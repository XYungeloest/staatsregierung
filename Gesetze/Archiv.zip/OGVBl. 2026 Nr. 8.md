**![][image1]**

**Gesetz- und Verordnungsblatt**  
für den Freistaat Ostdeutschland.

| Nr. 8 | Ausgegeben zu Dresden am27\. Januar 2026 |  |
| :---- | :---: | ----: |

Inhaltsverzeichnis

| 27\. Januar 2026 | Gesetz zur Einführung der Landesbank Ostdeutschland | Seite 2 |
| :---- | :---- | ----: |
|  |  |  |
|  |  |  |

**Gesetz**  
zur Einführung der Landesbank Ostdeutschland  
 vom 26\. Januar 2026

Der Ostdeutsche Landtag hat am 26\. Januar 2026 das folgende Gesetz beschlossen:

**Artikel 1**  
**Einführung eines Landesbankgesetzes**

Das nachstehende wird Gesetz:

**Gesetz über die**  
**Landesbank an der Elbe**  
**(Ostdeutsches Landesbankgesetz – OstLBGe)**

**§ 1**  
**Errichtung, Rechtsstellung**

1) Die Landesbank an der Elbe (Elbe LB) wird als rechtsfähige Anstalt des öffentlichen Rechts errichtet. Sie kann den Zusatz ,,Aufbruchsbank” verwenden.  
2) Der Landesbank an der Elbe werden einmalig aus dem öffentlichen Landeshaushalt 20 Milliarden Euro übertragen.

3) Sitze der Landesbank sind Leipzig, Dresden, Berlin, Magdeburg und Erfurt. Die Landesbank kann ohne regionale Begrenzung Niederlassungen, Zweigstellen, Börsenbüros und Repräsentanzen errichten und unterhalten.

4) Die Landesbank kann als übernehmende Rechtsträgerin an Verschmelzungen, Spaltungen oder Vermögensübertragungen beteiligt sein. Die Landesbank kann als übernehmende Rechtsträgerin auch an einer grenzüberschreitenden Verschmelzung beteiligt sein, wenn als übertragende Rechtsträger ausschließlich eine oder mehrere Kapitalgesellschaften im Sinne des § 122b Absatz 1 des Umwandlungsgesetzes beteiligt sind, von denen mindestens eine dem Recht eines anderen Mitgliedstaates der Europäischen Union oder eines Vertragsstaates des Abkommens \+ber den Europäischen Wirtschaftsraum unterliegt. Die Mitbestimmung der Beschäftigten im Aufsichtsrat der Landesbank richtet sich nach einer grenzüberschreitenden Verschmelzung ausschließlich nach § 10 dieses Gesetzes.

5) Auf die Maßnahmen nach Absatz 5 (Umwandlungen) sind die Regelungen des Umwandlungsgesetzes entsprechend anzuwenden, soweit dieses Gesetz oder die Satzung der Landesbank nicht etwas anderes bestimmen. Auf die Landesbank finden insoweit die für Aktiengesellschaften maßgeblichen Bestimmungen des Umwandlungsgesetzes Anwendung. Umwandlungen bedürfen der Zustimmung der Hauptversammlung und der Rechtsaufsichtsbehörde. Der Beschluss der Hauptversammlung bedarf einer Mehrheit von 75 Prozent der abgegebenen Stimmen. Für die Aufnahme weiterer Trägerinnen der Landesbank aufgrund einer Umwandlung gilt § 4 Absatz 7 dieses Gesetzes.

**§ 2**  
**Aufgaben**

1) Die Landesbank hat volle Geschäftsfreiheit. Sie kann alle Arten von Bank- und Finanzdienstleistungsgeschäften betreiben sowie alle sonstigen Geschäfte, die der Landesbank dienen. Sie ist berechtigt, Pfandbriefe, Kommunalobligationen und sonstige Schuldverschreibungen auszugeben.  
2) Die Landesbank stärkt den Wettbewerb im Kreditgewerbe. Sie erbringt ihre Leistungen für die Bevölkerung, die Wirtschaft und die öffentliche Hand unter Berücksichtigung der Markterfordernisse.  
3) Die Landesbank ist Universalbank und internationale Geschäftsbank.  
4) Die Landesbank ist auch die Zentralbank der Sparkassen in Mecklenburg-Vorpommern, Sachsen, Sachsen-Anhalt, Brandenburg, Berlin und Thüringen. Insoweit betreibt sie ihre Geschäfte unter Berücksichtigung der Belange der Sparkassen. Informationen, die ihr als Zentralbank zugänglich werden, dürfen nicht zur Anbahnung anderer Geschäfte verwendet werden. Zusammen mit den Verbundunternehmen der Sparkassen fördert und unterstützt sie die Wettbewerbsfähigkeit der Sparkassen im Markt.  
5) Die Landesbank erfüllt auf dem Gebiet der Landeshauptstadt Dresden auch die Aufgaben einer Sparkasse in entsprechender Anwendung des §§ 2 und 6 des Sparkassengesetzes.  
6) Die Landesbank kann rechtlich unselbständige Anstalten des öffentlichen Rechts errichten, sich an Unternehmen beteiligen und Verbänden als Mitglied beitreten. Sie kann sich ferner am Kapital von Kreditinstituten des öffentlichen Rechts beteiligen und bei solchen Instituten Gewährträgerin oder Trägerin sein.  
7)  Die Landesbank ist zur Anlage von Mündelgeld geeignet.

**§ 3**  
**Satzung**

Die Landesbank regelt ihre Angelegenheiten im Rahmen der Gesetze durch Satzung. Satzungen sind öffentlich bekanntzumachen. Der Erlass und Änderungen der Satzungen der Landesbank sind der Rechtsaufsichtsbehörde anzuzeigen. Das Verkündungs- und Bekanntmachungsgesetz ist entsprechend anzuwenden.

**§ 4**  
**Träger und Haftung**

1) Träger der Landesbank sind der Ostdeutsche Freistaat (Land), der Sparkassenverband Mecklenburg-Vorpommern, Sachsen, Sachsen-Anhalt, Brandenburg, Berlin und Thüringen (Verband) und die Landeshauptstadt Dresden (Stadt).  
2) Die Träger unterstützen die Landesbank bei der Erfüllung ihrer Aufgaben nach Maßgabe der folgenden Vorschriften. Es besteht weder eine Verpflichtung der Träger noch ein Anspruch der Landesbank gegen die Träger, Mittel zur Verfügung zu stellen.  
3) Die Träger der Landesbank am \[Inkrafttreten einfügen\] haften für die Erfüllung sämtlicher zu diesem Zeitpunkt bestehender Verbindlichkeiten der Landesbank. Mehrere Träger haften als Gesamtschuldner, im Innenverhältnis entsprechend ihren Kapitalanteilen.  
4) Ein Träger der Landesbank kann unbeschadet von Absatz 5 allein oder gesamtschuldnerisch mit anderen Trägern oder Dritten zeitlich befristete und betragsmäßig festgelegte Garantien gegen eine marktgerechte Gebühr übernehmen.  
5) Die Landesbank haftet für ihre Verbindlichkeiten mit ihrem gesamten Vermögen. Die Haftung der Träger ist auf das satzungsmäßige Kapital beschränkt.  
6) Soweit ein Träger seinen gesamten Anteil am Stammkapital überträgt, kann er durch Erklärung gegenüber der Landesbank als Träger ausscheiden. Die Erklärung bedarf der Zustimmung der Rechtsaufsichtsbehörde. Der Träger scheidet mit Erteilung der Zustimmung aus; der ausgeschiedene Träger haftet im Außenverhältnis für bis dahin begründete Verbindlichkeiten der Landesbank gemäß Absatz 3 entsprechend fort.

7) Juristische Personen des öffentlichen Rechts können unter Beachtung der vorstehenden Absätze als weitere Träger unter Beteiligung am Stammkapital durch Vertrag aufgenommen werden. Gleiches gilt für mit der Trägerschaft beliehene juristische Personen des Privatrechts, an denen ausschließlich Träger der Landesbank beteiligt sind. Die Beleihung erfolgt auf Antrag des aufzunehmenden Trägers durch Verwaltungsakt der Rechtsaufsichtsbehörde.

**§ 5**  
**Stammkapital**

1) Die Träger statten die Landesbank mit einem Stammkapital aus; das Nähere regelt die Satzung. Die Satzungen der Sparkassen- und Giroverbände können bestimmen, dass ihre Mitgliedssparkassen Anteile am Stammkapital unmittelbar aufbringen.

2) Jeder Träger kann seinen Anteil am Stammkapital ganz oder teilweise durch Vertrag auf einen anderen Träger übertragen.

3) Die Landesbank kann von ihren Trägern und Dritten Genussrechtskapital, stille Einlagen sowie nachrangiges Haftkapital und andere Arten von Kapital nach Maßgabe des Gesetzes über das Kreditwesen aufnehmen.

**§ 6**  
**Organe**

1) Organe der Landesbank sind die Hauptversammlung, der Aufsichtsrat und der Vorstand.  
2) Die Mitglieder des Aufsichtsrats sowie des Vorstands sind zur Verschwiegenheit verpflichtet; das Nähere regelt die Satzung.

**§ 7**  
**Grundsätze der Geschäftsführung**

Die Geschäfte der Landesbank sind nach wirtschaftlichen Grundsätzen zu führen. Die der Landesbank obliegenden Aufgaben sind dabei auch zu berücksichtigen.

**§ 8**  
**Hauptversammlung**

1) Die Hauptversammlung besteht aus den Trägern. Diese üben ihre Rechte in den Angelegenheiten der Landesbank in der Hauptversammlung aus, soweit dieses Gesetz oder die Satzung nichts anderes bestimmen. Die Träger werden in der Hauptversammlung durch eine oder mehrere Personen vertreten. Jeder Träger kann die Einberufung der Hauptversammlung verlangen. Das Nähere regelt die Satzung.  
2) Die Hauptversammlung beschließt in den in diesem Gesetz und in der Satzung ausdrücklich bestimmten Fällen, namentlich über  
1. die Bestellung der Mitglieder des Aufsichtsrats, die nicht von den Beschäftigten gewählt werden, sowie die Bestätigung der Vertreter der Beschäftigten im Aufsichtsrat;  
2. die Verwendung des Bilanzgewinns;  
3. die Entlastung der Aufsichtsrats- und der Vorstandsmitglieder;  
4. die Bestellung des Abschlussprüfers und des Prüfers nach § 36 des Wertpapierhandelsgesetzes;  
5. die Satzungen der Landesbank und deren Änderungen;  
6. die Festsetzung und Änderung des Stammkapitals, die Ausgabe von Genussrechten und die Gewährung von stillen Beteiligungen;  
7. die Zustimmung zu Unternehmensverträgen im Sinne von §§ 291 und 292 des Aktiengesetzes;  
8. die Vergütung der Aufsichtsratsmitglieder sowie die Aufwandsentschädigung der Beiräte;  
9. die Zustimmung zu einer Umwandlung nach § 1 Absatz 5 dieses Gesetzes.  
3) Die Beschlüsse der Hauptversammlung bedürfen der einfachen Stimmenmehrheit, soweit nicht dieses Gesetz oder die Satzung eine andere Mehrheit oder weitere Erfordernisse bestimmen.  
4) Die Stimmrechte stehen den Trägern nach dem Verhältnis ihrer Anteile am Stammkapital zu. Das Nähere regelt die Satzung.  
5) Durch die Entlastung billigt die Hauptversammlung die Verwaltung der Landesbank durch die Mitglieder des Vorstands und des Aufsichtsrats. Die Entlastung enthält keinen Verzicht auf Ersatzansprüche.

**§ 9**  
**Aufsichtsrat**

1) Der Aufsichtsrat besteht aus 21 Mitgliedern, die nach diesem Gesetz und der Satzung bestellt und abberufen werden. Die Mitglieder des Aufsichtsrats werden von der Hauptversammlung gewählt, soweit sie nicht als Vertreter der Beschäftigten nach § 10 zu wählen sind und soweit sich aus § 19 Absatz 1 dieses Gesetzes nichts anderes ergibt. Sieben der von der Hauptversammlung gewählten Aufsichtsratsmitglieder müssen unabhängig sein. Jeder Träger hat das Recht, Wahlvorschläge zu unterbreiten. Das Nähere regelt die Satzung.  
2) Die Mitglieder des Aufsichtsrats müssen zuverlässig sein und die zur Wahrnehmung der Kontrollfunktion erforderliche Sachkunde zur Beurteilung und Überwachung der Geschäfte, die die Landesbank betreibt, besitzen. Sie sind an Weisungen nicht gebunden. Sie haben ihre Tätigkeit uneigennützig und verantwortungsbewusst auszuüben.  
3) Aufsichtsratsmitglieder können vor Ablauf ihrer Amtszeit von der Hauptversammlung mit einer Mehrheit von 75 Prozent der abgegebenen Stimmen abberufen werden. Ein Aufsichtsratsmitglied ist auf Antrag des Aufsichtsrats oder eines Trägers durch die Hauptversammlung abzuberufen, wenn in seiner Person ein wichtiger Grund vorliegt.  
4) Mindestens ein Mitglied des Aufsichtsrats muss über Sachverstand in Rechnungslegung oder Abschlussprüfung verfügen.  
5) Aufsichtsratsmitglieder können nicht für längere Zeit als bis zur Beendigung der Hauptversammlung bestellt werden, die über die Entlastung für das vierte Geschäftsjahr nach dem Beginn der Amtszeit beschließt. Das Geschäftsjahr, in dem die Amtszeit beginnt, wird nicht mitgerechnet. § 19 dieses Gesetzes bleibt unberührt.

**§ 10**  
**Beschäftigtenvertreter im Aufsichtsrat**

1) Sieben Mitglieder des Aufsichtsrats werden als Vertreter der Beschäftigten im Aufsichtsrat von den Beschäftigten der Landesbank gewählt und von der Hauptversammlung durch Wahl bestätigt, soweit in § 19 Absatz 1 dieses Gesetzes nichts anderes geregelt ist. Für die zu besetzenden Sitze wird die dreifache Zahl von Beschäftigtenvertretern gewählt.   
2) Wählbar sind Beschäftigte, die am Wahltag die Staatsangehörigkeit eines Mitgliedsstaates der Europäischen Union besitzen; im Übrigen gilt für die Wählbarkeit § 13 Personalvertretungsgesetz entsprechend. Bei Verlust der Wählbarkeit scheidet der Beschäftigtenvertreter aus dem Aufsichtsrat aus.

**§ 11**  
**Aufgaben des Aufsichtsrats**

1) Der Aufsichtsrat hat die Geschäftsführung zu überwachen. Ihm obliegt die Bestellung, Abberufung, Anstellung und Entlassung der Mitglieder des Vorstands und deren Stellvertreter sowie die Bestellung und Abberufung des Vorsitzenden und der stellvertretenden Vorsitzenden des Vorstands. Der Aufsichtsrat vertritt die Landesbank gegenüber dem Vorstand. Der Aufsichtsrat wählt einen Vorsitzenden und einen stellvertretenden Vorsitzenden des Aufsichtsrats, soweit sich aus § 19 Absatz 1 dieses Gesetzes nichts anderes ergibt.  
2) Der Aufsichtsrat beschließt über  
1. die Feststellung des Jahresabschlusses;  
2. die Einrichtung von Ausschüssen des Aufsichtsrats, deren Zusammensetzung und Entscheidungs- und Vertretungsbefugnisse sowie deren Vorsitzende und deren Stellvertreter; weitere Einzelheiten bestimmt die Satzung;  
3. die Geschäftsordnung des Vorstands und die Zustimmung zu der vom Vorstand vorgeschlagenen Geschäftsverteilung;  
4. die Beauftragung des Abschlussprüfers und des Prüfers nach § 36 des Wertpapierhandelsgesetzes;  
5. die Zustimmung zu den in der Satzung als zustimmungsbedürftig vorgesehenen Maßnahmen und Geschäften;  
6. die ihm in der Satzung zugewiesenen sonstigen Aufgaben.  
3) Der Aufsichtsrat beschließt mit der Mehrheit der abgegebenen Stimmen (einfache Stimmenmehrheit). Jedes Mitglied hat eine Stimme.  
4) Der Aufsichtsrat überwacht den Rechnungslegungsprozess, die Wirksamkeit des internen Kontrollsystems, des internen Revisionssystems und des Risikomanagementsystems sowie die Prüfung des Jahres- und des Konzernabschlusses. Er überwacht und überprüft die Unabhängigkeit des Abschlussprüfers, insbesondere die von diesem für die Landesbank neben der Prüfung erbrachten zusätzlichen Leistungen.  
5) Der Abschlussprüfer berichtet dem Aufsichtsrat über die wichtigsten bei der Abschlussprüfung gewonnenen Erkenntnisse, insbesondere über wesentliche Schwächen bei der internen Kontrolle des Rechnungslegungsprozesses. Er erklärt gegenüber dem Aufsichtsrat jährlich schriftlich seine Unabhängigkeit von der Landesbank, informiert den Aufsichtsrat jährlich über die von ihm gegenüber der Landesbank neben der Prüfung erbrachten zusätzlichen Leistungen und erörtert mit dem Aufsichtsrat die Risiken für seine Unabhängigkeit sowie die von ihm dokumentierten Schutzmaßnahmen zur Minderung dieser Risiken.

**§ 12**  
**Vorstand**

1) Der Vorstand besteht aus mehreren Mitgliedern; das Nähere regelt die Satzung.  
2) Die Mitglieder des Vorstands werden für die Dauer von höchstens fünf Jahren durch den Aufsichtsrat bestellt und privatrechtlich angestellt; eine Wiederbestellung ist möglich. Der Aufsichtsrat bestellt die Mitglieder so, dass zumindest 60 Prozent der Mitglieder des Vorstandes Frauen sind.

**§ 13**  
**Aufgaben des Vorstands**

1) Der Vorstand leitet die Landesbank in eigener Verantwortung, im Rahmen der Gesetze und im Unternehmensinteresse. Er führt die Geschäfte der Landesbank und vertritt sie. Das Nähere regelt die Satzung.  
2) Der Vorstand ist für alle Angelegenheiten der Landesbank zuständig, für die nicht nach diesem Gesetz oder auf Grund der Satzung eine andere Zuständigkeit bestimmt ist.

**§ 14**  
**Beiräte**

Zur sachverständigen Beratung der Landesbank können ein Beirat oder mehrere Beiräte gebildet werden; das Nähere regelt die Satzung.

**§ 15**  
**Siegelführung**

1) Die Landesbank führt ein Siegel mit dem kleinen Staatswappen und der Umschrift "Landesbank an der Elbe".  
2) Urkunden, die vom Vorstand oder von den mit seiner Vertretung beauftragten Personen ausgestellt und mit dem Siegel versehen sind, gelten als Urkunden einer öffentlichen Behörde.

**§ 16**  
**Öffentliche Bekanntmachungen**

1) Öffentliche Bekanntmachungen sind im Staatsanzeiger für Freistaat Ostdeutschland vorzunehmen.  
2) Öffentliche Bekanntmachungen im Staatsanzeiger für Freistaat Ostdeutschland können durch eine Auslegung an allen Sitzen der Landesbank unter gleichzeitigem Hinweis auf diese Art der Bekanntmachung im Staatsanzeiger für Freistaat Ostdeutschland ersetzt werden.

**§ 17**  
**Aufsicht**

1) Die Landesbank untersteht der Aufsicht des Landes. Die Aufsicht beschränkt sich darauf, die Rechtmäßigkeit von Geschäftsführung und Verwaltung sicherzustellen, soweit gesetzlich nichts anderes bestimmt ist. Rechtsaufsichtsbehörde ist das zuständige Staatsministerium.  
2) Die Rechtsaufsichtsbehörde kann sich über die Angelegenheiten der Landesbank unterrichten, insbesondere Prüfungen und Besichtigungen durchführen, Berichte anfordern sowie Akten und Unterlagen einsehen. Die Bestimmungen des Fünften Teils der Gemeindeordnung gelten entsprechend.  
3) Die Entlastung des Vorstands nach § 8 Absatz 2 Nummer 3 ist nur zulässig, wenn die Rechtsaufsichtsbehörde bestätigt hat, daß die Jahresabschlussprüfung keine erheblichen Verstöße ergeben hat oder alle wesentlichen Umstände erledigt sind.

**§ 18**  
**Neubildung von Hauptversammlung**   
**und Aufsichtsrat**

1) Spätestens innerhalb eines Monats nach Inkrafttreten dieses Gesetzes ist der erste Aufsichtsrat mit einer Amtszeit von höchstens fünf Jahren zu bilden. Für dessen Zusammensetzung gilt:  
1. Die Mitglieder des Aufsichtsrats werden von den Trägern entsandt, soweit sie nicht als Aufsichtsratsmitglieder der Beschäftigten zu wählen sind. Dabei gilt: Das Land entsendet fünf, der Verband fünf und die Stadt drei Mitglieder in den Aufsichtsrat. Der Vorsitzende des Aufsichtsrats wird von Land, Verband und Stadt einvernehmlich entsandt. Sieben der Mitglieder des Aufsichtsrats, darunter der Vorsitzende, müssen unabhängig sein. Für die Abberufung gilt § 9 Absatz 3\. Der jeweilige Träger hat das Recht, im Falle einer Abberufung oder eines anderweitigen Ausscheidens eines entsandten Mitglieds für die restliche Dauer der ersten Amtszeit ein anderes Mitglied zu entsenden; im Falle der Abberufung oder des anderweitigen Ausscheidens des Aufsichtsratsvorsitzenden steht dieses Recht Land, Verband und Stadt einvernehmlich zu.  
2. Die von der Trägerversammlung durch Wahl bestätigten Beschäftigtenvertreter im Verwaltungsrat, die in der letzten Wahl der Beschäftigtenvertreter durch die Mitarbeiter der Landesbank im Wege der Verhältniswahl nach D’Hondt die sieben ersten Plätze erreicht haben, vertreten die Beschäftigten im Aufsichtsrat. Im Falle der Abberufung oder des anderweitigen Ausscheidens eines Beschäftigtenvertreters rückt der Beschäftigte nach, der bei der letzten Wahl der Beschäftigtenvertreter nach Satz 1 den jeweils nächstfolgenden Platz erreicht hat.  
2) Sobald die Aufsichtsratsmitglieder nach Absatz 1 Satz 2 bestimmt sind, in jedem Fall aber vor dem 31\. Dezember 2025, hat die konstituierende Aufsichtsratssitzung stattzufinden, die der Vorsitzende des Verwaltungsrats einberuft. Unter seiner Leitung sind in der konstituierenden Sitzung aus der Mitte des Aufsichtsrats auf Vorschlag der Träger der Stellvertreter des Vorsitzenden des Aufsichtsrats zu wählen sowie ein Präsidialausschuss, ein Prüfungsausschuss und ein Risikoausschuss zu bilden.  
3) Mit der konstituierenden Sitzung des Aufsichtsrats tritt die Hauptversammlung an die Stelle der Trägerversammlung. Zugleich endet die Tätigkeit der Vertreter der Träger in der Trägerversammlung, des Vorsitzenden und der stellvertretenden Vorsitzenden der Trägerversammlung. Mit der konstituierenden Sitzung des Aufsichtsrats treten ferner der Aufsichtsrat und die von ihm gebildeten Ausschüsse an die Stelle des Verwaltungsrats und dessen Ausschüsse. Zugleich endet die Tätigkeit der Mitglieder des Verwaltungsrats.

**§ 20**  
**Zusatzversorgungskasse**

Die Zusatzversorgungskasse der Landesbank besteht als rechtlich unselbstständige Einrichtung fort; auf sie findet das Versicherungsaufsichtsgesetz keine Anwendung.

**Artikel 2**  
**Änderung der Haushaltsordnung**

Die Sächsische Haushaltsordnung in der Fassung der Bekanntmachung vom 10\. April 2001 (SächsGVBl. S. 153), die zuletzt durch Artikel 1 des Gesetzes vom 27\. Juni 2025 (SächsGVBl. S. 285\) geändert worden ist, wird wie folgt geändert:

1. Die Bezeichnung des Gesetzes wird wie folgt gefasst:  
   ,,Haushaltsordnung des Ostdeutschen Freistaates  
   (Ostdeutsche Haushaltsordnung – LHO)”

2. § 112 Absatz 1 Satz wird wie folgt geändert:  
   1. In Nummer 2 wird der Punkt wird durch ein Komma ersetzt.  
   2. Nach der Nummer 2 wird folgende Nummer 3 eingefügt:  
      ,,3. die Landesbank an der Elbe.”

**Artikel 3**  
**Inkrafttreten**

Das Gesetz tritt am Tage seiner Verkündung in Kraft.

Dresden, den 26\. Januar 2026

**Louis Hahne-Eichinger**  
D e r   L A N D T A G S P R Ä S I D E N T

**Dr. Karl Honecker**  
D e r   M I N I S T E R P R Ä S I D E N T

**Dr. Karl Honecker**  
D e r   S T A A T S M I N I S T E R   F Ü R   K A P I T A L A K K U M U L A T I O N  
D E S   F I S K U S

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJMAAADJCAYAAAAn8ACEAAA5e0lEQVR4Xu1dB5gWtdae7Z1t7C7L7rIsLKA0YaWDIFVFmkqRiyg2rGAFQUFF0YvKFQsiimLDDhZQxIoIiNiu/na913rtvRfE/Hkzk/kyJ1O+tvAt7vs8734zJycnmcnZTJJJMobRiCCkcDLODBrQiEaEi7s52Z9bDMa2GuyvZ4RDgWuJXiMSHD9ydqXCHQQ2bbzpQF6cfZjtWDsD1ZzbqLAR7rALDccW3yM69QXNcfwIfWqgnvCKYd2LnZB2gwQ7/xi9wFwKL4lGjANg9y+aXji04tZXwYrHK01TcvGMek27QeKS8qbG7/RGebEwz755cbuJ3O5P+KFphUMlXi21GyXkdf1B0/Ji51qDtWhmrHNY+Tti1QJjM705QeTRWPf2cXOmqdR+NJxxiPEHNRwlvjSicOzX7xS/mdTY3wJlRcbPRhQ3TeWvG42h1G4U0OxGQ9ihhqMBt/UntR0uEZ3zBX58ELW7S+PrR43LjRgLEvGp3Sig2Y2GWRk7Py8yPjW6I7GBCjhKOKdzFtKAeIFf9AP0ZkTKi6fFfuO4nd+o3RjYkdqPBLzteLuLzYhJ7cYRuZzTOEtpAMdj+CMyIAfnKIuaGKxnB6OzFSFeGc2n6URLI7Y83UftxcKOrWPKy6/UXrR8/Q7jDGo8SsjraZqW6t4h2Pa0+Wvr/r7J2ESVVHZpKxT/TzEeK16jaURLI7Y8vUztxcKcrJjyotmLlm1bxJQPFbDTNSXZ+ISm4cJ0O5JLoIO86ymP85XEooVmP1ryWjOWG5dB7cXCZ28wbqIJRIDPqb1oacT2D2aD23q5RwfdPiVU1Xi/UAUv0ohRQrMbLWGLGo8Qms1oCDvUcITQbEZL2KLGo4Bm14vQdcRcvdC4hip5ce4RxvWOyJFDsxktYYsajxC3UZvRsNvuMb8v02xGS9iixiNEV2rTi1894p6WpuhF6NLIEeICajNaPn+TMZvYDsqbzP94VUbtRkLLnsQY6zycfKjIpHajZXUzzXak0Gx6Ebo0MrCBKvpxyv7Gp9RAhNBsRkrYsGydhOMkw3y1oKThhmdVG0lJBktNMX4xfPITFMaJe+GQjx8SmI/v09Ps+DMtmWY/UvJrCUo3CCdRm36sKvNIr38XYzFV9qLh4ZERoPbNu8Jvq1HeeYHBMtKMVoZ7AaTRxBQscdGX16PJZRiVBcW5ZLr//eE6z7nYqpsywniS2gqX6KYfOcp4kiQVKTS7XrzvkoBrpBG8CF0aOQAY8ab4gNpVOWovXaamf+7RxjdUjvEymgiBZku16RbuJXOTk3BPvH+/cQeNc8d8f5udWusylclJrmkuo4IAaHa9CF0aWcW5NIIXjQBDLsC7NFEtZmeGCoPz5XdW6fbBtYt0mUz75InGO1Su5Msrb5o+JXSonts5lbnR0nODZ3w/h8KUEyoDv3+C39MM409pF+NdlaUG+2G9bx68oNn34sRhxm80sgP8mfsgjeTGE8eJzKsIyrRmA1w6y7zgkgLjBxrmRuh62XLRc4A/Br6leuEwnPS8+NEa++2BhKZDmZIcfpq9Opq6/zxeDwMRRtKnoOGnUBtuPGmCFs8VWkRK7pHS0ADor1pgyp9ZbpypGiI4gNpRaXg4ydPX6XpUx43bzddDRUr6mk4QEQf/3Tj+fVP4aVMbSh4MXou8QnXcSNP6fJ27DtWjnHGI8bqaPkE6dJ5YYtsaBWFKirGV2qG09APRn0akNDwuwpL7QYujsqLEHLdQZe1a6HrhEumFmzblszfoMhCPISrzYyx5ULlPL+f5L08ZLDfL2Eb1VJK03eAVR5NT8prwBWrMC1rDVnLOEd6J1bUz/qKGFGj6fhzc3WCzDjOP37vPO00/Ik606Xvpe8m9GEseZPyXbzWPF5xgsPY1uo4fSfoUK6m+jFPdzHiEyiXREaCG/KAZUBOiMhpOjXEMoHpBPGBvXXbTObrMj0YEBWnpOkh1ItEj+hJauB83XavLTpuky4LInfB5JQ8Smp5Kv3CEUWN+yKYGFCPbqZzS0lOh6fjxqWt0mbRrzWGy+eOTup6kNSgYVR5AGoeeh0Mrn4F5UNblCV54vHd6N8zVZX4keQA0HUr+CPVMf/0S41xiLxAOA/JiqWEv8v+gN71s+RH/eV76BXm6zI+wE00eVJYWmnbyc/WwcBhLHvZoo8ukTfSm/FauUH0lD+NpuBcRj3c8flZlyWZPM2JoxiMh4odr68Rx+o2hceh5OCR5SKLhO4K8vTdRyYMWHkQah57jvp18sB6PxoklDz62wgeP/CMGxKjBcDispyPRC2l4ODxlopl5vD+jYeEQ8ZQ8AJpOfRLpkfS/pjrhMC3VtHXkKD0sHI4dZGxX8uA62BvEnzeYv7ymouNmYcE2hEKxxm0iomrsxVuMa2l4fRLtLjV9C/22PR3c5osXjz3QuJZmYNRexkKqV5/8baPzPnzzaOTlYCi+gGPVXjjwNKg2FI85QNcjrPGzWZ+08ugGTdeLVJee+xG6JF0JTbc+ifQciW81vqM6ksoeCvaaALf8UptB0Aw8s9y9ux7APMXmni7hYfOzh3SZF5F/JV03LDVcrtHFhmNQ0JJpulQnK8N4UE3MBVo8Lz53oy6LhAunG+sdCW81/kN1vIg3HSvm6XKYUW0GwdUAlfnxkwddE9T0/Gjpv03OPYlwi+FCs5GR7rDhZh/4C2/oaVwlPByEdT3813boIH1KKw0HzptqnEX1/OiWpptdX5QUhiKjvYRlPNSoHw3vBDVdLw7ubrxz9GhjtjxvWiBsYhm2pgtCTtIKwiFqXN42vJKEO14+795Ssz/fUPJywljjHRIeBO0aQKv7DdrvyN64U5yfH27b1YrvBk3Xj3iNg9ke8rxNlbCLDdAihsjUlw/riQTRiusF1+pTEu+/+KMCsx+NluWhniDiKTawG4qQyfCa5r5peoHalWhO8wXyfLvND/KyEYQnyLWByUq4ne7KBbb9D/ijy3Ojj9ULA/OixQkiBoYRz2Js4AYj2m4GtRq14YE2XN/RuzJIhtcuMi6SYbec62n32+MO8gwLwiVUYEG7Lrf8KbiHCsJBRpqxNi3F0XW3sUcbY5lM15q1oELL29lHGkcTHS94OqMP+1MjUYFX/64vBN04ci+DdWhlVFEbPhDxDh5qsNxsYxYJ09a1QZ/oSLxEBbHghZuMNWqa8vi7x8WvWnvEinepwIL2D3zPRWKuu4pD+WNHzFY1vO+LG3IrSowPqX0vzjgkItuBEEaTAjwaejRiGMhcd7nx3JKZxhE0gMOezPbxg+ZvGAsG4gH7mniDlf3Eq/kjRsZ8nREhyVqUKQcLQY9XGc1evtX4jbfX2tKAMKCVoUrshcV/8ZLYLd2oIYxj3wEce+1L4HGx4cArnm2bHlPFOOJ69ZoMK135K9mro9h3s76gpR9w3V7yIDiuSVIZS/y/gHSjwrEuRk+xzsUjyiU8Znz9qDkssOxMg2WmOy+4dyfjNaofD7StMl6SaTx6pTNN5EMeT59gsHOOiuvjTmKe+p6Sn7OzDjeP8U/8wxNGUxohBgi7R422yw5U1yGK8JMmiL204gde1a+A4fsvMebSMAvxdibHDcWv+kIT+1+2KBNLneIJh/MEncdQE3shf+CeZm0AXnaqni6OaaQY8K3hba9ASTPuqI+L8YLdg1NvpvyV/Mc+YqrvOBo5CmDDeK1XqZ57ya1NvuKxmUe39jXGR25pyV/JYT2Nz2jkeoBIi3eK6qW8HRdJA+OJ8qah/05QrfbRAFfDvnks5vxsu2O+s+eEmRJeE/T+e49YceKQrb865jxoNvftractic4ANRBn2GnhmAbGA44LisMyZC840qHnHVrpN1e56BXElh8uNjxqn6ApL6iNqAyEPc6rSTp+8NyKEZPyqG313HrtUx/4nqZLFeIBbOakXSBVigFdeZWqzfdxWw1ieBQA2LypnS+xLZ4CNJax5SJrVqzHo7b77uHNoDy0qrDz8LSVrooHEFacr8ejeVC5dbkuwyZs2ZnGMGI/Fmj52LzMuJQqxQUFucaL9IKM+DgU+2OzfrMgp7JwwqKlatPLfpMcp06478rCpVe6XmFKNz5WaLa7mjsG1htcL8jaowdMJfpBwDJm162KsYaOyigRn073jYbYtu+EsU4ZbFM9NzlW0vI2nqYXDaltN2KiP5WB1vKjSAtfvN/84H7dHuQW6w12QjRxl0xs5mynxM3hvFOGy5WybrznIu9FkJR+a/ODKP8JVBnO5ZJ1qi/Dbz1PD8c5bUSHS7TRrjhNl7vxfV7wl1tDBm60ZlZKrjTMHXIlMJSyXobTuJIyzNKrN9xJE4w35001C5PKg1hbGX6eurbTdTFn/bD9nec0HogpGPL49EkG23M3ZzjstqvW47kRutHUag9cGv188CBieZg87rZ7/ToTZhDYLwhxSjMTC2EPy56pPBJuvNZgvG2n/nd6EruF7NXFPA637aPO7ZFE/P5dQ2vNggi9DUt1O5HQ2jpIk8dCF3vYD75e4RiTkYsiacYiIeKPGaDLMY9q3GC9MDA8cOPZun40dMs7XqPQNFViozEax81ONMQ0G+tltoMHDjTYp2t1ffkqhMojIeLTlcLWRMR6h5YZEKPRCAt3Cbdsd8hHjiQakqhdqH59ED1IupTL7frCkWHXNgygUr36IObj15H7Zn2YyPH+0I93XWjqe22oZtmtd2gJU55zlPNCKTFW49cAjyfRKEbjduCe5opgmhdVl55HKqe2MYwwoM5gi05x7zHVB9FM2LtOz4vKcJaXW7r1jhyasORbdzszjUWUVCcWol2DgsGuaGo6IEbkMdsSjyhsNE/julEd28JMRq92E+xTmSTdAigcYnQbeyJhJbOySapNDKpiT0yvqT7RcuZkZzqv3KbrSPL7qK35qxcM72NchAakoWTsw9V6hiLlQ5cZLM98sWgTI9r3Xqzr+jGcqh7Op54jLaoTTRg9d+OZU3SZH9f8y/xChHpf8EoHcqobKdEOU+0+cqX9rnGH4APazoiE94cmvNuEs+CX6kbLcP6jaXro5lMdL12VV5F9Jv10JbHfFJVFS6QHp1JWtAhiAQLVDZeY3clt/CBKu56hJe7Gf53kvLijx+g6KscO0mX1yXCvoz5140E0xKlMJUb21XLw2vuS0tKvd2hr9Xt3CmUW7RYavjPot28TiLxSmReDdNWaOkg33pSf6IqU1gangm4OaYXtEIjELjpRz0QsfGyxLouWaKhTmUrkn8q8GKQbiTNF2v7z47v36rJYiHsmy1Yt7B2B52lmYqURUBCRMGjvx0jSCtKNxJl450WTRUuvl76x0Bok3uHQMhIrI7W57nJzRiLiuRGLELDY4fb5+muQSNIK0vVzJgw5YIAQg7pkM30H8S7QaxN9L9K04kErPzscWkZipbSJgTds14Nzla0rzd5gPKadRJL/IF0/Z4qWeJlrfdHSQbzgxTo+6MQrLZVWOjsc+9KMREK8MpHr8CQPVxY6+jFo271wiPSozItBuvF2piUzdZkbcb/U+4cxOgyGUr1IeMFxxnt2Ce9IbFpmXE4zQ3ntbOcFq9M8oiXsUFmkjMRGkG68nSkeNshaOG3ynxvpLnM7GnZGMGkL55LXzHZmtKxIz3y0VNONlpHYCNJNRGeS7NPZeY7ZFmo5vb0yFGbJdhpEBrD8h14EJfSoLFrGw1YkNoJ0E9mZwrGFl+GyLGXB7gw4lsX40QjjosJlPGxFYiNIt6E7k6obKtqdAJohL153li6Llthrkcr8+NIKczk5pr6oL5KpnheDdKkzgZjFiUcMpiG/eLMex490KnAsjOSl8lePuO5Es+PAe2Sunyl1o9cUj0iIhQZDeoQKTSVedk4dY3arg4YPoE9lXgzSpc5Ew1UiX5gdgddO1kJWjZhCQz+NVt9ED1IU6E6GljEvolagMpW40VNG6DcXo8av36nrx8JI8h2kG4kzRUo0kDEbkt6TSfsG/3PSpfR+tOzudGgZ8yJ04TDYdBPHkgcNdF+EWZ+MNN9UprI+nSmImG4zYajzfmJWaaTfurHi7nQsoBkD0cMzlAvEq4TX7tD14smvHzV3eqPzoxONWNaNqc1fuHzdMp5ErYapw2ra2LWX6oH8H9rvW4E7Dryd8qFhZRbtFrllYLyIMSu3+dtexFo0zJ/Cq5dwJsrtCOKRhElseE2E1co0z17Ey9xwR8TDJVb9yO+xgNYbBbonwk6BltlIiakssONHrL6I9VVBQyO29VHninlx/rF63Ehp2drp0DLmxudvcuz+rxEN76AeWCOdxP2ir01Uore45Xo9nhutODsdjkzhOQ2ZG9HlxZQMeiGNjD8xA7PfHnoZSL56u1PfkicEHBnFx5rpxTUycbhfH925lLJMCNDMNbJhMaHAdlWcccYZ5g2fP4QZqcnMSE4yjyWndg8d64XUUJhQoGWwy8B2JlA6zF7VzsKQzgRnU89VJxvUyjwuyGTG8T1oYe5sJhRoGewycNRM9BdsU8yMGf2chUN1VDmVJQYTCrQM6gUfffQR+7qqln3FiTRx3DMjk6oF4n//+x+7/vrrWWZmJjuuZSvWpVk5VbHhcCYvh6KF46Y7cy9mnDeYGRVN3OPsXCYUaBnYQMGj0P14dn4x27BhA43qwJtre/PeSDKrSc9gXThfeOEF9qXiVBTbt29nLzdvaadxa9NydmRuviPd/1TUuMZVYTtTj0p3JxnbgRaMswZSedYAbwfcuUwo0DKwcdXCf9mFt7q0gvXPzGK1qenCgahTbdmyhUY3sTWNlZYUsi7tS4RDvXhff7Z9fSp7y3IG8I8//nBEeaysSrPvxjF77+2IR2E7U9dyZpypOEOS1RBHmJdzQN6pzPxtlsuM9BRdJzGYUKBloGFmkyKtICnPKC6l0QQWLVpEReyvv/5iR/ZKs+PSPKAmovalXm5GhkPXD47HnNqTQy3TuRkzpvVixvhOpqOpBZST7qyFpGMpOqP2StqpxPY9Vl4SCrQMXJGRns4+rmxtFyxqGVCer2jq3XZ5p3V79o/OXdiwYcPYfvvt5ygU254Ch5ynUZmdojnWyLwCtmbNGkc8CtfenHSS3i3MtlBNITPSUkJyL57a1+Fg8vp3FuFQ1rUlFGgZsB9++IHV1dWx86tDzgMOycwWv3P2ybAvKifJdCi3Gujjjz+2j0U6z2awD57oy55a3EnE7Z6eKeIibNy4cbZuarJpU715o7Nz7XzM5Y/Zp5u1cOTt/3gbi0I6E+LjV3OolOSQrEOpw8mFPE2JN7DG/OUN8epmjc7kBVoGrBsv5Gd4Yf0jpwl7s3mobSP5P15DjeyYyo7qniHO01NTqQlfoP11UWGJbc8tD+ncoW7ntV1BajK7cJSZDviZUjuqdIPqTCCONYfykZ17dBLbp5fyeES7if+aM0/1At6RbDDOBCQZoUfNZu5YybzRqhYe5j8dlJ3HDp4wgUb1xS233MJ6ZJg1EnhT02aiDeUF6CwpKnOk3bqmRoR9+eWXRNsJ6kwgzr2cx/5tXcSM4uyQ/vlW2NkDeeN95zsS2KCciQKFeHdJc7tAK1JSxe+hhx5KVV0xcfhwh0NIPlpWSVUdgM46rnMWf7Spvbx58+ZRVQ1uzgQaKVZtk5fh7lBgryotnsOGgc/bJ2nyHcUG60wovJpUs/fVLi2dfVjZij1fXi3OgQvnzycxnJgzZ474zcwIPa4ks/njbPny5SQGY+OKS8Tvq9Z40/LiZuzkJoWOsa8+vXuTWE54OdOna7kzdK9gxtHdmHFQB3eHsn7VeOIxN3r3UHhuumZ7R7FBOhMKbf+sHPEL3WQj9PirSDPbSmj8rlu3jsR04qijjtIcSTojxX6ta1mHyip20vTprF+t2ZOblV/ETm9SJPKgOtT8UWNodBvSmTCFlhJyMSRQnmeObkuHykrjjzV+3iLf/OV6Nc1NivEqqWc5G9pPO4PKcquEAi0DGyiso62R5xyrVoEzIY5wBP4f8hyvoYC6klJP5wAwdEAd6VjevaeAozz++OPiGDp/bTKdaSrX/bzKbHwDciwKtaRXuo6hAS+qNRF4Qk9mjGjHjHEdQ49DN7Ys1G3tHCYUaBmwt956y1HoeK/Wra5OHL9U3pJ1TDMd6xhewPvyWiuoEZ7N21cLld4b+BRv1E+dOpWq2kC+WvFH6xO8nSQfqRgS6MTTruNpAgcOHGTba1qgO2ZYzgRSh6ouYMa8QcxowttUhVm6rlIzoUEujuUIe4Y1Ui7Da4v19OLLhAItA4FzTjtd9LwkvuAFhscMCi5D6dmh5kCNUZSbq8R2ItcaN/pvhVmLgEh3xYoVVFUgJzVVOO3vq9OF7vS8QjYyKzTOBIaDsJ0JpA4VJJM8uBMzdi9x6qhxxuyux4kvEwq0DDSceOKJjoL8gD9a5ONFFCx/3HVON2uriqxsOx56elIH+k82q2JrSisctmT699xzD2uVYzpMdjLvJT0dGvWGDijPU40kdgfvWQYhImcC/ZyH/krO2ds9TJXhXSBNK35MKNAy0IAClE7wuNU9z+I3CA4ku+sTu6UJp1o0NJvtlZnFlhaXsYvJow1v/h8qrXTIQPTU9uC23j4vR9hISQ45jsrnnnvOcf7555/TrDoQsTOBfg4FWo1yh34Qzx2kpxM/JhRoGTjQt08ftkl5dSEHL6/jDoC4tMAh+9/STOEUNMyL0F0+KdNhb15BU9HITrFumpTXNTMb3hutPPkhKmfC2BPaS2g3uTmU6lgqZY9w7xpdLzNV148fEwq0DBxwFDo5P58XuOyuUwehfEWZn+RHjLZjLpO0mWY5L9LC7+zZs8WrHhw35w37VtUtSY5DiMqZQIw97d+WGcf31B1Kzj6gcVQ9sH5rI5UJBVoGNgrz81lhstl2aVlUxEaPHi2O5cS1+0oqxOPu4TLz0aVOaKMcbo1VgZ96vF8DkR8MD6BGwrlsi11lvVJZZbWV1Dhe8Bq0DKL4lh5qGow5SSfBefO80HQVKffiYV1Dx6Xm4zuebHCDlrKw0F4C5liT4hBH/V3P203nFBSLHh91jquLTSc4M79IDG5ipsA03jtD+0nGV221Tk0TQwKy94bxJWqT5u8xlxkDQLTOBCKeXdNIpziwvbmipWcVrR2Y0a9a1z/Ucqgo8+DHBuVMkHsVnuTdd98tfifmNLFlg61pKqB8FaLSzTkk3QY2b+BtMzlA+YlVo3377bdanm699VZbJhGLM4GIqzlIrjVxTh3QVPREvMldzPN/dG50pj///NMuJBVqIeNRtHTpUnEMG2rYqU0KxW8KmWkg6feY+0gZcgAxBWbhnDniWKbTotQ5q1PqUsTqTCDiaw5FZdbvieOsAoYMMw0UfWo3VjYYZ8KcoQrevVeBaSIosBHW46dty5bsggsuEMdHWa9c3rUGJWFTyD3ex2EQUh6/Tmqvob17a/qAmywI8XAmEDZ8Hco6vvD40CyCj9Yks983JbPPHjLPjx+bxFYuiN8sgwbjTG6YNGmSKMRB1mMMOOWUU8Sx7KajJ4Zf2HRzAtlQR/tJygZye+rUEhpHyiZZj1KsapGyIMTLmUDYEc7j8Xhzq4GEXM4dR/g5A9nDV8THoRq0M0GPFnDX9u0dMjnfSeoC+EVPDKtasCLlNV4TYSrJe0otVm1Nb1HjgHKAFHj99dc120GQzrR1eXLMfOoa7hwtC8xFm72qfB3q3XuTBW2Z5PmD2azDktiPTybHzOF9G7AzYQqtfOEq4+BXdaYR+YXiBW6/jCzNMbyYl2W+SJXnahzMnZIyasutwU0R9TiTHzGrALWNunRKHXtSnYeS2ooPEwq0DFyBApSzKyUQVy3g8sJCNqiq2h5UBPBok/OP1Fcpd1m1WE1lpd2Ql3HksZw6LJFuNejxOD20W3db7oV6cSYQjiFnC4Cz+zNjz+be+xBQZ8IxBjVVOWzQeOExoUDLwBWq00iMz85zyP/zn/+wNm3aOPRubNrMoYP08Ct7dDJ9NY50vges94EqcH6BNRoehHpzJpDWRN0qmDGrvzmpDq9jIBtW614jQSaXTqkrYFTSON5MKNAy0JCbk2MPSOZlh2YFvK2sylULF8cLeOMckBPawC28Rim3ajfJf3LHALDiRdpAnlSd22+/3batrk755JNPbLkb6tWZQOpQ9HGn/tJ4eIeH3+y0kAw1G17juMXxZkKBloEGFJyccUnlKt1AddyIcS0KNbyqPLTA84r55nAEJsqdUeq98BOod2cCqUOpMnoMqos5MQNBHoOyRqNx/JlQoGWgQRYqZjlSeW+rsb2wrocjDOiRHXof50fUehRq+NY2HTzD/LBDnAn0cyg/x6BOV5Kjy4OZUKBl4EB2aqpnwUEm20QU2IxCxtstJ1dcuDq/6apFixxO8f777zviy3S3lutTTb755hs7nl/+d5gzYaMwOIDX0ik35+hp7cyC46Isd53wmFCgZeCALLTJLhtTqM5AQcNmzZrFmljTd6UM87ulQ7jlg9pQ0ceqEd3CJOI5aOnHD1dzZ+rTghmH15kLEbwcCjylT+jYh08s8R/cbHCDlmj4ehXY2AMPtMM+/fRTGszapKWLi1WdCY1t1V7/3c1BT7Y11bxJChA3Udi7V90ftDApxw9JMndXKc1xtoWwowqmr7jYFeFYsCB1M1LN3zbFmn3KBudMmCYyqkk+FQukWRtW7FZVRYPE0nFc8FdffcX22G03IevaubNrTfPk44+z3377Teiffkw3W+6Xrx2NcJwJxHULZ5COAmLKygHtTR7XIyTHMIK1iNOhP6S12FCD2qZscM7kh9tvuIGKBMS8bH6xxx05wiFXV7TMzjdnZ6rAdjuIJ/cdoOE7E+E6E4h8aw7VvIlZO8npK31b2DrbnuZxjtjTPJdTf3HtLrZV7jLOVF3pXlsJ8Av9bMMe4hCLKeEkmIqCdOBIWGd3boE5ya4yP589+uij7Oeffxb6p0/tYt4s1nCdCUTeNYdSZVjkqTjN8zcls/Q0g337WDJLUjbGwDs4altyl3GmZcuWsfUrj2XshWL26fqOoQB5sRzYkAK2wRfLq21nkr8gGtFvNK8R+xg8Ijew4PFLS829kuKJc845x86PSlxLUFqROhMo7Ps51PTeZrpKnC/WWfFAZTNWahvcZZzJAVwcR4c2efYxoLaPJuTksUsLzeXjSA+/mC0pR70xHRjHv/zyC/vuu+/swogHYEfSTUbD3BCNM8lr8HUo4iwOPUWf2gV3CWe66LSWzgt7Tpksb+HFF19UYpiQjtXX6tK3Vka1AbSVZLx/r+ocWMDAtueepyINK1eu1ByHcsaMGTSaA3V1db/QOGEzP5MZ5wwyp694ORR4mjIyruoFM6FA750nhK7iNMC8481u7H7D+rLvt/YSx3RHlIHVodmUaHzL8SYVX3zxhYg7b+Zo1qdXNzMtHyA+GvVvvPEGDbIh08AgJwCbXvRDTM4ETuhkvvQ9sae7Q4Hqql83Z3KLYzKhQO9d2Nh8UwXb/vY/qNiB5pnmLnFHjBsnfh8srWSdlWGCX3/9lUYRCMoXwiX9sJ076c/zF7CfTp0pJuap8cK1EbMzgZgTLseRwHnWtj2YelLXPCSXPT41rupINCzBQO9deOC1yMSJE+1TtHdga9HQfbTN6FtaXyKQ55jvtPq22xw6NzctF/HvuOMOoRuUL2xBCB3w66+/psEODBmiFYCDSbxW8ENcnAmkToFeHWYKYC4Uxp3cnYUZJ1uj5u4LQBMK9N4Foqggk/2+JTQ8IB3i+NahuUy2k5x3vtDpmZsnLl7Kge+//17TlwwnX9CRDAeqfiRx4+ZMIHUoudBT3afcLY5KbJaxW4kMTyjQexcR5GIA4JDC0OuS4f0H2Dp33nmnrYPfprm57N/WJmHAkVOmOBwJCCdf0FF54YUXUhUbVFdlEOLqTCB1KFWGIQHsC0XjUP0WBVKeUKD3LiLIwr+6zJwVKb8ggL3EsROK6iD4iI48lgsqH66utR9To7t1j6hmAqDnxvx8s+aEI9MwyiDE3ZlAP4dyq52kXI6Wh+QJBXrvIoJa4+CxJSHX0Mlw4JprrnHMXVJro8WLFzvkkeQLum787LPPNJkbgxDtOJMfRdpwCjl9hToSfvHiGNNT8L5O6kjuio85FLxbjwyfxqhRNv4CWhcViYUEKtpYG1O0aNHCIY80X9BX+e6772oyLwahPpzp143J5n7jGF/C9BU3hwKbZptfUsCx3FgMDfJd0ZlmjRzlqH2wIZcXZC00/3yzUa5iybSTHAUbTb569zZfUYCYsSCPgxiE+nAm8J/HJ5mvVbCNofoJMrnQE20nFycTjrgrOpPE4fvvz66cNZuKbWzevNnxWPPDMcccE1jIsPHbHXdTsQDirlq1SnMaLwahvpwJbJJjOYm6dAofCMJCT0xfUZwINRPiiONd2ZmCoDpSOG0iv/Bvew8IdITi4vB2uQ3nCwv16UygyIta+4D4hBkWeuITG9JxDurgjGMyoUDvXb0AezOpznTddddRFQf88oUwlSrQi6PhfgwH9e1MoMgPdSi8YsEeT4Nb2fKJw8zpvLvEi95YkJFm7ikQDoLyhXDJLGuJeTQMBzvCmUCRJ+pQclqv9UUptKdeua3RmQT27NKFilwRlC/sUQ6dWCm/6+KHehln8iN1KC+ZyYQCvXcJgXDytXr1ar0gCE8++WRNRhmEHe5MWDIOh/HozQli/Mk8TijQe5cQiCRfN954o9Bv3bo1m0++MAV5EIOww50J7N/SbC+pvTzI5W+i9uYSlfEAtenGINTW1v5G4yQQEwpaQzARKPIVB2AGJ2z5MQiDBg2iop2OUaNG/b2c6a9ndFm4FPmKEzCbAPa8iI9b+6HRmcKHVpDRstPu7RznvetaazrhUuQrRsBGuPRDozOFD60go+FZR5r7LMnzq668kr3+2muaXrgU+YoBiB8JX3rpJWrCRqMzhQ+tIKOihbOnNnWc17ZsqeuGQZGvKIG4kRI9Qi/sKGdqmuP9zT6KXc6Ztj2dwp7asMFxkf9ekWWGE0yfWKbF96PIVxRAvGjoh1icqVVBofgI0ejBg+2tF71AX4Kf3rSMTRk/XtEIYZdxpgHda+i1CaDntPHabKFz4BDn/CSJHl330Oy5UeQrCiBeNPTDYYcd5jg//fDWjnMvrF+/Xux5LvdWwJaMfpAfHQJuuO46cbxXWTOiZaLBO9OIfYfRa3Jiq9mDg0NdN6eAtfb5fNcvP//Mrp+br6UhKfIVBRDPi37hfqADoXkpKWxgV7MH+N677znCgOZlOeyCE4pZl6JituC887Qaxw3d2+0m9qvC/uiAjOP1+G2wztSxnXmBXtit1uy1vbMqQ/wefWCZcKTJI5qx755IpeoOyO10KEW+ogDiUT7yyCO+4UFp4YNDKioLC9mCInPzM+xs9+OPP4YClWsYsFvo07AgJux5QercZS2+kHPkvZCwzuQ3HrR7rfVI48dwkL17hh5xFy9YYOuJWoj/vnK7+RVM8PElOWzvHpXieHBvUktZOhuf2ug4l0S+ogHiqXz55Zepiqbjl9bll19uH48aHPrsve0kZM3ef+9JZmOHFbJZU/SvgcJB3IAtG5GHWfxxKL9gBd591122Dr5xvHbtWvu8T58+ielMH9yvO5FNC9ecWSDO4TTv3pthO88pk0rY3KPMHhxkzyw320wv3ZrJFkwrEsdtW7Vk667IZb88lcLata51tb90ydUO+dbbO7Jt27bZ4W7467vv2MBsc79MOV0Yxyrd4DbjAHsSuIHaWGZtgL+ypLnjo9NfVTprkSeffJKV8TbQG3c6HaoLrp9AOA63hbRwXEk278dKZJy/+uqrtqyqyv7mXUKBt3FcnIize9fOduaBjx80dzoDUZuNHVoujtE+WDbHdLZLTy20HQ0cMaC5+IVs+dnONtJ/3nnHYZ+mj7wFATpe9MNVV10Vlr6XXDqHRJvmFezm4nJWkpsrvoQugeXwx+cViF/o36uE1eQXsEUl5awZdx6kg3B8mV21+0J5NRtnbd6vQsl3QoGtmOexGSfF+8Xs3ftMh/rz6WT25SPmF8PBbx5LZXXtW4jjey7OY5edVsh6dK5iQ3qZjznwyaWhHVO2v1vMTj3a/MKmxIxDSxzpY9m23EnODT+dPktzCJVBUHWvuOIKGuxpY2TTUlaen88OLiljE3j3neK2W29mwwZ1YwP6dmITS3LE3lPS+fAYA9oUFIoPEw3NzLY/uya54qabhA6Oe2SYezW0LChQk0hcZ+q3h6E7kosztW/Tkh0/vlTUMnAkDEieekiJXfuAf24xf9XByn8Mb8Y2LssWY1CnWw5z3zK9y6vWaJLIn9tSKjdAVxILGNzwy6WXa05HG9gAHPmFF16gYuHc9y/MYJs2bRLng4rN7ajRKHeD6iSjs81ByaLUVLEpfvu0dDbZ+vTZMOsbxnCkqSXOT4TgMyIUSv4TCuZ/IHUkF2cS4PKHr8xl7Wur2dePpjr0X70jkz1/cxbbdF02+2RtqNYC7/9XnnCWCfuYj8bt27dTy67OBCJ/Z599NlWPCr9cuSTQ6SBX2ydBkD2vjopDLV282OEQIGqgKu5I+Gbec9ZuehhbamF9Iq0gxez9qZ/0ALBJhzyWUK4hoeDpTGtWr3ZcADCgRyvWsW21/UgbMyhUK33xcJrDwaYdXCp+e3epYivOa8Juu6CJqLF+3ZhCzQo8eFmulgfJq+ebXz2KBz5u39V1/ObZZ5+NKg0siUdh47t6o4cO1b7uCeKLWNLpyqwG9m7WJ9DADtaxbHzfaTXuL7c27ac9QVlujpJMAHg600NX6O+KsHUOGt+HjWrGNvMaaLfW1aL7f8t5+ew93p6CM+E1y1srM9hN5+aLsSbUOKMHNhcN9WvPKmBv3OX8bIYNlzxQ2vmNM2Dz4osvpuJAdKyuFoUttxHC/ufUkUB8naFjmul0kmgz4RdL5g/LDX00u1VZGZtrORF6jPjFfVch74NakIkAT2cC33zjTcdFdOnQnv2+KUU4CJxH6qHbf+v8JuzIMWVsHO/lTZ9Yyh5Y5KxpUFMN5g1yMa5F4ZK2F2Weh/JaIFbATkaG2HVkLg2LBBVFxewdyznwpU/qTG6EE2HnYfTYpEzuKqN+MWtY3340OXkPPlTKMSHwo+HjTKB8LYKtAuefdz4byRvckMXCNjWtxG+X9q209IKI/CYtfo7lXLFJHP/3v/8ltzoYKbx9Iu2A4h7EiCmFxawu3ex9qVTbQOA63rs7PDef7Zdl9vTw5VB8uw/fOh5ifQMZPLNE76RIIL+c+yjlmBAYa/g4E3WCWAlQGbhfvwotbTcir9IBJAdMPjZsZ8BnN9xsWA7lfJZEiONLy9lN5GONbry6uEz07PCVUHx5Xf1GMXiMjxNJ4BrUQkwkeDrQ3nv1Z3fcFvp4oIQMx4eY8Xvc1GPYCccdpznJmbzwNm3cxB575FE287TTfR1KkjqQw5l4m4Q6gU1rk1E3YHgBYa0uWaPHCzkTjaYBPauuHdxfi2DEfkOzKjajSejr6G5EOgfxmghtJtRMGNBEjaaO+Ku9yWXXXmsfA5deemliO9M+vUIDl21rqkWhDhs8RGT+m6+/YV07maPhkJ960sniF489MZuS48n16zWnAMW+3hwj9hsechbLDkW/Xr19nQn5pA7gRujl5OTYdnG+R+9+mp4boRsEOISKts2bs9WlFWy91d6R3J8/xoqTQy978QoGv2isY46TPB5ujTFRSjzJHfSU4463z5FHiwkJ8yYqBUedwos//fSTw0EoP/v0U/F764oVtmzVypV2HDgsxpzUONSJwJdvTWZJ+x+jFb4f5XVRuR/FfWDsc7vkFLz33ntiAFEtaIxT1ZWUsgXKt/QkUfPI4QCMLcmR8EVFpezN5jXiW33qp87mFzRli4vMzff7dDb/eQf17CXOcZ8l5HWpBZhI0Jzp4wfTNMfwYveudbZz0LA9u3Rlr77yikP2yMMPa3qS1IkkkT9a8PVFcS9cMGJv85svKlHboCsvZ1GuaFpuvwIB0R5C7XNTsbmbMGQl1uCkJBzulptvtocXOrduzaYddTRbatVkh5Q4X9lY5fWrWoCJhHEGcSZJvO0f2ruC9a2rEq9SIDtg1GjNCcAxI0dqMjcCB+9bLhYhYKjgoCHmqLgX+3fljrRos1boktV9hznO0w4/l+VNOkUct6hIZU1a1/D4m8RHBmlcNxo992evvfbaPx0lqKBr27ZsFS/ot956y5bV5jZRNEJQnWak8g5O/RA22LOD8g0aJR5e/FKgrGgBJhoCv75ok2PMyFGagzy0dq1DVtuyhi28+BIRpsqf2bLFjEPtehB5owUueOyl7KOPPhL28auGIZ78ve/iJJa0cD3L2f8QIcM6uSOOOELEw69mFw7lUTudzx9DmC4CrOdtmbrCIqKhQ3Ua1ZlkWCurNyeB9ufAzGzxTWQMGahhw4cPbxjOBNKCdOMTjz/ucA63XhwlII+3PvNM2M6EPNGCdjiNhWe4TVVe2yKFLTghycHc0hYs6YqtjngZfUeKc/mIyWpTZ9q4cB3Lzs6+xVZk5jjb4ssus89POukkM58EUw4ay6YdeZR9jpfD1Jmkg+CDRDh+35quC5ykDHrOI8MEspycRZd4CNuZUNuoTnIgf+wB1IFATMt9eN06T8eitimRJ+pAYPLwI5kxZDIbMPJAYW/g6LF2GN7IowckR6RVJs24kY0cNUpMXgM2bNgg4mRnhnpU0o64HxGApiWJ2QFqrw5E70/iOt7OQjtSAg1xqUdhldNLjpJLUNhTSPw4cfwEzTEOO2QyW//EEw6nGc//Q6nzYChBHuPbvv14W4za93Mk9JDycgtYy/zckGONnyF+04ccKn5lQbxKXrh+xNsfDntWO2x8UWigkaaHPHgBteFaa9KbF6flFbJzCorFS2AahtrQDfg+H8LLmzjbYVt48wD5IWWWsAisnYb2bW07w/VVrcRFqg7kRalH9W25S1pGXpFWuHgc4EbPKCzVwrKGTmbfDW4vOLwkj01rofe+VP1spVue06RYsxfkTH/++ad4VYLHkvouTRIvaTF3+8S8AkcPTxLv5lCDUshwClk+ziJLXGwzApypY1vznRr4UWUt+5jz2KOn2hf8Nu/hzJ93Hps1Yyb7+OOPbfnLlaYTAtTRQDldxXYkl1pp25YMlnSqcy/MvLLmmt7ps8506KiQOkuWXiPOs5qWafEpxT0JAMbKsMe56iwYJlBBnQmcYk2E61rbRuj0tybbnTNrliMugHxwPu8osQQHG9bTv1eHl7SvWxPo0Sbau7qGfcHPv+b8nHNEixo2kMvu5T2WT/n5YqsGQzgAh1NrphMmOB3pgUt572vyuVqhgmW7t2QzZ840766CpHn3a7pvvumc8SD0jr5EhAF5NbuL4wceeMCpQ50pNd0R7gXVSWa4TOeljgRK7F4ZGj13mzhYXV3doGolCd9HHRwAr0hUZ8D5wePGsSmTJwuHeYHXQqi1VOzVp6+tjyEDHNft0cX1EYf0aYFSqthnn33YDS6T3dygxnWzlzRlvpYWKO6JC95++22RZ4xmA9Ih8JlYCupIqjMFQZaLo6QaCFwdakD3SocTqY+piePGs1NbtBLO9D+rlgJ67tnNNY7jWEmjtpI70pXPaoXp4MTZjt5XJJQ21PPkXvuzsk7dRRc+pdcIPT04035H4bOv2mTswb1627aA263v6GF6bsuSEocuenB0VkFNqbmY0w/33ntvg3UkQHMmzJIEVAeafsKJ7ORp0+1zOJBKyMQ6OY7zzj3XERfExLs9O5jTf8OulS5TRsIvflxzliCqttxkfhT3REH3NubMSfqxRpUqcH5fSQXrUBAaR0Jcv+18AFkejhJqYLAd6scnU9mgAQPEhc2aeYbtDGsfeFD8ysfWhy7OJOn2quW48c6dUZAeLUCVKuaefbaQYXk2LUA/UptecldeuhFtF3OaBM9vbkqyay8OvHDePEd+KcaXhVbugl5YuHBhg3ck4DOD1E54j6Y6w+ZNmzQHkY60qCrU65ME8PvB++877IbrTGlDJtk3WZWPHDNGLLEOB3a8c+6xj3///XcRdv/997OtW80Rci+Ke0IgHaI8L49V5OezNf/SP9O6fPlyMV1ZOs69Jeb3+SQxzOAGpGexwUN73IFwCMwGUB1l7plneToPOGzQYFsmV/9G4khg7cARIn7bPoNYRe+hQrZ6zRr7xnthv/32s48RR77PA4aMHCNkKpJOvkZLW6W4JxYuxtc3t+pfQ3fDQ9YAZ7cSc5pJUM0k77+jRBow0jlZXra7Q6nEmBJ+MR0Fsyul4+DdE467dWzB+nStMuXEFkbdjeZhPmoU+qG8vJwNHDiQikW86j6hhQhJc1fatnKbt2C5rTtq6VDinqiYcWiW49wLcsBV5bLZyVRNYABvViAdTuxBvsvAtXZCz04979S2WjiKXAKOVbw4V5eHexH2aYG58YWbzfGeocPNGsoNw0eZNY3b7idA1m57ivABw0eypGMX2bYBmp4fxT2JBPw6Hy2rZF3SMxz7CZw71fyyOoW8746S2EXg6lDx4FUzkljSSf6PFZXZ5aH/7hKyRv+sfOv1C2YGDDtcHNOaAExv38dh88RC87FD0/Kjkeu+HNwLLSrMdXGA+OXX7tWLk/eblMEuhXpxKNikBeXF91ens0xrKdBxTYpYamo6O4Q7wlr+H5+04BGhQx0nXNK0wqG4H1Fi1QK9kQ7I++y487sgMo04O1RhXviOBHbqXi5+xTs6l3DqIJJz8vUXvuBZXJ7dxnzsRcVJcxy70sUKeX85D3bc+V0UexlxdCjY0QooCmK3kkiZVxiakSBX0ADY1JTa96O4F3FAcrJ5PzifVW/4ro7pRhwcCvFpwUTLb775hpYNy+ixrx3uBoeNY/4Vkv/zYc2+L6/cioHM0NKRKCDvJ+f36o3+u2CoEaNDIa5WMGFwjTKuBCdSw1R4ySWo3QmTJrPKPubYVaQU9yFKyPvI+ZFyf/92SDasG+G3waobEYcWSNi84CG7IJKmnO8Iu+CiS2xmF4Qmu00+bIojTDIjO4dldR7ABjTRJ+FFSlxTpJD3j3OGcl//1hA3pLQwvFrqh/XcmTr01QojEpb02YeNnThJk9MGtuyl5fbcn80rLmPJ3PlouNSJlbgH4QK7zsn7xpniuJuNsG+M5jyU0KEFEQ8OddnGpjIrNE9cJdW7ranZS4yV4voDoN4r5f41ggD/Yb5ONXNyEks6e5VWCNESQwTUMcCUfY9kSRc9pulLqrpT8wq08GhpNKtxnSUJ9O3bV3WiK9Ub1whvfG54OBXOaQHEwglD9e0MqY4bJfoPca4EjgfFNSuYO3duY20UBzhuYlpqfB0JPPKAdDbywLF2wc05IsURvmoVrwXn3GWf9xrgfPHrNfgZE6ddxZYtW8aysuyvezc6URyx3VBvakUbvQBi4O+b3R1ChZCdej3buNH6tAZHv3qolZKOu4w6UKMT1ROaGvqN1gskTlTRpp85foSaqKpVLWvXVV8eFS2NEvuzEyqXyotuRP1jjKEXgMl2PVjS5Vu0QouK05c4zo2+5vSUaGn0H6vnN8SHxZU1YqfjakMvnMjY9wCt8L1otOuux4+cbxuNaDBI4pzD+amhF2QgNQdy0QmD33Au4MwyGvG3hOZQiqyxNmlEVKC1TCMaETWaGY2O1IhGNKIRjWjE3x3/D/ZWQSObjH9QAAAAAElFTkSuQmCC>