![][image1]

**Gesetz- und Verordnungsblatt**  
für den Freistaat Ostdeutschland.

| Nr. 42 | Ausgegeben zu Dresden am28\. März 2026 |  |
| :---- | :---: | ----: |

Inhaltsverzeichnis

| 28\. März 2026 | Verordnung über die Hoheitszeichen des Ostdeutschen Freistaates | Seite 2 |
| :---- | :---- | ----: |
|  |  |  |
|  |  |  |

**Verordnung**  
über die Hoheitszeichen des Ostdeutschen Freistaates   
(Hoheitszeichenverordnung – HzVO)  
 vom 28\. März 2026

Auf Grund des § 15 des Hoheitszeichengesetzes vom 23\. März 2026 (OGVBl. 2026 Nr. 17\) verordnet das Staatsministerium des Innern, Bau und für kommunale Angelegenheiten mit der Staatskanzlei:

### **Abschnitt 1 – Allgemeines**

**§ 1 Geltungsbereich**

(1) Diese Verordnung gilt für

1. die Staatsbehörden,  
2. die Organe der Rechtspflege,  
3. die juristischen Personen des öffentlichen Rechts, die der Aufsicht des Freistaates Ostdeutschland unterstehen,  
4. die nach dem Hoheitszeichengesetz zur Führung des Staatswappens oder Staatssiegels berechtigten Stellen, soweit diese Verordnung nichts Abweichendes bestimmt,  
5. Gebietskörperschaften des Freistaates Ostdeutschland.

(2) Besondere gesetzliche Vorschriften über Hoheitszeichen bleiben unberührt.

**Abschnitt 2 – Verwendung und Führung des Staatswappens**

**§ 2 Grundsätze der Führung und Verwendung**

(1) Das Staatswappen darf nur in der im Hoheitszeichengesetz und in dessen Anlagen festgelegten Form verwendet werden.

(2) Soweit diese Verordnung nichts anderes bestimmt, ist das kleine Staatswappen (Staatswappen) zu führen.

(3) Das Staatswappen ist würdig, heraldisch richtig und in seiner äußeren Form unverändert zu verwenden. Die von der zuständigen Behörde  bereitgestellten Muster sind verbindlich. Unzulässig sind insbesondere

1. Veränderungen der Farbgebung mit Ausnahme von Graustufen,  
2. Verzerrungen oder sonstige Verfremdungen,  
3. die Verwendung einzelner Wappenteile als selbständiges Staatswappen sowie  
4. die Verbindung mit Zusätzen, Bildzeichen oder Werbeaussagen, die den Eindruck amtlicher Billigung hervorrufen oder die Würde des Hoheitszeichens beeinträchtigen können.

(4) Das Staatswappen darf von führungsberechtigten Stellen insbesondere verwendet werden

1. im Briefkopf amtlicher Schreiben,  
2. auf amtlichen Druckschriften,  
3. in amtlichen elektronischen Dokumenten,  
4. auf Internetauftritten und amtlichen Veröffentlichungen,  
5. auf Amtsschildern nach § 12 des Hoheitszeichengesetzes und  
6. auf Dienstsiegeln.

(5) Auf Amtsschildern ist das Staatswappen im oberen Teil des Schildes anzubringen; darunter ist die amtliche Bezeichnung der Stelle in schwarzer Schrift aufzunehmen. Befinden sich in einem Gebäude mehrere Staatsdienststellen, soll ein gemeinsames Amtsschild mit untergeordneten Anhängeschildern verwendet werden.

(6) Auf Dienstfahrzeugen dürfen nur die nach dem Hoheitszeichengesetz und dieser Verordnung zugelassenen Hoheitszeichen verwendet werden.

**§ 3 Verwendung des großen Staatswappens**

(1) Das große Staatswappen darf nur für besonders repräsentative Zwecke verwendet werden.

(2) Zur Führung des großen Staatswappens sind berechtigt

1. der Landtag,  
2. der Ministerpräsident,  
3. die Staatskanzlei,  
4. die Staatsministerien,  
5. der Verfassungsgerichtshof,  
6. der Rechnungshof  sowie  
7. die obersten Gerichte des Freistaates.

(3) Im Übrigen ist das kleine Staatswappen zu verwenden.

**§ 4 Genehmigung für nichtführungsberechtigte Stellen**

(1) Die Genehmigung zur Verwendung des Staatswappens durch nichtführungsberechtigte Stellen ist schriftlich oder elektronisch bei der zuständigen Behörde  zu beantragen.

(2) Der Antrag muss enthalten

1. Namen und Anschrift der antragstellenden Stelle,  
2. eine genaue Beschreibung der beabsichtigten Verwendung,  
3. eine bildliche Darstellung oder ein Muster, soweit dies möglich ist und  
4. Angaben zur Dauer und zum räumlichen Umfang der Verwendung.

(3) Die Genehmigung kann mit Nebenbestimmungen versehen werden. 

(4) Die Genehmigung ist zu versagen, wenn die Voraussetzungen des § 3 Absatz 2 des Hoheitszeichengesetzes nicht vorliegen.

(5) Die Genehmigung ist nicht übertragbar.

**Abschnitt 3 – Flaggen**

**§ 5 Beschreibung der weiteren Flaggen**

Neben der Staatsflagge und der Staatsdienstflagge nach § 4 des Hoheitszeichengesetzes gelten folgende Flaggenbeschreibungen:

1. Europaflagge. Die Europaflagge besteht aus einem Kranz von zwölf goldenen fünfzackigen Sternen auf blauem Grund. Ein Zacken weist nach oben. Der Kreisradius beträgt ein Drittel der Rechteckhöhe. Die Sterne sind wie die Stunden auf dem Zifferblatt einer Uhr angeordnet. Das Verhältnis der Höhe zur Länge des Flaggentuches beträgt 2 zu 3\. Die Europaflagge kann auch als Banner gesetzt werden; der Sternenkranz ist dann sowohl im Verhältnis zur Länge als auch zur Höhe mittig angeordnet, ein Zacken weist nach oben.  
2. Bundesflagge. Beschreibung, Ausgestaltung und Verwendung der Bundesflagge richten sich nach den einschlägigen bundesrechtlichen Vorschriften, insbesondere nach der Bekanntmachung über das Flaggenrecht des Bundes in der jeweils geltenden Fassung.  
3. Staatsflagge. Die Staatsflagge (Staatsflagge nach § 4 Satz 1 HzGe) besteht aus drei breiten Querstreifen, wobei der obere und der untere Streifen die doppelte Höhe des mittleren Streifens haben. Die Streifen sind oben blau und unten grün; der mittlere Streifen ist weiß. Das Verhältnis der Höhe zur Länge des Flaggentuches beträgt 3 zu 5\. Die Staatsflagge kann auch in Form eines Banners gesetzt werden; das Banner besteht aus drei Streifen, wobei der rechte und der linke Streifen doppelt so breit sind wie der mittlere. Von links an sind die Streifen blau, weiß und grün.  
4. Staatsdienstflagge. Die Dienstflagge der Landesbehörden (Staatsdienstflagge nach § 4 Satz 2 HzGe) besteht aus der Staatsflagge (Nummer 3\) und dem mittig angeordneten Staatswappen in einfacher Schildform, das auf den blauen und den grünen Streifen je zur Hälfte übergreift. Das Verhältnis der Höhe zur Länge des Flaggentuches beträgt 3 zu 5\. Wird die Staatsdienstflagge in Bannerform verwendet, ist das Staatswappen parallel zu den Längsstreifen, in den blauen und den grünen Teil je zur Hälfte übergreifend, mittig ausgerichtet.  
5. Sorbische Flagge. Die sorbische Flagge besteht aus drei gleichbreiten Querstreifen, oben blau, in der Mitte rot, unten weiß. Das Verhältnis der Höhe zur Länge des Flaggentuches beträgt 3 zu 5\. Sie kann auch in Form eines Banners gesetzt werden; das Banner besteht aus drei gleich breiten Längsstreifen, links blau, in der Mitte rot, rechts weiß.  
6. Niederschlesische Flagge. Die niederschlesische Flagge besteht aus zwei gleich breiten Querstreifen, oben weiß, unten gelb; in der Mitte kann der schlesische Adler abgebildet werden. Das Verhältnis der Höhe zur Länge des Flaggentuches beträgt 3 zu 5\. Wird die niederschlesische Flagge in Bannerform verwendet, ist der schlesische Adler parallel zu den Längsstreifen, in den weißen und den gelben Teil je zur Hälfte übergreifend, mittig ausgerichtet.  
7. Progress-Pride-Flagge. Die Progress-Pride-Flagge ist ein rechteckiges Flaggentuch, dessen Grundfläche aus sechs horizontalen Streifen gleicher Höhe besteht. Diese Streifen verlaufen von oben nach unten in den Farben Rot, Orange, Gelb, Grün, Blau und Violett. Am Liek befindet sich ein linksbündig angesetztes, keilförmiges Chevron, das sich etwa bis zur Mitte der Flagge erstreckt und aus fünf diagonal angeordneten Farbsegmenten besteht. Diese Segmente sind, beginnend am Liek, in Schwarz, Braun, Hellblau, Rosa, Weiß und Gelb gehalten; in der Mitte der gelben Grundfläche ist ein nicht ausgefüllter, in lila gehaltener Kreis. Sie bilden gemeinsam eine nach rechts weisende Pfeilform.  
8. Sind an einem Gebäude mehrere Flaggen gesetzt, so sollen diese gleich groß und im gleichen Format sein.

**Abschnitt 4 – Außenbeflaggung**

**Unterabschnitt 1 – Regelmäßige allgemeine Beflaggung**

**§ 6 Beflaggungspflichtige Gebäude**

(1) Zu beflaggen sind alle Dienstgebäude und diejenigen Teile anderer Gebäude, in denen sich Dienststellen befinden. Sind in einem Dienstgebäude mehrere Behörden oder Dienststellen untergebracht, obliegt die Beflaggung der hausverwaltenden Dienststelle; sie können abweichendes vereinbaren.

(2) Eine Beflaggung kann unterbleiben, soweit es sich handelt um

1. Nebengebäude und selbständige Gebäude von untergeordneter Bedeutung,  
2. Gebäude und Gebäudeteile, die zur Beflaggung nicht geeignet sind oder  
3. Gebäude und Gebäudeteile, die zum Wohnen oder zu anderen nichtdienstlichen Zwecken bestimmt sind, auch wenn sie teilweise zur Erledigung von Dienstgeschäften mitgenutzt werden.

**§ 7 Ständige Beflaggung**

Die Dienstgebäude der obersten Landesbehörden werden ständig beflaggt.

**§ 8 Regelmäßige Beflaggungstage**

(1) Ohne besondere Anordnung ist an folgenden Tagen zu flaggen:

1. am Tag des Gedenkens an die Opfer des Nationalsozialismus (27. Januar),  
2. am Weltfrauentag (8. März),  
3. am Tag des Gedenkens an die Opfer terroristischer Gewalt (11. März),  
4. am Tag der Märzrevolution und Demokratie (18. März),  
5. am Tag der Arbeit (1. Mai),  
6. am Tag der Befreiung (8. Mai),  
7. am Europatag der Europäischen Union (9. Mai),  
8. am Tag gegen Homophobie (17. Mai),  
9. am Jahrestag der Verkündung des Grundgesetzes (23. Mai),  
10. am Weltkindertag (1. Juni),  
11. am Tag des Arbeiteraufstands (17. Juni),  
12. am Christopher Street Day (28. Juni),  
13. am Jahrestag des 20\. Juli 1944,  
14. am Tag der Deutschen Einheit (3. Oktober),  
15. am Tag der Friedlichen Revolution (9. November),  
16. am Volkstrauertag (2. Sonntag vor dem 1\. Advent),  
17. am Tag gegen Gewalt an Frauen (25. November) und  
18. jeweils am Tag einer öffentlichen Wahl oder Abstimmung im Geltungsbereich dieser Verordnung.

(2) Am Tag des Gedenkens an die Opfer des Nationalsozialismus, am Tag des Gedenkens an die Opfer terroristischer Gewalt und am Volkstrauertag ist Trauerbeflaggung anzuordnen.

**§ 9 Flaggen bei der regelmäßigen Beflaggung**

(1) Wenn zu beflaggen ist, sind neben der Staatsdienstflagge oder der Staatsflagge in der Regel die Bundesflagge und, sofern die Voraussetzungen gegeben sind, die Europaflagge sowie die Progress-Pride-Flagge zu setzen.

(2) Darüber hinaus kann

1. im Siedlungsgebiet der Sorben die Flagge der Sorben und  
2. im niederschlesischen Teil des Freistaates die Flagge Niederschlesiens

gesetzt werden. Bei besonderen Anlässen können auch Flaggen ausländischer Staaten und anderer Hoheitsgebiete sowie Flaggen internationaler und überstaatlicher Organisationen gesetzt werden.

(3) Am Weltfrauentag (8. März), am Tag gegen Homophobie (17. Mai), am Weltkindertag (1. Juni), am Christopher Street Day (28. Juni) und am Tag gegen Gewalt an Frauen (25. November) sind zumindest die Staatsdienstflagge oder die Staatsflagge, die Bundesflagge und die Progress-Pride-Flagge zu setzen, soweit die zuständige Behörde im Einzelfall keine Ausnahme zulässt. Im sorbischen Siedlungsgebiet wird an diesen Tagen auch die sorbische Flagge gesetzt, sofern die Voraussetzungen gegeben sind.

**Unterabschnitt 2 – Art der Außenbeflaggung**

**§ 10 Flaggenmasten und Flaggenstöcke**

(1) Zu flaggen ist an senkrecht stehenden Flaggenmasten. Soweit dies nicht möglich ist, sind waagerecht oder schräg stehende Flaggenstöcke zu verwenden.

(2) Zur Beflaggung sollen Flaggen verwendet werden, die am Flaggenmast oder Flaggenstock aufgezogen und niedergeholt werden können.

(3) Die Größe der Flaggen muss in einem angemessenen Verhältnis zur Größe des Gebäudes und des Flaggenmastes stehen.

**§ 11 Reihenfolge der Flaggen**

(1) Von der linken Seite von außen auf das Gebäude gesehen gilt für die zu setzenden Flaggen folgende Reihenfolge:

1. Flaggen internationaler und überstaatlicher Organisationen, einschließlich der Europaflagge,  
2. Flaggen ausländischer Staaten und anderer Hoheitsgebiete,  
3. Bundesflagge,  
4. Staatsdienstflagge oder Staatsflagge,  
5. Progress-Pride-Flagge,  
6. Flagge der Sorben und  
7. Flagge Niederschlesiens.

(2) Sind jeweils links und rechts vor dem Gebäude Flaggenmasten vorhanden, gilt für die rechten Flaggenmasten die in Absatz 1 dargestellte Reihenfolge.

(3) Gegebenenfalls freie Flaggenmasten befinden sich ganz links oder, bei Flaggenmaststandorten links und rechts vor dem Gebäude, zusätzlich ganz rechts an dem Flaggenmast, der am weitesten vom Zugang zum Gebäude entfernt ist.

**§ 12 Dauer der Beflaggung**

Wird nicht ständig beflaggt, beginnt die Beflaggung bei Tagesanbruch, jedoch nicht vor 7 Uhr, und endet bei Sonnenuntergang, jedoch spätestens um 19 Uhr. Erstreckt sich die nichtständige Beflaggung auf mehrere Tage, so sind die Flaggen am letzten der angeordneten Tage einzuholen.

**§ 13 Trauerbeflaggung**

(1) Bei Trauerbeflaggung werden die Flaggen zunächst voll gehisst und unmittelbar anschließend auf halbmast gesetzt.

(2) Flaggen internationaler und überstaatlicher Organisationen mit Ausnahme der Europaflagge sowie Flaggen ausländischer Staaten und anderer Hoheitsgebiete bleiben von der Trauerbeflaggung ausgenommen.

(3) Soweit Flaggen nicht auf halbmast gesetzt werden können, sind sie mit einem Trauerflor zu versehen.

**Abschnitt 5 – Beflaggung aus besonderen Anlässen**

**§ 14 Anordnung durch die zuständige Behörde**

(1) Beflaggungen aus besonderen Anlässen, die für den Freistaat von allgemeiner Bedeutung sind, werden von der zuständigen Behörde  angeordnet. Sie kann bestimmen, dass auch die Flaggen ausländischer Staaten und anderer Hoheitsgebiete sowie Flaggen internationaler und überstaatlicher Organisationen zu setzen sind. § 11 findet Anwendung.

(2) Aus einem Anlass, der nur einzelne Verwaltungsbereiche berührt, kann das zuständige Staatsministerium in seinem Geschäftsbereich die Beflaggung anordnen.

**§ 15 Örtliche Beflaggung**

(1) Beflaggungen aus örtlichen, nichtpolitischen Anlässen werden

1. in kreisfreien Städten durch den Oberbürgermeister,  
2. im Übrigen durch den Landrat

angeordnet. Die Beflaggung ist dabei auf Fälle zu beschränken, die nach ihrer besonderen Bedeutung eine amtliche Anteilnahme rechtfertigen.

(2) Soll aus einem örtlichen Anlass politischer Art geflaggt werden oder ist zweifelhaft, ob die örtliche Beflaggung als Parteinahme in politischen Fragen gedeutet werden könnte, ist vor der Anordnung die Entscheidung der zuständigen Behörde einzuholen.

**Abschnitt 6 – Innenbeflaggung**

**§ 16 Art der Innenbeflaggung**

(1) Bei der Verwendung von aufgestellten Flaggen im Rahmen von Veranstaltungen des Freistaates Ostdeutschland oder zur Dekoration von Dienst- und Besprechungsräumen soll die Größe der Flaggen in einem angemessenen Verhältnis zum Raum und seiner Nutzung stehen. § 9 Absatz 1 und § 11 Absatz 1 gelten entsprechend.

(2) Die Reihenfolge von Tischflaggen richtet sich nach der Tischordnung. Tischflaggen sind in der Regel 15 × 25 cm groß. Bei der Verwendung einer quadratischen Form sind sie 20 × 20 cm groß.

(3) Bei Dekoration von Dienst- und Besprechungsräumen mit Flaggen empfiehlt sich die für die Außenbeflaggung vorgesehene Reihenfolge. Die Flaggen sollen im Raum angemessen zur Geltung kommen.

**§ 17 Trauer- und Innenbeflaggung**

Bei Trauerbeflaggung ist die Innenbeflaggung mit einem Trauerflor zu versehen. Tischflaggen bleiben hiervon ausgenommen. Eine Halbmastbeflaggung findet im Innenbereich nicht statt.

**§ 18 Begrüßungsaufnahmen und Pressekonferenzen**

Abweichend von § 16 Absatz 1 ist bei Begrüßungsaufnahmen und Pressekonferenzen mit internationalen Gästen die Bundesflagge in der Mitte zu platzieren. Hinter dem Gastgeber ist rechts die Staatsdienstflagge oder die Staatsflagge anzuordnen; der Gast steht links vor der Flagge seines Staates.

**Abschnitt 7 – Mitteilungen**

**§ 19 Bekanntgabe von Beflaggungsanordnungen**

(1) Beflaggungsanordnungen der zuständigen Behörde nach § 14 Absatz 1 teilt diese den Staatsministerien sowie den sonst betroffenen Stellen mit.

(2) Die Staatsministerien benachrichtigen, soweit erforderlich, die Behörden und Dienststellen ihres Geschäftsbereichs.

(3) Soll bei örtlichen Beflaggungen nach § 18 ein gleichmäßiges Vorgehen der Behörden und Dienststellen des Bundes, des Landes und der Kommunen sowie der sonstigen betroffenen juristischen Personen des öffentlichen Rechts erreicht werden, verständigen die Oberbürgermeister:innen und Landrät:innen die betroffenen Stellen.

**Abschnitt 8 – Staatssiegel**

**§ 20 Formen und Ausführung des Staatssiegels**

(1) Das Staatssiegel wird geführt als

1. Prägesiegel,  
2. Farbdruckstempel,  
3. Siegelmarke oder  
4. elektronisches Siegel.

(2) Beim Prägesiegel sind Staatswappen und Umschrift erhaben auszuführen.

(3) Beim Farbdruckstempel sind Staatswappen und Umschrift in dunklem Flachdruck wiederzugeben.

(4) Elektronische Siegel müssen gegen unbefugte Verwendung technisch gesichert sein und die siegelführende Stelle eindeutig erkennen lassen.

**§ 21 Verwendung und Führung des Staatssiegels**

(1) Das Staatssiegel darf nur von den nach dem Hoheitszeichengesetz hierzu berechtigten Stellen und Personen verwendet werden.

(2) Das Staatssiegel ist nur für amtliche Zwecke zu verwenden.

(3) Es ist so zu führen, dass seine Herkunft eindeutig erkennbar und ein Missbrauch ausgeschlossen ist.

(4) Die Verwendung eines Staatssiegels durch nichtberechtigte Stellen ist unzulässig.

**§ 22 Umschriften**

(1) Die Umschrift des großen Staatssiegels (§ 8 Absatz 2 des Hoheitszeichengesetzes) enthält die amtliche Bezeichnung der siegelführenden Stelle in Großbuchstaben. Sie muss mit der amtlichen Bezeichnung der Stelle vollständig übereinstimmen; allgemein gebräuchliche Abkürzungen dürfen nur verwendet werden, wenn sie Teil der amtlichen Bezeichnung sind.

(2) Die Umschrift beginnt oben mittig und verläuft im Uhrzeigersinn. Zwischen Anfang und Ende der Umschrift werden vier kleine sternförmige Trennzeichen gesetzt.

(3) Ist die Bezeichnung zu lang für eine Umschrift, kann sie auf zwei Zeilen aufgeteilt werden, wobei die Behördenbezeichnung oben und die Ortsbezeichnung unten stehen.

**§ 23 Beschaffung und Herstellung**

(1) Staatssiegel werden über die zuständige Behörde oder über die von ihr bestimmte Stelle beschafft.

(2) Die Herstellung von Staatssiegeln darf nur durch von der zuständigen Behörde zugelassene Hersteller erfolgen.

(3) Neubeschaffungen, Ersatzbeschaffungen und Änderungen von Umschriften oder Ausführungsformen bedürfen der vorherigen Zustimmung der zuständigen Behörde.

(4) Neue Staatssiegel dürfen erst in Gebrauch genommen werden, wenn die Bestimmungen des § 11 des Hoheitszeichengesetzes über die Verwahrung und Vernichtung eingehalten sind.

**§ 24 Verwahrung, Siegelverzeichnis, Vernichtung und Ungültigkeitserklärung**

(1) Staatssiegel sind so zu verwahren, dass Verlust und Missbrauch ausgeschlossen sind.

(2) Alle Staatssiegel einer Stelle sind fortlaufend mit kleinen arabischen Zahlen zu versehen, soweit ihre Ausführungsform dies zulässt.

(3) Für jede siegelführende Stelle ist ein Verzeichnis zu führen, in dem die siegelführenden Personen und die ihnen zugeordneten Staatssiegel aufgeführt sind (Siegelverzeichnis). Die Siegelverzeichnisse sind der Staatskanzlei auf Anforderung vorzulegen.

(4) Unbrauchbar gewordene Staatssiegel sind in geeigneter Weise zu vernichten. Das Siegelverzeichnis ist entsprechend zu berichtigen.

(5) Verloren gegangene oder gestohlene Staatssiegel sind unverzüglich für ungültig zu erklären. Die Ungültigkeitserklärung ist von der siegelführenden Stelle im Gesetz- und Verordnungsblatt bekannt zu machen. Die Kosten trägt die siegelführende Stelle.

(6) Elektronische Siegel sind bei Verlust der Kontrolle, bei Ausscheiden berechtigter Personen oder bei sonstigem Sicherheitsvorfall unverzüglich zu sperren oder technisch zu ersetzen.

### **Abschnitt 9 – Anwendung und Schlussbestimmungen**

**§ 25 Übergangsbestimmung**

(1) Die bei Inkrafttreten dieser Verordnung vorhandenen Flaggen, Druckvorlagen, Amtsschilder und sonstigen Darstellungen dürfen weiterverwendet werden, soweit sie den Vorgaben des Hoheitszeichengesetzes entsprechen.

(2) Vorhandene Staatssiegel, die den Vorgaben des Hoheitszeichengesetzes oder dieser Verordnung nicht entsprechen, sind unverzüglich außer Gebrauch zu nehmen und zu ersetzen.

**§ 26 Aufhebung der bisherigen Verwaltungsvorschrift**

Die Verwaltungsvorschrift des Ministerpräsidenten über die Beflaggung der Dienstgebäude des Ostdeutschen Freistaates vom 6\. Dezember 2025 (OABl. 2025 Nr. 5\) tritt mit Ablauf des Tages vor dem Inkrafttreten dieser Verordnung außer Kraft.

**§ 27 Inkrafttreten**

Diese Verordnung tritt am Tage der Verkündung in Kraft.

Dresden, den 28\. März 2026\.  
**Dr. Karl Honecker**  
D e r   M I N I S T E R P R Ä S I D E N T

**Mia Wollrath**  
D i e   S T A A T S M I N I S T E R I N   D E S   I N N E R N,   B A U  
U N D   F Ü R   K O M M U N A L E   A N G E L E G E N H E I T E N 

**Emma Müller**  
D i e   C H E F I N   D E R   S T A A T S K AN Z L E I

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJMAAADICAYAAADsrNMhAAA7b0lEQVR4Xu19B5wWxf3+AnfcwfV+x3Xu6L0f5eCkqYAKGiVWMGoUNIKxADYgIWoswRaMSVTUWBILxBaTqKCxEZNgN1bUaEwXE/NL8o9x/vPM7nff2e/O7rtvueNF7/l8ns/uzs7Mzu4873dmvjO7r2V1Ix62SArJJhbejW5ExoeSQuywuWuLEhR4A4vXjQwHKm0jD+wiiC0Xx0Rk4pL5rrD2BCDynTywG2aInTd7KmybZDGL01nwCSeIKKPVdZV6kGU/C2UhZ4zttpDxIBpr/JVGXLG406xBh2VbQd8149ER/OVI68kxPeiwnB8Wvy4R5y3bUnXDwc61x/sfVBCtWMWlqwLXUb78WlGIdGgWeaYpQOUFofJrBbEoX6Xp8Gbz+cO6Dx/yP5wwwsw7Dy9dFfghv0YytNLUFOOHZSUh7FED0vY89joslNxlJfHQiE4Tkw748k6Gln0/qWIpzzcRyvTbrfT9yPYeODfveyCJUKbfzLJNGIk0sWG00lOJvnwTIayT0znfY8DF10rOcIj9bU44HHadgQ7+IJKhlXoFLuR5Jss0WMqdN5znzzdRdqKYmqyYLrAlzZBe1EBA4NeJQoDY37bJLhhuzklMSJfvZyV/CMnQGeFt5pkngK08z2SJZ8YzTxC+PJOh0+dKFzqc7WhJVxfYkmawdQYgGNXGr1hkJLnU2aYDaen0glZqZfLllwp55okgXc0tyPNOAchrG0TDr6HTY5UPmu6PwImMnSmFdIxafPknS+TFM08Al/P8kqVjxZMGzy8VyuxW8vyTgPrBh/n+tOt57t0XIYg8YZLw5ZsskRfPPBF0jPPnmQytFMvB80uFMrutPP9EEc8asest1dNG7ojCL2Sl7iDz5ZsskRfPPEHs5nkmSqfP0MQzTgTFBf58k6XMbh3PP0H48gzi6IGG598UwZwRcTGePkFs5nkmQ8suR5OWL/ZDywazbdlxMK+GOS/Al3ci7GFZHzn5rHDyjvKMPOeRR9jUSVSmwxufyKjSCrhPX8Qgpto/ADAS4/kmSst7I7uc49CyUVpUnDOMBlfSSMVExOFhRFgUy5nb0+/JyTcQ2kT2DU4Q+qK+/HVGmS1w8kwF23ieQQwbTa9MZD7Isr2tqSBu82KFPFynEtXCNQwMKNyxPIHg+YDkAoHJ5udAnONhFB7nXCD0uJoLZql+L5yIw8MM+TR5LpQ4fPkGEXF5Yh2+BEFEXJ44DtAEcPjy5dfgYSAtVDP9UhHOrsHhS6OnNfVdTGkQBo8zDwed5Smh5TCVnawVD9evycPYNZWvhwFTV4nAl3cQrTh9s8hzQzLuszxxHCgHFyyHMynpkudNDBqWIo2pMuicZXtlTfDF50SconzrUx7Gj+NZcceJGbTeKfDeqOnl4WBQmstPU2kwglNpyQHt9J+26xeOAF/+JsKdxBP6EGTqORFVS6bae+3YBF8eID08U59l42n+MMSN10HUltjqSKrTD9cB8lp3gv9cPKL8rAwWVjzweJy4nmlAZBquIx7iBzWPVriYlGebhfnyMNGQzghfQk7EceKqPgsJwQpxGfTsYf2d52PI0xO2+Xx/RUapDNBxYTRpRfDFiUduCZLJw/JaJ9/5INK1nftQnV29GXQsX2iZHMsU5mRW8bSFh0sQGGVUaTHfUhBG84Sclt3EmcKDzDqw02RpdOpTChbLnx9HIdLQxU2/6jCarhf06w+jXgZTnvFoSgNrFM86g4V51qeWtwXh8KVBmClcp9G3FISw/kDY4i0rxPMa1FkNommuKp4YOS2tIk35hRFpeRhoao7DmEoZQNM9B5XNRP36BvjiO9YsdO4U6XhGYfBloGcU1Pl1+gimC4UWjjOowiznV0NE5QSVRYuvEFaReIA4rzOnd7R4YfmCehmC7ouIvDTfl6LpTRmEb7/GH26i00yaEPicaYDEw4mWedQYCONKAgybeT/CRMsvKF+cIGJkAjNuarcTtW762h5ThzYe9XKjPFH7azwP9yEYzsej6dnpE/MoF0QR1uxZ3k54hylPTsQxNetJrdviE6DUEeSZm+g4z7Zp2fni6IRAYdV0K4M0dJzItXUiTdQyBBEVhQ5qmAUMo6X5YoIsQTzq1irRvh/opCX4zpsY9MxZXpHhyygRIn2qedGURwoVqZchKddAKuTTTskIIR20NMtksjaJ0Io4iuOIvJLARDbh6DvfFbTYvFEyTV0qxH3r18cxj9MVtGIjupTWbyU0iuOAeYevJ2pnj1PLKm3LY6MyYPbcF6+z6DQTfCpjO4/X2WTW0Xc+ESK9lldi0Duc6HhRJw9ORHk6ykhmHeUV5m7oDKJ8dG0GX9wg8rhRLZth7byLqHmki1YC3Q0nrjIg/JxzfrOWV0LwZQZxJdKJtLwecd/5RGgaIgcR19Kua8JuPsDgtJwHy8K2hqWjTqvlt0g6lloRn4VpRJsonesRfOeDqLl5xNIFSY7iNPgukIiQQJ6haUY+jLwM/JjTWZbytveqofDlAcuhLXbzXZ/CTb9eK84sOoOqJJ4HkVYe0DGefZiQTUR6fk0eJyoNeSUEY4Y8LIgBs8oLV37RH9dEZ4LVMwiQx1t79rDeDWoqrMRXMrgjPMt+WNv1k9x348TRIUa2Wp/gHJp8di4KfPegLV+BdXPDnfw3Rx3ZOnlwJD2ossz5JQQ3syBHYhCRlmfmQM1Uh83COxYGE5SelzWRTstHPWxQOx82D2UElptY5rL6Bg0BnXqAly0qVL7aKoe39ZO6k1ZzwG4Ne3bOKoLtWjYeBP0Q49EKb7ojoclyHhT/lYbRsSrrPDn5sdnShKAVWi/4Ov2c88EKjibJVNr0oHS+sjnlM00lrLSS878sDVlI16RbIWb5nuVNpCbIeD+ohP12ThnTgrirCHQ6Ixk83EigfhitG2KnfUNpKzhvnjYVFFO5HGukXz+d1wGCmmbPfTtLTjjcKQ/s85Mh8NVbGFPyL3GQC4D/Gjgt+4aaWPJ4UPla5nU3Kl+YeG3NVPpuLBiee8JWt8yWd6qoU0CrBSxvWdaxaMCzjtA6+Ik4WBfBtdMpz1zP1DgBmOJF3+YBAE0qW851teuErZtKFTfo92Sq1HgvLaQBnmdKfVXs84gOgsJDETQ6d5YBu3Utt7tZ0pTAbwZWZLtz7A6TtfPpgGekpXdGnZWBnYFifUbe0ioVD1V/+DjHE6cJu+gaEDKaWSqTaRlwKqC5QqcZI66j87i20/HvoLB04HKYRMcpt5SfdIBz23lgCnArjh6m7kV3VhGmEzcgzyDxkID4Mc8kRazUR8yW9iPupGuG1VlnXM9Fp2bO4D48faWhHg46gkpHk7eTuz0sdi0if+HCWUjWwfJLBh4vP4RMoy7dKjvNTgdPnGYUU1msTqpv/WbW8ZNpRLH+8CytUvFwubVwKnMtzyQB3MDnDTEgCBo+mxbIWfYDNw0gouJDfj1Lu288c77Wi2eQZqjrOC3R9fxkOvAy3ZDTZ4nnz0gKelMD8pWdpsrU5sQSqdAOy2B9UHFRRzk6wyZ3Q7DEMuRlWozH4+GY5ZUuuEusrc67hu25pgs50yVreaQUgObK88CC5vJ4PKIzRAaR1wxP7jbUNwFAXlkgmjqyihTPxLAyaK8NgbwMTZb9bQHjjwJEubilBCFWXmbkY6X3R+25BtbB8whpw4mLvG6BJC2CCb6HB4ZZiKA0OlFW9Ll402gi8tMr0VShFE/fj7KaAdePUgZdzCaa7tlxqu7SH2YSWMtXgVqxH0SnwXhDmkVIVFSBgsE5HsaJOFEnjoNI0xB6GPLkYUSE6511PrufLJFHlC/DBFlrx/eVqKjUJ4B4XvSSAs7xBOmEuhhtOTVLBaKpWWt5v+KrmjL0i4Icn2H5BxHxw/IzkcqqWxZ0vKn5CSoDjbJwXm8SkI6P9KJQv2YU4poLZ/jDiTT943CbZQtGrwN1LsgCIn+yUlYaJnfD8CwuAuXGm1rBQ6f3wED86vjw20RUSKLCAGXZIq2ExBJkctLx9EEOyyAijj7NQp1weJB5XE6yaEHNaRghPt5/MhF1gOdOdRDUCuik+07n5G4Qmuiipl9nKqT8eHhUQiRYmtE23BLZWZ5fp5H6AzZd1/TgTWGoMIgYoqA8+bU4q8vsskJ0UX5gJuJ68X7QiRDWTn8OaZ3cDQJv13Ec1I5HpczW+Bo0LBQeOnP3u2JA5Ubp2IYRefEw+mBGEHl8WKRUykEDBTxL7TOJLrGiYquho48fIKxUKv3GoB+xc+1Oh+/CID2EqE0UVdigRv/DS4dIotBkaXB9bm35PaO/wUdx3B/WWdTmyzxiwzaRHzW9FBL0nK00T+4GwXdhndSBQ7wg4jyvjM4gNX1oDrT1Uh7q8YMqg8cDYUX4D4fnjeYP10UZYFmSfWUsEVKzHUSI3vQj4rQ6f8pGIfBFPlI70eTJTZbU5AWJQm/2cMzTc/JfJNJwcejneBiF8xEdj8OJMqK/gx8TDVD4vYDow5iatmSJ+9WvBaEHiTvdqxNCcf+3vJWKQgZVRFSahEICSTRvpOVhnDwO7wuGxQ06B2HF+/HgnriQ45FGZfqzAdFXChJEVKK/5yyHVtQMQpdgJ0xlog9EJx4AF06qeepEfjyMU48TT6xh+fFz8ZoQHj8Vmpo0CCzZESLLs0vgK0AQebMX9qATyTceo+Slx4n33zFh+fF7guXhcaLmlSip6eLhIATlzJ8qYkScSLNpde7KEBe+C+tDaZjMRN5k0QrvC0uWUZoS/XpBFWKKy8mvExY3yvlEGOU+ORFft2hoIbglc9wFXQZVEHQkE72ZIGK4na688LC4xeBE+Wl/bxVTOvPC82I+rq4DV3OqJP8JD0+GYeafaHWLyUjkqddzlyCZSc14tBJ8OBA0+ZJMXnIixAIril8fLUnRr5VuMVFTQkN/fbTESX6oZEZl8cqdDJ1ydTl8BUmVpjzD/Eswy+Q+4JUaj/q14lWKqVxEft2wuCaS8FAGfn/wBYUJzTQFlSqtgNfOOhu+giRDPChaP6QzSCCmsGSol39PisnEoDwwsOGig0UO+/ZAorS6yPPN4fkOQBgxOuCCwbCVV0RUJptOJ8pA+3uLmOIRlkr/XxpYtijLYYjOKG/PgHfCaeGW5dwM+gq4QR4vVcYbqUUhykf7nxUxmYi80FVwPuzh0iQy59weg1u4eBUc73wiDJqQTYQoM+1/1sXEw4j4kfNmkyp2T8BXwCAmEjce05GXnkemiSlsnjBRBi3P5XQmdzdrddvleDvevBbRSsNDJkbNi9wGaHpNrgOKl24x6dSH/vEmgYPyTIVR83LKu0exLuqvyAqpkESJvDDPFOQyIJLbAKMg3m/Ty5NuMfHz8fxNEDoEH+YGSIa8bGF0yrLH4SuYiYnM12Guj4sEFRHkLkiGerk7U0zJEvka+jNqoV9UwSXiWLb2kH+Jw1ewINKDh1Vxvr3oEhYuEcGlSr3cmSimeET3wuTshIUjK5xIWaw95F/iCPQ36R+NAtM5ogvi21st8aMLLHHBMvvB9qvwlmFPER3hExZa4ntn2wL856P+sqeT3LLB0gdZtC5dWRkPJx3sfXAQTdSOeRT+/Cq7PzG4yV9JYRzeYokvHWCJ76y2xG9u8ufb2USH+6dXWuLrJ1rigHZLVJX6yxjGeVMscdNaS7x5tz/vZAmR8XVOzn5GwFfgRPizK+0K75vrf5jEXr3sXxmawU+e9OfxWeRrd1ji7KXxLSt+MBtOSl1wVoY0c76CBfGjR+xpldqQB0STm2iuePpu2lb6qP0t0bOn/9kRYQVh0XjaMFrBXzHuUvgK9sT3/HNxOscPscQ9l/rTdTM1/vcJS3zty+6ncHxs7meJG9f6+2td8Sp4IvAVHFx2iCU+eMB/093sej54hSUmj/DXEdijh/tfMRmB2yxDIbu5VzFj0C2mvZ8ZAyWmww8/XHwWMWvWLGH1kA98/Uz7wdcUCOuQocJqLrGPN8y2SRWD8zP72/uT63mlZSozBp99MX1NsrSPsJZPtIWkCwjbktxYxeAYQtPjHDcudqwLL3OYMfjsiwkCgJh0AZ0x1RYNxKVXDM6NrTGLKTerW0xx8PkQky4kbCEias50UlxdOPq2W0yh6FIx/f73vxfbt28Xf/vb39ywp556SouRXigx4YGbBAVOaeAV442PPhTtd4spLuKK6YD99xdf+MIXxMMPPyyeeOIJ8fzzz4tf//rXYseOHeK5554Tr732mvjPf/7Dk/lw1dfqxO/nDhAN8ld/dmupuGN8rZgmmx8T/vGPf4hVq1aJ6dOni9GjR4umun6itLBA1BQXian1lWLrhDoxtzyPJ/PBtUx46CZBBYnDlCZzmTGIK6bXX39dieAcKYBn2pvUPjg0L1t8d2S12n9/TqsYN3ggT6pw9913i3++0Fvx4dsGidLePcVRtYUq3djC3uLg1hpP/I0bN7rXAB+d3CAOrs4XS+oKxWgZfz8pIoSjXPHgsUzUbwJ5M3aw03dC06dbIb3zjXMnT5LCtoR4c89SlXVvFBOwYNwI8YZ8mHolc74nBXXLLbfwpKKxsdHdf+yxx8RHH30kpvbvKW49P0fMrcgT3xxSEYssMa6swJf3GzNbxM4ZTeLhtgYxtixffPjhh540QYCY1MPP6WV3utGsQRhrpseERJUCsaBZo3Dw3A57q3XKRw/1V25X0y3z3igm4Fe/+pWY2NIo2uRQ+oSGIlXJJ+zXS/yyvVHtw2rNnTuXJ1NNIwCL097eLhYuXCgGlRWJsw7Ldi0d4eOPPxYTinJcEf3s0hzx5qwWtd9WlieOOeYYN24UkJgmY33Q+fvYPicSyokT7I748CpbaBATWShdZNinvtORo3wVuyfolm1vE9Mnn3wiLr/8ctFUXyvOGDdQVezP2+rFOQNKVdO1bP8s8ZvpTdJyNIvbbrvNk/amm24S/fv3F08//bTqfD/++OPilVdeEW3FOeLO9TnitP4l4oWOZjGkuclNU1NiN4Fz6u2m8ezF2ep4ZnlfcdNou1l9saO/OHHsINE2dJDo6OjQrugFiQnsg6UyJBISFCzVWdOEldc7FobzUmRupVG4w+23+iu3q6nKtbeJCX2bV/bpL+6dUCsFkCv2q7D7K2Cz7HdQX2iurPh+OVmetPfdd5/nGNiwYYM46oAqUVNoiaKsHm5eEKyOAfk5YtsmO2+Q4hFh0TaPrhG3j6sVN2260pNWhy4mtxK4oApyYmGyT6T8T5KIX1zoqzhfxe4JsjJlDELFtPP+rWK7/PWiAt+Szc1PJ9WL5j62pQCv/WqOGF+UK8qyLJ40ENMnThBPT4t15H8i8zRh7MgR4piJOeLlfWJ9tbUDy8W+U9vEuPpqMb61Wfzzn//kyTzgYnIrggtKD3NEZUqHzrc6P7lerDzWX8ldRbece5OYOAryYpbpETnKOmRqlpjU2iRGD4r1e4IwddIkz2gQxChwXksdjyr++Mc/ihtvvFEc3a9A7JrdIhpkBxrxD5V9l5NaK3n0QJjEpCqD+k4mQfXq4R57Kk9r6vj5rqYqz94sprGVxa4IinpZYqfsJ40tzBErhzeIBx98UJx99tk8iYvFixer7aTaCo+YHpR9r7n9+7HYQjRVVSg/1hfG2VYQZezb01L7o2SzdN3EJp7ECNc1EESIQu+UUxhtjxhpN3uZPT+XMYgkpkP7V4l5lbZVGiMFNFX2nzYOq1JN1GHSWpx77rlifkVf0dLSIm699VaeXKFPjrfv86oc7o9p7e+JM3efGeLg1n5i1tiRorqkWLz/sD2yu3xYpdrWVlep7SzZGX9ndmukZg73F8qvOxPBJkGBEBP8UtjHqA/naCoGk8TzBtr7EBylofhdw4xBXDHl9ekjHnX6Ta85D3FgXrYYnGeL47a1OeKggQ0q7hG1BeLQwY3eDBxMkw+ehHTn+FoxSY7opowZ5YlzTmuZGFNXrfZ/MKafuOE8+xr9+2SJ0/uXikPrS8WkkcNV2P5S3LdNafGk54gkJrgIICasLoBQ1u4jrMZiYR0/znYdwDqRUHAeYSQW3VqRAPWJ4q6xYhmDUDH1lUIiARwzb67461//qlwAt4/tpwTxDJq6RkscPaG3mD9/Pk/u4ojDDhU/k02aLqZ62Q/CtIwJzbKZWzA6W7zU0az6S+2ysn84rp+4S6b7yU9+It555x0xtqpUTJYW8hc/fZAndxFJTCAEhC0JAAJbPNz2QZHjkpo6PR2OaY0UnaMlLBAchKgvcekcZgxCxQR88MEH7j7ijiiw+zFjCnuL01tK1f7Yxh5ifmVfMaipMZbQwc033+w2cRARtvATFcs+UEWBd35t/fr1Ylq/MjGiopdYNCZbbJHx0ZyOdK55lrzephG25YqCyGICSQwkHvigVrd7fVB8pQGFk9AgHMqHzvHrpJ8Zg7hiIrS1tYnnpVWCiwAV21emy5eCIIHsLy3Jc7fkipvG1IgHD24X0wa3qpsla/SzNruphN+K9sHyLEt8tX+JeExWXqtszv74cK5YKPNCn2hxv0IxvihH9CuxPe5gR1kfceaZZ/LiGZGQmEBUPqZeSAi6D4qaL56G5vm4iKh/xeOnnxmDyGK6bGilqM7pqSp0ZIMtIHjC17SWiiucDvKtaP7W57rORvRrSAQgrIx+DMJvRfHHNfUUv2xvcvtojbJiRxbYVq1dWixsIWgIMgoSFhPIRaGHQSCmzjXO0yQxt16dz4xBJDENHTzYrdSrpHDm1toV+5YckVX27imuH12jhu47pBCenGbP1WGk9x1nVUEYZ0pL84ST5pwBZUpw00v6KMFMKo512mdMGCcuPfoLar84q4cY3mx3+sMQ5GcKY494PihqBodU2HN5FIdT62Pxa6RKVZ69VUwdlYXiwsG2j+ilZ3aIX09vFr/dp1kdV/XuIe6bWKd8T+hDIT9sT2kqFt8dFRMTNYd6E6dEIsWE9U3rB5WLkiy7WURTlivzGdA3Wx3jeuj4Y67vG7Icb8zqr/pd8ZCMmFRloXk7pc0e9kMQmL+Tgw1XWLT6ANSbOaK+lKVbTDFgpn50oe3vmVRfLc477zy1v6AqX22bZT8H2wF59uhrWH62si7o7yyXgjqsX4GyXNgiHkSD7fENxWKytECTZad1nOzMqxFebi/R5DQjiEPb4Y5VHOn4pTDFAjfCpIHxXQO8IqLwz8/ISpLlsdobhXXaFFsUEFZ2T3vkB6sEy4O5PLJacovlKWof4aDcv/w8f/6pUl1zbxQTOseoyHVLj1DHiI9jOC+xbSy0+0V1ufaUx7dk34riTCy246DJwhbN4L4VeYo4Bpucub5qaZUwvYL9nzpuhIYG24od3s9eSYAVBgRK/+6777phHMmKCbz7Gst+o4X7oGB9yQeFMMdK7XrUqVxmpZYe4s87Varr7G1i2nfffVWFLZkUcy7OKrd9T/AxfWVghWgqsoUx1wm/QDZDN43pp/YLcv0z/py4PrawTFdKi4bR4ruzbVFNGzdGTdno8Qmf/uMj2eGvUU3g+++/74brSEVM4KwpsrLWOe/ckUDgg4L/iHxQaNKklUL8jefaFexOCFv+PNNBytthxiBUTOOKcsU7r7zkCdsyoU7cP8m2HBdccIErpuuc/lFZTpaac8M+1nA/N8PuWwVx9uRJanuv7HeNHj7MtU4vSWs2fECLuHTZl9TxvhV91RYvJERFqmICC/A9S6cZczvfE2vt1ZrwQTlC24z/hNPSqXDLWcbieNB53smS8naYMQgVkwlvyl9ijTOLD0wtsS3So1PsEVnbxAlqJIf9e+65R5zYaPebcIy+Ezk6aYsJXWx/JC3TpZdeqjrWKq0U1zEHLVDXeFYKkuYGJ02apBcnFOkQE4hnpEQU5INCU1dTILZ+x46/boUTX6fsG/J8k6W65t4upj/96U+qQveXVgKjKwArIBFGFmjFihXKemH/rbfeEi3OiAwdbvSZIKLhBbGm6+2331ZbeLfvuOMOd5kK+mqrF9rLgBdU5anrXSz7Y6OHDtaLFIqk/ExBRF8JoujpLFEB4UbARDHOO4Jx458zIxbvyFH+/NLHjEFCYrrkkktcEUxsthe1YQKWwsAnn3xSnDfA9kMByF8/zwlgC4Fi6uaK4bZjc4gcFT51rD3ft2C4HXeEHNU9s6jNLkwEpFVMxPWyDyXF7QpF/phcC4V5Ojg2aWKYOumnT/Xnkz5mDBISU21FuTi23p7awFsmADrOtOgf/MMf/iDOcAQGlBXERm56MwcXAaZMAIz2sKwEwMpNnK/NzRK7ZsWG/q/PjF3jX//6lxsehk4RkyyfxwcF1wHCsW+aWkGY/tYLrJQeh8KJiU8MZwwiiwmrH+E3OrAqX02jENAsUX8JUx0AmrzHptoeauSPc+g3QUjwQZGgwN/85jditjMSBMY5C+hWNtsuCUKT488a1DdLjB8/3g0PQ6eICZzWaJN8UCD6U3Ad0ByePulLhAA1H5Qbjn16AyboLeNgZgwii2nY4EGuAOZPnuiG4xj9HWwXNNsz+oeOHy6e2/5zZaXqc20RBLGm0n5vbuW8mWqLV6qw1OTaEdVqizdeMIK76bvXKk85XvzcOGOUCovHsWPH8gefPsI6cR/UwLKYD4qWouhpSHgQFfpUcDFQnM+TZbpS9mW+O9LuzxBeffVVdTzS6VBv2rRJSyFEeam3PxXEhx56yE2zdu1a/rAylxAStkvH2EIgH5RszlU4FxORhIN9slI0BfNZt0xYkEYVv++Q2JwYXl1C2IzSWDNF+OUvf+mmWdVSInLlKIjm5+BovOfSb7jnB9fVuOlITJkAlCMuIQCM9MgHBSHB6sAHBStDL3byNCDSmFYhJMaMQSQxNdTaHm2QOt7AnDlz3PBvDC7XUgjRNzc2/J83abwYUF/r9pVOHmn3reg8ykBIt5i2bt2qPn6BPPE2MYCXSqNAlcPg5/H4fMj3hIrVLQ62cB2Ql5wqX3cZjNGW+KJZdL5Wx6/B6ea1N4rp3AH25OycZu+bJEhLgsBSWh2lWfbN4hycl/OmT1W+JhxPH2yP4jAlc1pzsVrL9Oabb6qwVMV00EEHeR72jBkzPMejRo1SYopyDRXHUJk6P9zp5A1BcB8UCQuEu0BfS65TD4twTf1+rAxCXDE98MAD6k3e//ztL/yUWpuN0dyx+832hJ9++ulKIHddfokYlme/6VtZWqJGcnADnNE2TOzevVtMLOkr/v73v4vHflQv/vFCmYqXqpjwTQOk1wnwsKKiIpbSD5XWUJkmut/OrCv0i4S2LGznvVo4RnOwWhGuye4lYxBXTGHQP9qlA0K6aK33BYMBTicdvqbXpKAqK70vUyLN/P2nBorp09+/K/614TS1jYctW7bwB25kPKg4hsoMohrd6T4oXTz6Z3zkebwR7C5ZIaJJjHBNdh8Zg6TFdOKJJ4q1KyvFtddeK/7v//7PDX9yS3/xyiMt6l26wf2bxOB+Vao/1V5qOyNpAd1zM5rE0ZNjQ/eXXnpJCQqf4MExx4JKx/FnOKfjH1Prhfj7brWPT+9QGhPjQcUxVGYQ1TKUfZr9PigIiXxQuLbsH9EHMHDc0WZvlxzsz9NEdh8Zg6TF9Oc//1l9Lqe60l7zDbQ0l4m/P1+i9seUFahJ2x+Os0dwuA62GNFh7dNWucX825n9S8WGQeXqy3Rz9hkozl7Wy1jRCCMuWbKEn/Zh27ZtirzPpDMeVBxDZYbxhotl3ism255yLKKDmGhBHVwHuLZjoUwCUctX0NxJAfK8eVyHGYOkxTRv3jxx1GGjxKeffio2rrMndSEqvFuHsA2DStWXU+A2WDJmiJhfmSfF1SxelU3c1cMrxSPXbBQH9CsSc8v7in3L80RuTo7497//LU48wrZAHBAGwolhWLp0qWhqauIP3cd4UHEMlRmPKn8Ihr5bAPbN9jZ7so+0+1ktDebvEE5NpLNGykR2HxmDhMWUm5srPthRIR67c5jYet0Q8b2LW8Sr2we4b5jcelWTOP80e7RGwBflYJVekZaK5vHwKjkBa7ufuKtJPL2lItAyAQgnRoWeRic66vHA0yRMXTz6PrZwVsLBiX2+jtzpO0VkxiBhMeGjqJsuHO4eT2kbqkS0c+dOdQyrdOCBB7rnf/GLX4hLh1aKxTWxzwue2mS7CPTmCj4rIKgDDuAaOEeE9QkCrJMelzMKeJqkGCQojP6wDx8UfY+cvOEUD4QvCtvgf0zIGCQsJh03bawTj9w+yD3GpC1eE+/Xr58Y2Nwovjqo2l05Cd8OiQlf7D3LWVu+dNGBoqysTBx//PHi5ZdfDhUTgHNBXLlyZdw4xCjgaZImxKH7oGifzun78JrT33GgyeMfufczY5C0mJDurcdq1T6WhKyaMkKJ49g6e/E/cXmj7c/JzcpSX4ubVtLH/XTgzDJ7YR0RwjvVeZBhwHkTucMyjBBtPPA0SZP7oGhOTxcRtrx5o+bPtAIhxoxB0mIi/Pa3vxUL60rEKY3F6tvdv3MsERydhEWLFokXZjSLxvJSMaGlUb1lAusFvPPD68W3htrLTn4rTX5tba16SPEATzbi6USzycOC2KViArGgDm+7BPmgsG/6+w1Ox7GpMWOQspgGOK8jYbSF7ZelqICBAweKaxbNFM/OsJfhAo3lZWK/9ini3+/tEk9NaxQfLBorOqa3q7VSL2/epN5MIT9UFMTzI4UxCnialDm3VVhTG7w+KIzy9K+w8DQUTlbLPzGcMUhdTFX2dwb23WeGeGhybNFcpfN2Lnj96hUqrDA3R0x25uX+uOUH7vlFc+3O9+6nt4s5WAZr+Sv7f6+9KP61+jgerID4iTIKeJq0kASDZg/78D/hdSpMGEMwQasM0FHnzaDNjEHKYrpo1Rlqvk3/xwB0sOc2VIpFjd4Pxs+rKRL3HjTVPf7kD78T1w6vEuMHxVwJpg44RDSyyBZZ2AflN2/ezB+0kTfccANPaoQqh8HPkwpVGSAO3QelrzzgX1vRVxmQL8p7PxmDlMUE/Pgb54k/nXSguPjii9X/ngSBXq6Ec5Lj6mXHim9/+9tGMbVXFHoeIEdUEQWlD4KKaxBEqlTlIFGQUGgf83vYh8WipSv0YoLpg2MZhLSIKQpytW9aLjvKfD1YndEDW30VzqdEaDQYxcttYlSouAYxpIOqLEGC0j/aqk0Qq3T+T/ZkDLpMTHhnTncDfPOb3+RRFEyWCUBYuhgVKq5BCOmiKg+EktUzJh7ug3K2iI/vFnRbJon/fvCu+lThQ5MbxO43XuGnXQSJCUhk6B9GvCgaBYjLBZBuKvGErYMCtY/cY2UBu5+MQZeJCThwxECxcHL4a0phYgJoiYqJtOCNh5sYBSqeQQDp5MlHW/Z3C2giGMQxXAj4SCvKu8H7LQN2LxmDLhVTFMQTUzwgbRRGgYpnEEC62dJoC0aVDctUsI9JYCy0w2ek8eKm7DvR53nYvWQMlJgykamA52VimIuBwNNkKDMGrpjE22UZwbUr7aFxKkBzR/cVxCj9plTL0ZnQ7iVjkFYxrT652nPcWO+PE4+pigkWp7i4OJKg4iFKnD0F7T4yBmkVk4Kz/4s7S8WFF17ojxOHqYiJ7iUq4yFKnD0F7T4yBmkTU2NDlbrJ+XMa1fG0qfb3CEpKSnxxw5ismOg+dEZxJYQh3vk9Ce0eMgZpEdM1F5S6N0ni0b87sObk6IJKRkw0AuTk68ZNDEO883sS2j1kDFISkxIOw7RJNeKiNaWifZr3c4H4m9Xlx8QXVaJiChNMkMjce46DKHH2FLT7yBgkLKZbryoVy04yLwXBagGK986TZfy0C4gQ+fC8wUTFROVPhvEQJc6egnYfGYPIYoIAlFgCAMuz+wVbRBeuKhH33VCqttdccw2P6gLfJxg5rJ/nOttut1cIRAWVP4imFZnuPYeAXl7IVGj3kTGIK6blS+yOdZCQ8M0A6idBQNgesbBEjeY2faNUbRsbvOuaOJDH8z+NWSpVnoig8nMmGoeDvlkQFXBH8Pz79OnDo6UN2nUyBqFiWr3c7hNNa6tVFmfZMVWejrUSiRO3sd4rqFuutLcQGgSF/ZEjYm+yAMgT56ZNGaOOSVCqPBFB5dfJwZewEPFNgiCQOMKAte08TxM7A1r+GYNQMSk/kbBFc+HqGhU2f3a5WLNmjWrCcHz/Zrs5w/6Ri0rElevt/UvOKVHHJCg14pP7NdVwI9S4ooOAli1bpq4zYvhgV0y7du3SHl0MHx/c5qkgKj8RHXITeDwwzAuO86bX0ElkeB+Q5xfEHj16uGuw0gUt/4xBoJiUZdGgN0PgtInFroggFt2fNKi1WPWf6Fz7pNg56lPRcXtbjec68Fc11vW0y2TAbYNtsYGoINp37yMEPG5QfHpRgUAfC0s3a2q8954ItHwyBpstp1BcTCOGD/QUHpZk0phiVzS6IEg02KK508VFzZ8rHkdYyG/YoGJpqUo818EvHudRJvrSm472cu8SXp0mS8LB05iAcP37TTxNupmM1dLSZwyutJxCcTFRE0dY5viI1JBfbkcMKZZCscUFqwXCj0T9IxyTs3LZ0ba40AdDGjqPrclXhfBdj9vNCV7z5jB90EvdQwA+PmSyL64pvv76OYGn6UwmAi1dxuDrFt1IHDEBs2fPViJS827SMkEs8Bet/2qpa410lpfb21XoyL9tW6P5s2zxQVQNDfYbwT44Zdj5QGyyNgj6Yrkg/Pf+H/oqji9B0deTA/hAB0/TFVSWOQK0NBmDUy2nUFxMR3xxES+/Apotsj7wdEMs6JSOGmb3ob54ULE4+5RiMWd6sZg8vkSJD3EgPIgIfSm4DiCmwAfHykJlVOVMAv9csq+bHuLTob/ZogP/6aJft6vZ2ur9kgyHFjdjMMNyCsUrcP5s81++X7i6RGy73RbTxedI4XylWLy6rVg8IEd1bzxWKtadViK+fkaJ+O5FpWLDWcXiO3IUN2WC3bSBp3+5WBwuBQdBmaBGdqwsIDkzwbCvn0SF/jYwvjUVBIqzJxgGLV7GoNGigrPKU6MxA2ZMqRQ3bSwVSw+zrQ01aWi+YJlAagZBhON829hiMWaE3dy9vr1UXHeJWUzkgghiUWGPSA87DJ5XpHoGfw+KgD5ar152vK5kELQfwm4rw6AK9v4O76gLhD+IA51oiAjNHdwHn7xZKt7bUSqe3FIqLj23WJx4VIk4ZB4sT7G4Yl2JeOIunI8JjJq8S8/1uh4A8j3FI5UZTGQktG7duljaSQuEdfUzNuUxvPBRETQASDeDoE1uP2plGFTBvv31PF+lgSOGVon7779fvVJ98skni1OWFIu5M+x+ULJEH6uhHm6BUrUP8usGsX1ilv0gIYL1P3YfvMojAHCAUjzrqPNjIiLm2R39KOgqIYEm1whwxhlnUJxVVoZBFWzu9GxfxR26wCwa/MEND0uENJ/HebjsR+1+wbZOm7/lt5SgKu+Zm71iuPgRtwK4K4HCrQFj/SLSKePQh+1NCOqQV1dX+8LSORI0AZ9wdM4PtjIMsYLLyrrgLG8FL1iwQFx00UVq5AWeffbZ6jODOHfAAQcoq4Ut4jz++OM+gSA+/cP3Cy+8oPorsHAAj6vTZK36N9iecZ8QiCu+46uM0Pg6q5oCKw/w5RmHQLr6WZgDDChLxsEtHCrsd0/HfEaYg0PlQwzLly9XwtErXP+LC7I2WPLBhQHgP1d0sQE0KoMQSbAAzh8y3yumK9baX0Gxvn6fXwicI2cIq0++Pzwe6Tkw6M9IJ8QSdJ4D9xYmrnhzfTq08IxDrMBOxaEyYW10QaDisYXjksKwhgnhEBlWE5jSHXXUUcoSYR/LWCichIX4lAZWjPbvvd7bGXfLyQWQThoqLqh50+PxcJ4HIUww6B+tXr3aF07Uvw6shWccdlj0AJyK2zekgw3PuH5MIMFwQmxqvZIUEv6ansJhiXhcT76akP6ykz4YeoJfAPG47sf+sDDK6wweHPtTaRzzT/bwzz6bXqsKAo9HjDcXiGU0hvMZh3aLHoBWgSccaRbUfvvt5wtzBSDM/SCTcEz9K/ST2sb5+0qqfAVl/oqX3HqPv9n788+yReXwASJ/yRniv0/lCOuyR0VdfV+RX2XOw8N1W+1nkQASEVPQaBAWUAc/T2L63//+p4dnJFThvrI011eRnI0NlaKtrc0nBHw4nocRsXSXhwGYguH5c77ysLOCkVe6pI6lK1fFzn1xtWgaUSesLzhiWnOrePH2bPc8rXmCy2DlmWf58sX18DnpKKBnpzNoSI8pEh6XqAMd7qwsxwXikCzXSSedRGEXWBmK2E0ZKpRz4sSJnv4PmjEIBhZI76TTKI9Gc7qYqKPO8+ZU5cJIi1c4E5Pn3BfXiOL8Hh6WFvQQx/UrUed1K0Bpds8aqlhR119Yl2zzVbAJQR3qIASti+IwxTvuOPslDi0sY+EW8q/Pxq9g3QoB3OoEUY9L+xvPD7ZOD93izMehwlf/wHZSyv2HNzlWZsV3VD7Fh55quwUQdsDJShTPT2l1BUK8c3S9itOx6hL1h9BLV60Vo0/5mkdMB9ZW2vnI65J1wL9pmoBzVVZPHxFuAvqVPC5YafXgUV3odcOYsVhmOYVsquvpq1SdWM+ki4n6Q7A0GK1wAZHVwoOEhaIwj5vAcB1QlWnYNNd6HFieL/pWNYjtE5qFdeWOmMic83n9pFVZca24oLVS7jeLzWNbPGIaV13lxiXmFJe754vz8mLnrnxaXf93vcsCxTSkRy91nhPpTMAz4HHBZ7PN85QAj0v1pNVdRsItKK9UnY0NtR6xkJggEPiSuJgANHc0qqMwXWx1tX7r9L+37O+Bu5V7/l2ioLJeVfrrUwf4RAHi3JSyAnFKfak4vLpIVOdme8S0vqXCE7+1pMg917eg2Jcfrr8ruzRjxPRutvNMLOuPWr1lJCKJSbc+b9bY/yTOfUtBBLiY6Jh7vFVZMKPvVCw60ueuXS/uuusu+ylLVDY0+wVwwYPqHHw2HMqPgzjn3O6G9Rk/yw6jZlLnSfbIK1PENLaH2ynvo9VbRuIjyxHTeaf28YmIi2lIaZnYWdMsXpbNCcREQMdc92jTbDwckn+tbTWKCUQzuWCWLaiPX2ZWiXjxI+K6m28R5XUN7vWAMRMm+eJWDR7liQP07JWlzi09/svq2Dr3R+qYRnfYqhl5PS/Lbup0oXAxgK2WWVibeuX7wuLxJSkuHgZS/Wh1lrHItiJYp6lTxqnKf7nG/jt5TLnsV1ohXpGiel/2WXZJNsrzt1XVi7urG8Tb8vi9fi3iwDlz1L+IN5TYS0/41ErH5JhlUmUImQ455ZRTVBogKztbxX/lldhHV+cuiP1FmY6q2tg/KACU38IvLY+FOZ18l+feITvJPTwVyisZ7GwxdfSw71Py41iVZTZcMX26y7y2CJVPbgGaWzvkkEPE97//fXHzzTeLv9a1iq9V9FNW6NFHHxUvvvii+tsw/A8dmjKkg/uApmdcQTn5/+6pYL8ScWJJnvjhyHrx4zENYk5pnrh+WG0k5pdXq/RZhWXquKiwSB13HHmCug9sQX49lIcqVd/X2dli0upmr8FGK8A6/ek3sQlg/PO37mcCFy9eLA4dOVqJ6XuVdWqLv1o9+uijXRGRFeL7en9JXbu81l+hRCw3uRqjsAqRL0dixVk9PZ3sMC6ojXXAC4dOUmEFffrYYdwi6ZT9MJTrq736eFghLdZpcsuJuLJTI4qc84f2zFFhQ6yevrjgST1zfWFEXOfUns6/FuxlYgKMYkKl601TQ0ODmDlzpkdQZ1XUKBH9rLpRbfVzaA51IYGYqwOHD7bFdOAcx5TzygTlkL/40BViy4/vVfvW5U+Kotxcn2DCmDN4gifPuTW2WyD34BX+63HKcn0/q8BjLYI64PVSNDyMwm9meYDogPMwnf0d35Xka3pF7Q1w5+r2mZylKnlAf/tNEn2iljht2jTXPXCdY5Ger2lyxXTrrbe6oz3etBHVVAFZpQAxLT059ip301J7VNZQVi42DakRJ9aViCqZT11VZSjLKu1mDuxYtkZte8lOeUudtITr7xFFI9qEtdgZ8XEe9BVVNr2SuZhelUP3B7OK1D6skn7ujqxCd3+5tET6uXhicp/LXgqPdVq1LFbx5Hg0sVwSIiLy87ofClh2dKx5GznEmZrglehQh1pQj3DZ5CWCshFy1HfIVz2jN7gE8sq9b+JY59/tu75icaX4Vq88t5IHSjE9I4VA3LdHb/cc9tF848eEkSzujc69KOPOlh1qSvdzKUA9H52HOU2kZLFeQXsTBlqOmPLz/M0diYGLhXhoeZXa4iHyc4SRQw1+JTly8lUgp9O36b3PYW5e+G9g4L333hPt7e1i8ZIvqeP9999fvTKOdVf4/96cweN8wqR8aT+/xp5yCSSzTsQaaYkgElgk0ATcP/pAl0lB6qLk1DvgVA965eyNcG/kD8/ERlskKDjg0IcC0Rk3OS7xq8QW0y98ycnbT8RGi1UVzutLvOJ0yn5SRf9Bovf848R+h8SExJFz4DKx9Dh7dMZx3MmnCuuES9TcHICtmo5ZdoU69l3TxMah4njWTFGl034YwkTExVRmua91fSbgCkoXEwlqdnuxWLW8WLRPskdrcFBCZDR6I4Ghz/XJm7G0f/q1YRXlN3/urzidi9eICcV5bmf6g47Bns711YNrRP5A56WByx5T8e8d3eDrhPft3VvFKT71SjfvnZNbxdQKw3RKEA3WicLW9erL9eOBnvY+p3/FSWJynv17serYu+GK6ayTvGudjljkbaZuv7pE1NcVqzXkOP7DM6WipTn21ZQgrlnuDHt5hTGWy5HikPJSJQjMsVVW1Ylj+9eKMZUVoqawUBSNalfxDqwuUXEgkPayAp+YwNLqOmGdsVlYVzwl8nPsEaF16aO+awZSey4mhoHHjcDPFNwbQyeZiyFVqrxlp9hXYYyYmzuiukgsqMiXI6tTxF9+Li3MrCNFTl6BHUd2xrloiPeNbfSFEf+8zxBhnXdnuJ/JRFnuodportFxByyTTWAYkI7S/MBxE/DR3LZs95OGW7V6+EwAowhXUJs2mF/WTIZHLuxt58srKoz6S5RYJnLiZaKoZbhPJMRbRtb5wsCyydobvbI/pioa/iuQX9PE7JxOE5P2vD+T8HjGn9pS6BNGMlT5yQ6xr6Li0fGCg0EorG8R1pcuFDt27OCnxPxFh3jy018N1/OOSyvmFccIDtsJPbK0K/mhp1nUs7faQoAUpj3nzzR+Z2mCeu4ntqMxWXpe845KjLx0K0Lhkw/yVFjziNjbu4WV/u8l9MXSXC1fHeu+eZn/ukHMKxIXOqOzZCzTTcwbrj3fzwWmWZqgkm3y7r42385jza3+CopDwroNF3jCCweNds/VNHsXz5lQMmNhLI60Rpdf9W3ftSJR3gdGX6mKSXuufd2n/TmAR1DjRiTeKXfT84qJQwznPRWjncOIjveLvta/Qljj91P7Vfn5vvNEjOr4tSLTea08GTHd6IhJe56fS7xtaYLKzvb7oYL4/153Fr5NXeSvmIjEykce9qvJ3vXev25rcV8lLxzaprbFrSN8QlJiMlwjIcr7mSz7SmCNFFUY9LgNsQlcsIQe7ucR11maoMD/vGZeA6VTxe3tLPtIlVpnWRfHmuYK0Wf0DH98ydNaa7xCmjhPWMes98VLiGduViKClYF3PAz4JjhZpmmxZbjdkKiwmKBqKnv4BER0X/PmlZEM550gRuTniPGFcgQl2VbUR0wt7iOPc0UfvKLE4zvMz85WcSbKNDOrpJU84hxfnKRo2c1XPDH17t1bZHufWTcYHrOYqM5f4V9Hrs4FvOadKM8/qY/61LKOwvEzPXE6jvyy5zhvygJPfPd1qXRw3VZxdM+cQDHh3xDYM7rEfXrdMII/MDWJCyGFveadFKVlOv94+5M2tU39xRt323NuID43SH+XQS8IwIMOUPiixUeIU9fH3slLC+X9cTEVFvo+gr+THlY34uMEyyAqxcoGfwWkwpApEIL6UDzCTr9eHT9zY7baWuv9nfiUeck29TqS9j0Azm4kgRzL/yBt9s4V1ob7/RWRRq48+3xXTEo4CJeWrHXYSPtDFstjKwbSxmMv8N9rjO+op9KNlAAH3DOW/+HG2DjUfX8t3dx8c+zVcZeJTJeE8ZSr/ffi5+NWNzoF4y3/ww7m3KXmt2y7kqdeI6zZRwurutlfvmD+y+pGl2K25IuWvyJSY2mNsM6/0y8K8LJHhdUyxp8mPfxUstzqRkagVHKb5a+k5KmLip9LnRda3dhrMVfyKMnlkmslvyv5gORLlt2s8Mq22afAH+blG5IPSd5o2V9iw0j0IMkRkvlWNz73uMryiwZ8U4/UjW5EhcladaMbSaNbSN1IK77EA7rhx/8HENvQxrkfzDIAAAAASUVORK5CYII=>