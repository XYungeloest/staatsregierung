![][image1]

**Gesetz- und Verordnungsblatt**  
für den Freistaat Ostdeutschland.

| Nr. 35 | Ausgegeben zu Dresden am24\. März 2026 |  |
| :---- | :---: | ----: |

Inhaltsverzeichnis

| 24\. März 2026 | Gesetz zur Änderung des Gleichstellungsgesetzes | Seite 2 |
| :---- | :---- | ----: |
|  |  |  |
|  |  |  |

**Gesetz**  
zur Änderung des Gleichstellungsgesetzes  
 vom 23\. März 2026

Der Ostdeutsche Landtag hat am 23\. März 2026 das folgende Gesetz beschlossen:

**Artikel 1**  
**Änderung des Sächsischen Gleichstellungsgesetzes**

Das Sächsisches Gleichstellungsgesetz vom 19\. Oktober 2023 (SächsGVBl. S. 850\) wird wie folgt geändert:

1. In der Überschrift des Gesetzes werden die Wörter „Sächsisches Gleichstellungsgesetz“ durch die Wörter „Ostdeutsches Gleichstellungsgesetz“ ersetzt.  
2. In der Abkürzung wird die Angabe „SächsGleiG“ durch die Angabe „OstGleiG“ ersetzt.  
3. Die Inhaltsübersicht wird wie folgt geändert:  
   1. Die Angabe zu Abschnitt 4 wird wie folgt gefasst:  
      „Abschnitt 4  
      Gleichstellungsbeauftragte“  
   2. Nach der Angabe zu § 22 werden folgende Angaben eingefügt:  
      „§ 22a  
      Landesgleichstellungsbeauftragte  
      § 22b  
      Aufgaben und Rechte der Landesgleichstellungsbeauftragten“  
   3. Die Angabe zu Abschnitt 6 wird wie folgt gefasst:  
      „Abschnitt 6  
      Gremien, Beteiligungen, Vergabe und Förderung“  
   4. Nach der Angabe zu § 27 werden folgende Angaben eingefügt:  
      „§ 27a  
      Öffentliche Auftragsvergabe  
      § 27b  
      Staatliche Leistungsgewährung“  
4. § 1 wird wie folgt gefasst:  
   „§ 1  
   Ziele des Gesetzes  
     
   Ziel dieses Gesetzes ist  
1. die tatsächliche Gleichstellung von Frauen und Männern im öffentlichen Dienst des Freistaates Ostdeutschland,  
2. der Abbau struktureller Benachteiligungen und bestehender Unterrepräsentanzen von Frauen, insbesondere in Funktionen mit Vorgesetzten- und Leitungsaufgaben,  
3. die Förderung der Vereinbarkeit von Familie und Pflege mit der Berufstätigkeit,  
4. die Herstellung von Chancengerechtigkeit für alle Bediensteten im öffentlichen Dienst des Freistaates Ostdeutschland sowie  
5. die geschlechtergerechte Ausrichtung von Personalentwicklung, Gremienbesetzung, Beteiligungssteuerung sowie der Gewährung öffentlicher Mittel.“  
5. § 2 wird wie folgt geändert:  
   1. In Satz 1 werden die Wörter „Freistaates Sachsen“ durch die Wörter „Freistaates Ostdeutschland“ ersetzt.  
   2. In Satz 2 werden die Wörter „Freistaat Sachsen“ durch die Wörter „Freistaat Ostdeutschland“ ersetzt.  
6. § 3 wird wie folgt geändert:  
   1. Absatz 1 wird wie folgt gefasst:  
      „(1) Die Dienststellenleitungen, Personalverwaltungen sowie Bedienstete mit Vorgesetzten- und Leitungsaufgaben sind verpflichtet, auf die Beseitigung struktureller Benachteiligungen von Frauen hinzuwirken, Unterrepräsentanzen abzubauen und die Zugangs-, Entwicklungs- und Aufstiegschancen von Frauen auf allen Funktionsebenen zu verbessern.“  
   2. In Absatz 2 Satz 2 werden nach dem Wort „Leitprinzip“ die Wörter „der Personalverwaltung, Organisationsentwicklung, Haushaltsaufstellung, Beteiligungssteuerung und Gremienbesetzung“ eingefügt.  
   3. Absatz 4 wird wie folgt gefasst:  
      „(4) Die Staatsregierung berücksichtigt bei der Aufstellung und beim Vollzug des Haushalts die Auswirkungen auf die Gleichstellung von Frauen und Männern und berichtet hierüber nach § 29.“  
7. In § 4 Absatz 5 Satz 1 werden die Wörter „weniger Frauen als Männer“ durch die Wörter „der Anteil von Frauen unter 50 Prozent liegt“ ersetzt.  
8. § 5 wird wie folgt geändert:  
   1. Absatz 2 wird wie folgt gefasst:  
      „(2) Soweit zwingende dienstliche Belange nicht entgegenstehen, ist bei Ausschreibungen von Stellen mit Vorgesetzten- und Leitungsaufgaben ungeachtet der Hierarchieebene darauf hinzuweisen, dass der ausgeschriebene Arbeitsplatz für Teilzeitbeschäftigung, Jobsharing und mobile Arbeit geeignet ist.“  
   2. Nach Absatz 3 wird folgender Absatz 4 angefügt:  
      „(4) Soweit Frauen in einer Funktionsebene unterrepräsentiert sind, sind frei werdende Stellen grundsätzlich auch extern auszuschreiben, sofern nicht zwingende dienstliche Belange entgegenstehen.“  
9. § 6 wird wie folgt geändert:  
   1. Absatz 1 wird wie folgt gefasst:  
      „(1) Bei einer Unterrepräsentanz von Frauen sind alle Bewerberinnen oder mindestens ebenso viele Frauen wie Männer zu Vorstellungsgesprächen, Personalauswahlgesprächen oder besonderen Auswahlverfahren zu laden, sofern sie die für die Stelle erforderliche Qualifikation besitzen. Die Auswahlkriterien sind vor Beginn des Verfahrens festzulegen und zu dokumentieren.“  
   2. Absatz 3 wird wie folgt gefasst:  
      „(3) Auswahlkommissionen sind zu gleichen Anteilen mit Frauen und Männern zu besetzen. Erfolgt ausnahmsweise keine gleiche Besetzung, sind die Gründe schriftlich zu dokumentieren.“  
10. § 7 wird wie folgt geändert:  
    1. In Absatz 1 Satz 1 werden die Wörter „bei gleicher Qualifikation“ durch die Wörter „bei im Wesentlichen gleicher Eignung, Befähigung und fachlicher Leistung“ ersetzt.  
    2. Nach Absatz 1 Satz 2 wird folgender Satz eingefügt:  
       „Wird bei bestehender Unterrepräsentanz eine Bewerberin nicht berücksichtigt, sind die hierfür maßgeblichen Gründe schriftlich zu dokumentieren.“  
    3. In Absatz 2 werden nach dem Wort „Mitbewerbers“ die Wörter „oder einer Mitbewerberin“ eingefügt.  
11. Dem § 9 wird folgender Absatz 7 angefügt:  
    „(7) Dienststellen haben Frauen in Bereichen der Unterrepräsentanz gezielt für Fort- und Weiterbildungsmaßnahmen zu fördern, die auf die Übernahme von Funktionen mit Vorgesetzten- und Leitungsaufgaben vorbereiten.“  
12. Nach § 9 wird folgender § 9a eingefügt:  
    „§ 9a  
    Schutz vor sexueller Belästigung und geschlechtsbezogener Benachteiligung  
      
    (1) Die Dienststellen haben sexueller Belästigung und sonstigen geschlechtsbezogenen Benachteiligungen entgegenzuwirken.  
    (2) Wird ein Sachverhalt nach Absatz 1 bekannt, hat die Dienststellenleitung unverzüglich geeignete Maßnahmen zur Aufklärung, Unterbindung und Verhinderung weiterer Verstöße zu treffen.  
    (3) Beschäftigten dürfen aus der Inanspruchnahme von Beschwerde-, Beratungs- oder Schutzrechten keine Nachteile entstehen.  
    (4) Der Gleichstellungsbeauftragten oder dem Gleichstellungsbeauftragten ist Gelegenheit zur Mitwirkung bei der Erarbeitung und Fortschreibung von Schutz- und Interventionskonzepten zu geben.“  
13. In der Überschrift von Abschnitt 4 werden die Wörter „in den Dienststellen“ gestrichen.  
14. Nach § 22 werden folgende §§ 22a und 22b eingefügt:  
    „§ 22a  
    Landesgleichstellungsbeauftragte  
      
    (1) Die Staatsregierung bestellt für die Dauer der Legislaturperiode eine Landesgleichstellungsbeauftragte oder einen Landesgleichstellungsbeauftragten.  
    (2) Die Wiederbestellung ist zulässig. Bis zur Neubestellung bleibt die bisherige Person geschäftsführend im Amt.  
    (3) Die Landesgleichstellungsbeauftragte oder der Landesgleichstellungsbeauftragte ist unabhängig und in der Ausübung des Amtes an Weisungen nicht gebunden.  
      
    § 22b  
    Aufgaben und Rechte der Landesgleichstellungsbeauftragten  
      
    (1) Die Landesgleichstellungsbeauftragte oder der Landesgleichstellungsbeauftragte  
1. berät und unterstützt die Gleichstellungsbeauftragten der Dienststellen,  
2. wirkt bei Gesetzentwürfen, Rechtsverordnungen und Verwaltungsvorschriften mit, soweit Belange der Gleichstellung berührt sind,  
3. beobachtet die Anwendung dieses Gesetzes,  
4. gibt Empfehlungen für eine einheitliche Verwaltungspraxis und  
5. berichtet der Staatsregierung und dem Landtag über wesentliche Entwicklungen.  
   (2) Die obersten Landesbehörden beteiligen die Landesgleichstellungsbeauftragte oder den Landesgleichstellungsbeauftragten frühzeitig bei allen Regelungsvorhaben und grundsätzlichen Maßnahmen mit Bezug zur Gleichstellung.  
   (3) Die Landesgleichstellungsbeauftragte oder der Landesgleichstellungsbeauftragte kann von den obersten Landesbehörden die zur Wahrnehmung der Aufgaben erforderlichen Auskünfte und Unterlagen verlangen.  
   (4) Das Nähere über Stellung, Geschäftsstelle und Ausstattung regelt die Staatsregierung durch Rechtsverordnung.“  
15. § 24 wird wie folgt geändert:  
    1. Absatz 8 wird wie folgt gefasst:  
       „(8) Ist sechs Monate nach dem Ende des Geltungszeitraums eines Gleichstellungsplans kein neuer Gleichstellungsplan in Kraft getreten, sind bis zu dessen Inkrafttreten bei bestehender Unterrepräsentanz von Frauen auszusetzen:  
1. Besetzungen von Stellen mit Vorgesetzten- und Leitungsaufgaben,  
2. Beförderungen,  
3. Höhergruppierungen,  
4. Übertragungen höherwertiger Tätigkeiten sowie  
5. Einstellungen, soweit sie nicht der Beseitigung oder Verringerung der Unterrepräsentanz dienen.

   Dies gilt nicht, wenn der Gleichstellungsplan wegen einer Beanstandung der oder des Gleichstellungsbeauftragten gemäß § 21 oder wegen eines gerichtlichen Verfahrens nicht in Kraft treten kann oder in einer Notsituation das Erfordernis der Aufrechterhaltung der Funktionsfähigkeit der Dienststelle der Erstellung des Gleichstellungsplans vorübergehend entgegensteht.“

   2. In Absatz 9 wird das Wort „Absatz 8“ durch die Wörter „Absatz 8 Satz 1 und 2“ ersetzt  
16. § 25 wird wie folgt geändert:  
    1. Absatz 3 Satz 2 wird wie folgt gefasst:  
       „Soweit Frauen unterrepräsentiert sind, muss der Gleichstellungsplan die Zielvorgabe enthalten, dass bei mindestens der Hälfte der im Geltungszeitraum erfolgenden Maßnahmen im Sinne des § 7 Absatz 1 Satz 1 Nummer 1 bis 4 Frauen bei im Wesentlichen gleicher Eignung, Befähigung und fachlicher Leistung berücksichtigt werden.“  
    2. In Absatz 4 werden nach den Wörtern “Entsendung in Gremien gemäß § 26” die Wörter “sowie Aussagen zu Beteiligungsunternehmen nach § 27” eingefügt.  
17. Die Überschrift von Abschnitt 6 wird wie folgt gefasst:  
    „Abschnitt 6  
    Gremien, Beteiligungen, Vergabe und Förderung“  
18. § 26 wird wie folgt geändert:  
    1. Absatz 1 wird wie folgt gefasst:  
       „(1) Gremien sind zu gleichen Anteilen mit fachlich für das jeweilige Gremium geeigneten Frauen und Männern zu besetzen. Hierbei bleiben Sitze, die mit Personen ohne weibliche oder männliche Geschlechtszuordnung besetzt sind, außer Betracht. Besteht ein Gremium aus einer ungeraden Anzahl von Personen, ist einer der Sitze abwechselnd an fachlich geeignete Frauen und Männer zu vergeben. Erfolgt keine Besetzung zu gleichen Anteilen, sind die Gründe schriftlich darzulegen.“  
    2. In Absatz 2 Satz 1 wird das Wort „soll“ durch das Wort „hat“ ersetzt.  
    3. Absatz 4 wird wie folgt gefasst:  
       „(4) Die Dienststellen erarbeiten zusammen mit den Gleichstellungsbeauftragten Strategien für eine frühzeitige geschlechtergerechte Nachfolgeplanung bei der Besetzung von und Entsendung in Gremien, die mindestens für den Zeitraum von zwölf Monaten gebildet werden.“  
19. § 27 wird wie folgt gefasst:  
    „§ 27  
    Beteiligungen an privatrechtlichen Unternehmen  
      
    (1) Hält der Freistaat Ostdeutschland unmittelbar oder mittelbar die Mehrheit an einem privatrechtlichen Unternehmen, hat er im Rahmen des geltenden Rechts darauf hinzuwirken, dass die Grundsätze dieses Gesetzes in dem Unternehmen entsprechend angewendet werden.  
    (2) Das Ziel der Gleichstellung und die entsprechenden Regelungen dieses Gesetzes gelten insbesondere auch für Vorstands-, Geschäftsführungs- und Überwachungspositionen.  
    (3) Entsendet der Freistaat Ostdeutschland in das Überwachungsorgan eines seiner Beteiligungsunternehmen mehr als zwei Mitglieder, sind unter diesen Personen Frauen und Männer jeweils zu mindestens 50 Prozent zu vertreten.  
    (4) Bei Beteiligungen ohne Mehrheitsbesitz wirkt der Freistaat Ostdeutschland auf die Anwendung der Grundsätze dieses Gesetzes hin.“  
20. Nach § 27 werden folgende §§ 27a und 27b eingefügt:  
    „§ 27a  
    Öffentliche Auftragsvergabe  
      
    (1) Bei der Vergabe öffentlicher Aufträge über Leistungen mit einem geschätzten Auftragswert von mehr als 50 000 Euro ohne Umsatzsteuer ist im Rahmen des Vergabe- und Haushaltsrechts zu berücksichtigen, ob Bieterinnen und Bieter nachweislich Maßnahmen zur Förderung der Gleichstellung von Frauen und Männern im Erwerbsleben ergreifen.  
    (2) Sind Angebote gleichwertig, soll das Angebot bevorzugt werden, bei dem entsprechende Maßnahmen nachgewiesen sind, soweit vergaberechtliche Vorschriften nicht entgegenstehen.  
    (3) Das Nähere, insbesondere zu Nachweisen, Zuschlagskriterien und Vertragsbedingungen, regelt die Staatsregierung durch Rechtsverordnung.  
      
    § 27b  
    Staatliche Leistungsgewährung  
      
    (1) Bei der Gewährung freiwilliger Leistungen nach Landesrecht an Arbeitgeberinnen und Arbeitgeber ist in geeigneten Fällen die Förderung der Gleichstellung von Frauen und Männern zu berücksichtigen.  
    (2) Zuwendungen können mit Nebenbestimmungen verbunden werden, die auf die Förderung von Frauen, die Verringerung von Unterrepräsentanz oder die Verbesserung der Vereinbarkeit von Familie, Pflege und Beruf gerichtet sind.  
    (3) Das Nähere regelt die Staatsregierung durch Rechtsverordnung.“  
21. § 29 wird wie folgt geändert:  
    1. Absatz 1 Satz 1 wird wie folgt gefasst:  
       „In einem alle zwei Jahre dem Landtag vorzulegenden Bericht über die Verwirklichung der Gleichstellung von Frauen und Männern in der öffentlichen Verwaltung stellt die Staatsregierung die Umsetzung dieses Gesetzes dar, zeigt Wirksamkeit und Defizite der Förderinstrumente auf und berichtet über die Auswirkungen des Landeshaushalts auf die Gleichstellung von Frauen und Männern.“  
    2. Nach Absatz 3 wird folgender Absatz 4 angefügt:  
       „(4) Die Berichte nach den Absätzen 1 und 3 sind zu veröffentlichen.“  
22. § 31 wird wie folgt gefasst:  
    „§ 31  
    Übergangsvorschriften  
      
    (1) Die Landesgleichstellungsbeauftragte oder der Landesgleichstellungsbeauftragte ist innerhalb von sechs Monaten nach Inkrafttreten des Gesetzes zur Änderung des Gleichstellungsgesetzes vom … zu bestellen.  
    (2) Bereits bestellte Gleichstellungsbeauftragte in den Dienststellen und ihre Stellvertretungen bleiben bis zum Ablauf ihrer Amtszeit im Amt.  
    (3) Gleichstellungspläne, die bei Inkrafttreten des Gesetzes zur Änderung des Gleichstellungsgesetzes vom … bereits in Kraft sind, gelten längstens bis zum Ablauf ihres bisherigen Geltungszeitraums fort. Sie sind spätestens innerhalb von zwölf Monaten an die geänderte Rechtslage anzupassen.  
    (4) Die §§ 26, 27, 27a und 27b sind auf Neubestellungen, Neuentsendungen, Vergabeverfahren und Bewilligungsentscheidungen anzuwenden, die nach dem Inkrafttreten dieses Gesetzes eingeleitet werden.“ 

**Artikel 2**  
**Inkrafttreten**

Dieses Gesetz tritt am ersten Tag des auf die Verkündung folgenden Monats in Kraft.

Dresden, den 24\. März 2026

**Louis Hahne-Eichinger**  
D e r   L A N D T A G S P R Ä S I D E N T

**Dr. Karl Honecker**  
D e r   M I N I S T E R P R Ä S I D E N T

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJMAAADICAYAAADsrNMhAAA7b0lEQVR4Xu19B5wWxf3+AnfcwfV+x3Xu6L0f5eCkqYAKGiVWMGoUNIKxADYgIWoswRaMSVTUWBILxBaTqKCxEZNgN1bUaEwXE/NL8o9x/vPM7nff2e/O7rtvueNF7/l8ns/uzs7Mzu4873dmvjO7r2V1Ix62SArJJhbejW5ExoeSQuywuWuLEhR4A4vXjQwHKm0jD+wiiC0Xx0Rk4pL5rrD2BCDynTywG2aInTd7KmybZDGL01nwCSeIKKPVdZV6kGU/C2UhZ4zttpDxIBpr/JVGXLG406xBh2VbQd8149ER/OVI68kxPeiwnB8Wvy4R5y3bUnXDwc61x/sfVBCtWMWlqwLXUb78WlGIdGgWeaYpQOUFofJrBbEoX6Xp8Gbz+cO6Dx/yP5wwwsw7Dy9dFfghv0YytNLUFOOHZSUh7FED0vY89joslNxlJfHQiE4Tkw748k6Gln0/qWIpzzcRyvTbrfT9yPYeODfveyCJUKbfzLJNGIk0sWG00lOJvnwTIayT0znfY8DF10rOcIj9bU44HHadgQ7+IJKhlXoFLuR5Jss0WMqdN5znzzdRdqKYmqyYLrAlzZBe1EBA4NeJQoDY37bJLhhuzklMSJfvZyV/CMnQGeFt5pkngK08z2SJZ8YzTxC+PJOh0+dKFzqc7WhJVxfYkmawdQYgGNXGr1hkJLnU2aYDaen0glZqZfLllwp55okgXc0tyPNOAchrG0TDr6HTY5UPmu6PwImMnSmFdIxafPknS+TFM08Al/P8kqVjxZMGzy8VyuxW8vyTgPrBh/n+tOt57t0XIYg8YZLw5ZsskRfPPBF0jPPnmQytFMvB80uFMrutPP9EEc8asest1dNG7ojCL2Sl7iDz5ZsskRfPPEHs5nkmSqfP0MQzTgTFBf58k6XMbh3PP0H48gzi6IGG598UwZwRcTGePkFs5nkmQ8suR5OWL/ZDywazbdlxMK+GOS/Al3ci7GFZHzn5rHDyjvKMPOeRR9jUSVSmwxufyKjSCrhPX8Qgpto/ADAS4/kmSst7I7uc49CyUVpUnDOMBlfSSMVExOFhRFgUy5nb0+/JyTcQ2kT2DU4Q+qK+/HVGmS1w8kwF23ieQQwbTa9MZD7Isr2tqSBu82KFPFynEtXCNQwMKNyxPIHg+YDkAoHJ5udAnONhFB7nXCD0uJoLZql+L5yIw8MM+TR5LpQ4fPkGEXF5Yh2+BEFEXJ44DtAEcPjy5dfgYSAtVDP9UhHOrsHhS6OnNfVdTGkQBo8zDwed5Smh5TCVnawVD9evycPYNZWvhwFTV4nAl3cQrTh9s8hzQzLuszxxHCgHFyyHMynpkudNDBqWIo2pMuicZXtlTfDF50SconzrUx7Gj+NZcceJGbTeKfDeqOnl4WBQmstPU2kwglNpyQHt9J+26xeOAF/+JsKdxBP6EGTqORFVS6bae+3YBF8eID08U59l42n+MMSN10HUltjqSKrTD9cB8lp3gv9cPKL8rAwWVjzweJy4nmlAZBquIx7iBzWPVriYlGebhfnyMNGQzghfQk7EceKqPgsJwQpxGfTsYf2d52PI0xO2+Xx/RUapDNBxYTRpRfDFiUduCZLJw/JaJ9/5INK1nftQnV29GXQsX2iZHMsU5mRW8bSFh0sQGGVUaTHfUhBG84Sclt3EmcKDzDqw02RpdOpTChbLnx9HIdLQxU2/6jCarhf06w+jXgZTnvFoSgNrFM86g4V51qeWtwXh8KVBmClcp9G3FISw/kDY4i0rxPMa1FkNommuKp4YOS2tIk35hRFpeRhoao7DmEoZQNM9B5XNRP36BvjiO9YsdO4U6XhGYfBloGcU1Pl1+gimC4UWjjOowiznV0NE5QSVRYuvEFaReIA4rzOnd7R4YfmCehmC7ouIvDTfl6LpTRmEb7/GH26i00yaEPicaYDEw4mWedQYCONKAgybeT/CRMsvKF+cIGJkAjNuarcTtW762h5ThzYe9XKjPFH7azwP9yEYzsej6dnpE/MoF0QR1uxZ3k54hylPTsQxNetJrdviE6DUEeSZm+g4z7Zp2fni6IRAYdV0K4M0dJzItXUiTdQyBBEVhQ5qmAUMo6X5YoIsQTzq1irRvh/opCX4zpsY9MxZXpHhyygRIn2qedGURwoVqZchKddAKuTTTskIIR20NMtksjaJ0Io4iuOIvJLARDbh6DvfFbTYvFEyTV0qxH3r18cxj9MVtGIjupTWbyU0iuOAeYevJ2pnj1PLKm3LY6MyYPbcF6+z6DQTfCpjO4/X2WTW0Xc+ESK9lldi0Duc6HhRJw9ORHk6ykhmHeUV5m7oDKJ8dG0GX9wg8rhRLZth7byLqHmki1YC3Q0nrjIg/JxzfrOWV0LwZQZxJdKJtLwecd/5RGgaIgcR19Kua8JuPsDgtJwHy8K2hqWjTqvlt0g6lloRn4VpRJsonesRfOeDqLl5xNIFSY7iNPgukIiQQJ6haUY+jLwM/JjTWZbytveqofDlAcuhLXbzXZ/CTb9eK84sOoOqJJ4HkVYe0DGefZiQTUR6fk0eJyoNeSUEY4Y8LIgBs8oLV37RH9dEZ4LVMwiQx1t79rDeDWoqrMRXMrgjPMt+WNv1k9x348TRIUa2Wp/gHJp8di4KfPegLV+BdXPDnfw3Rx3ZOnlwJD2ossz5JQQ3syBHYhCRlmfmQM1Uh83COxYGE5SelzWRTstHPWxQOx82D2UElptY5rL6Bg0BnXqAly0qVL7aKoe39ZO6k1ZzwG4Ne3bOKoLtWjYeBP0Q49EKb7ojoclyHhT/lYbRsSrrPDn5sdnShKAVWi/4Ov2c88EKjibJVNr0oHS+sjnlM00lrLSS878sDVlI16RbIWb5nuVNpCbIeD+ohP12ThnTgrirCHQ6Ixk83EigfhitG2KnfUNpKzhvnjYVFFO5HGukXz+d1wGCmmbPfTtLTjjcKQ/s85Mh8NVbGFPyL3GQC4D/Gjgt+4aaWPJ4UPla5nU3Kl+YeG3NVPpuLBiee8JWt8yWd6qoU0CrBSxvWdaxaMCzjtA6+Ik4WBfBtdMpz1zP1DgBmOJF3+YBAE0qW851teuErZtKFTfo92Sq1HgvLaQBnmdKfVXs84gOgsJDETQ6d5YBu3Utt7tZ0pTAbwZWZLtz7A6TtfPpgGekpXdGnZWBnYFifUbe0ioVD1V/+DjHE6cJu+gaEDKaWSqTaRlwKqC5QqcZI66j87i20/HvoLB04HKYRMcpt5SfdIBz23lgCnArjh6m7kV3VhGmEzcgzyDxkID4Mc8kRazUR8yW9iPupGuG1VlnXM9Fp2bO4D48faWhHg46gkpHk7eTuz0sdi0if+HCWUjWwfJLBh4vP4RMoy7dKjvNTgdPnGYUU1msTqpv/WbW8ZNpRLH+8CytUvFwubVwKnMtzyQB3MDnDTEgCBo+mxbIWfYDNw0gouJDfj1Lu288c77Wi2eQZqjrOC3R9fxkOvAy3ZDTZ4nnz0gKelMD8pWdpsrU5sQSqdAOy2B9UHFRRzk6wyZ3Q7DEMuRlWozH4+GY5ZUuuEusrc67hu25pgs50yVreaQUgObK88CC5vJ4PKIzRAaR1wxP7jbUNwFAXlkgmjqyihTPxLAyaK8NgbwMTZb9bQHjjwJEubilBCFWXmbkY6X3R+25BtbB8whpw4mLvG6BJC2CCb6HB4ZZiKA0OlFW9Ll402gi8tMr0VShFE/fj7KaAdePUgZdzCaa7tlxqu7SH2YSWMtXgVqxH0SnwXhDmkVIVFSBgsE5HsaJOFEnjoNI0xB6GPLkYUSE6511PrufLJFHlC/DBFlrx/eVqKjUJ4B4XvSSAs7xBOmEuhhtOTVLBaKpWWt5v+KrmjL0i4Icn2H5BxHxw/IzkcqqWxZ0vKn5CSoDjbJwXm8SkI6P9KJQv2YU4poLZ/jDiTT943CbZQtGrwN1LsgCIn+yUlYaJnfD8CwuAuXGm1rBQ6f3wED86vjw20RUSKLCAGXZIq2ExBJkctLx9EEOyyAijj7NQp1weJB5XE6yaEHNaRghPt5/MhF1gOdOdRDUCuik+07n5G4Qmuiipl9nKqT8eHhUQiRYmtE23BLZWZ5fp5H6AzZd1/TgTWGoMIgYoqA8+bU4q8vsskJ0UX5gJuJ68X7QiRDWTn8OaZ3cDQJv13Ec1I5HpczW+Bo0LBQeOnP3u2JA5Ubp2IYRefEw+mBGEHl8WKRUykEDBTxL7TOJLrGiYquho48fIKxUKv3GoB+xc+1Oh+/CID2EqE0UVdigRv/DS4dIotBkaXB9bm35PaO/wUdx3B/WWdTmyzxiwzaRHzW9FBL0nK00T+4GwXdhndSBQ7wg4jyvjM4gNX1oDrT1Uh7q8YMqg8cDYUX4D4fnjeYP10UZYFmSfWUsEVKzHUSI3vQj4rQ6f8pGIfBFPlI70eTJTZbU5AWJQm/2cMzTc/JfJNJwcejneBiF8xEdj8OJMqK/gx8TDVD4vYDow5iatmSJ+9WvBaEHiTvdqxNCcf+3vJWKQgZVRFSahEICSTRvpOVhnDwO7wuGxQ06B2HF+/HgnriQ45FGZfqzAdFXChJEVKK/5yyHVtQMQpdgJ0xlog9EJx4AF06qeepEfjyMU48TT6xh+fFz8ZoQHj8Vmpo0CCzZESLLs0vgK0AQebMX9qATyTceo+Slx4n33zFh+fF7guXhcaLmlSip6eLhIATlzJ8qYkScSLNpde7KEBe+C+tDaZjMRN5k0QrvC0uWUZoS/XpBFWKKy8mvExY3yvlEGOU+ORFft2hoIbglc9wFXQZVEHQkE72ZIGK4na688LC4xeBE+Wl/bxVTOvPC82I+rq4DV3OqJP8JD0+GYeafaHWLyUjkqddzlyCZSc14tBJ8OBA0+ZJMXnIixAIril8fLUnRr5VuMVFTQkN/fbTESX6oZEZl8cqdDJ1ydTl8BUmVpjzD/Eswy+Q+4JUaj/q14lWKqVxEft2wuCaS8FAGfn/wBYUJzTQFlSqtgNfOOhu+giRDPChaP6QzSCCmsGSol39PisnEoDwwsOGig0UO+/ZAorS6yPPN4fkOQBgxOuCCwbCVV0RUJptOJ8pA+3uLmOIRlkr/XxpYtijLYYjOKG/PgHfCaeGW5dwM+gq4QR4vVcYbqUUhykf7nxUxmYi80FVwPuzh0iQy59weg1u4eBUc73wiDJqQTYQoM+1/1sXEw4j4kfNmkyp2T8BXwCAmEjce05GXnkemiSlsnjBRBi3P5XQmdzdrddvleDvevBbRSsNDJkbNi9wGaHpNrgOKl24x6dSH/vEmgYPyTIVR83LKu0exLuqvyAqpkESJvDDPFOQyIJLbAKMg3m/Ty5NuMfHz8fxNEDoEH+YGSIa8bGF0yrLH4SuYiYnM12Guj4sEFRHkLkiGerk7U0zJEvka+jNqoV9UwSXiWLb2kH+Jw1ewINKDh1Vxvr3oEhYuEcGlSr3cmSimeET3wuTshIUjK5xIWaw95F/iCPQ36R+NAtM5ogvi21st8aMLLHHBMvvB9qvwlmFPER3hExZa4ntn2wL856P+sqeT3LLB0gdZtC5dWRkPJx3sfXAQTdSOeRT+/Cq7PzG4yV9JYRzeYokvHWCJ76y2xG9u8ufb2USH+6dXWuLrJ1rigHZLVJX6yxjGeVMscdNaS7x5tz/vZAmR8XVOzn5GwFfgRPizK+0K75vrf5jEXr3sXxmawU+e9OfxWeRrd1ji7KXxLSt+MBtOSl1wVoY0c76CBfGjR+xpldqQB0STm2iuePpu2lb6qP0t0bOn/9kRYQVh0XjaMFrBXzHuUvgK9sT3/HNxOscPscQ9l/rTdTM1/vcJS3zty+6ncHxs7meJG9f6+2td8Sp4IvAVHFx2iCU+eMB/093sej54hSUmj/DXEdijh/tfMRmB2yxDIbu5VzFj0C2mvZ8ZAyWmww8/XHwWMWvWLGH1kA98/Uz7wdcUCOuQocJqLrGPN8y2SRWD8zP72/uT63mlZSozBp99MX1NsrSPsJZPtIWkCwjbktxYxeAYQtPjHDcudqwLL3OYMfjsiwkCgJh0AZ0x1RYNxKVXDM6NrTGLKTerW0xx8PkQky4kbCEias50UlxdOPq2W0yh6FIx/f73vxfbt28Xf/vb39ywp556SouRXigx4YGbBAVOaeAV442PPhTtd4spLuKK6YD99xdf+MIXxMMPPyyeeOIJ8fzzz4tf//rXYseOHeK5554Tr732mvjPf/7Dk/lw1dfqxO/nDhAN8ld/dmupuGN8rZgmmx8T/vGPf4hVq1aJ6dOni9GjR4umun6itLBA1BQXian1lWLrhDoxtzyPJ/PBtUx46CZBBYnDlCZzmTGIK6bXX39dieAcKYBn2pvUPjg0L1t8d2S12n9/TqsYN3ggT6pw9913i3++0Fvx4dsGidLePcVRtYUq3djC3uLg1hpP/I0bN7rXAB+d3CAOrs4XS+oKxWgZfz8pIoSjXPHgsUzUbwJ5M3aw03dC06dbIb3zjXMnT5LCtoR4c89SlXVvFBOwYNwI8YZ8mHolc74nBXXLLbfwpKKxsdHdf+yxx8RHH30kpvbvKW49P0fMrcgT3xxSEYssMa6swJf3GzNbxM4ZTeLhtgYxtixffPjhh540QYCY1MPP6WV3utGsQRhrpseERJUCsaBZo3Dw3A57q3XKRw/1V25X0y3z3igm4Fe/+pWY2NIo2uRQ+oSGIlXJJ+zXS/yyvVHtw2rNnTuXJ1NNIwCL097eLhYuXCgGlRWJsw7Ldi0d4eOPPxYTinJcEf3s0hzx5qwWtd9WlieOOeYYN24UkJgmY33Q+fvYPicSyokT7I748CpbaBATWShdZNinvtORo3wVuyfolm1vE9Mnn3wiLr/8ctFUXyvOGDdQVezP2+rFOQNKVdO1bP8s8ZvpTdJyNIvbbrvNk/amm24S/fv3F08//bTqfD/++OPilVdeEW3FOeLO9TnitP4l4oWOZjGkuclNU1NiN4Fz6u2m8ezF2ep4ZnlfcdNou1l9saO/OHHsINE2dJDo6OjQrugFiQnsg6UyJBISFCzVWdOEldc7FobzUmRupVG4w+23+iu3q6nKtbeJCX2bV/bpL+6dUCsFkCv2q7D7K2Cz7HdQX2iurPh+OVmetPfdd5/nGNiwYYM46oAqUVNoiaKsHm5eEKyOAfk5YtsmO2+Q4hFh0TaPrhG3j6sVN2260pNWhy4mtxK4oApyYmGyT6T8T5KIX1zoqzhfxe4JsjJlDELFtPP+rWK7/PWiAt+Szc1PJ9WL5j62pQCv/WqOGF+UK8qyLJ40ENMnThBPT4t15H8i8zRh7MgR4piJOeLlfWJ9tbUDy8W+U9vEuPpqMb61Wfzzn//kyTzgYnIrggtKD3NEZUqHzrc6P7lerDzWX8ldRbece5OYOAryYpbpETnKOmRqlpjU2iRGD4r1e4IwddIkz2gQxChwXksdjyr++Mc/ihtvvFEc3a9A7JrdIhpkBxrxD5V9l5NaK3n0QJjEpCqD+k4mQfXq4R57Kk9r6vj5rqYqz94sprGVxa4IinpZYqfsJ40tzBErhzeIBx98UJx99tk8iYvFixer7aTaCo+YHpR9r7n9+7HYQjRVVSg/1hfG2VYQZezb01L7o2SzdN3EJp7ECNc1EESIQu+UUxhtjxhpN3uZPT+XMYgkpkP7V4l5lbZVGiMFNFX2nzYOq1JN1GHSWpx77rlifkVf0dLSIm699VaeXKFPjrfv86oc7o9p7e+JM3efGeLg1n5i1tiRorqkWLz/sD2yu3xYpdrWVlep7SzZGX9ndmukZg73F8qvOxPBJkGBEBP8UtjHqA/naCoGk8TzBtr7EBylofhdw4xBXDHl9ekjHnX6Ta85D3FgXrYYnGeL47a1OeKggQ0q7hG1BeLQwY3eDBxMkw+ehHTn+FoxSY7opowZ5YlzTmuZGFNXrfZ/MKafuOE8+xr9+2SJ0/uXikPrS8WkkcNV2P5S3LdNafGk54gkJrgIICasLoBQ1u4jrMZiYR0/znYdwDqRUHAeYSQW3VqRAPWJ4q6xYhmDUDH1lUIiARwzb67461//qlwAt4/tpwTxDJq6RkscPaG3mD9/Pk/u4ojDDhU/k02aLqZ62Q/CtIwJzbKZWzA6W7zU0az6S+2ysn84rp+4S6b7yU9+It555x0xtqpUTJYW8hc/fZAndxFJTCAEhC0JAAJbPNz2QZHjkpo6PR2OaY0UnaMlLBAchKgvcekcZgxCxQR88MEH7j7ijiiw+zFjCnuL01tK1f7Yxh5ifmVfMaipMZbQwc033+w2cRARtvATFcs+UEWBd35t/fr1Ylq/MjGiopdYNCZbbJHx0ZyOdK55lrzephG25YqCyGICSQwkHvigVrd7fVB8pQGFk9AgHMqHzvHrpJ8Zg7hiIrS1tYnnpVWCiwAV21emy5eCIIHsLy3Jc7fkipvG1IgHD24X0wa3qpsla/SzNruphN+K9sHyLEt8tX+JeExWXqtszv74cK5YKPNCn2hxv0IxvihH9CuxPe5gR1kfceaZZ/LiGZGQmEBUPqZeSAi6D4qaL56G5vm4iKh/xeOnnxmDyGK6bGilqM7pqSp0ZIMtIHjC17SWiiucDvKtaP7W57rORvRrSAQgrIx+DMJvRfHHNfUUv2xvcvtojbJiRxbYVq1dWixsIWgIMgoSFhPIRaGHQSCmzjXO0yQxt16dz4xBJDENHTzYrdSrpHDm1toV+5YckVX27imuH12jhu47pBCenGbP1WGk9x1nVUEYZ0pL84ST5pwBZUpw00v6KMFMKo512mdMGCcuPfoLar84q4cY3mx3+sMQ5GcKY494PihqBodU2HN5FIdT62Pxa6RKVZ69VUwdlYXiwsG2j+ilZ3aIX09vFr/dp1kdV/XuIe6bWKd8T+hDIT9sT2kqFt8dFRMTNYd6E6dEIsWE9U3rB5WLkiy7WURTlivzGdA3Wx3jeuj4Y67vG7Icb8zqr/pd8ZCMmFRloXk7pc0e9kMQmL+Tgw1XWLT6ANSbOaK+lKVbTDFgpn50oe3vmVRfLc477zy1v6AqX22bZT8H2wF59uhrWH62si7o7yyXgjqsX4GyXNgiHkSD7fENxWKytECTZad1nOzMqxFebi/R5DQjiEPb4Y5VHOn4pTDFAjfCpIHxXQO8IqLwz8/ISpLlsdobhXXaFFsUEFZ2T3vkB6sEy4O5PLJacovlKWof4aDcv/w8f/6pUl1zbxQTOseoyHVLj1DHiI9jOC+xbSy0+0V1ufaUx7dk34riTCy246DJwhbN4L4VeYo4Bpucub5qaZUwvYL9nzpuhIYG24od3s9eSYAVBgRK/+6777phHMmKCbz7Gst+o4X7oGB9yQeFMMdK7XrUqVxmpZYe4s87Varr7G1i2nfffVWFLZkUcy7OKrd9T/AxfWVghWgqsoUx1wm/QDZDN43pp/YLcv0z/py4PrawTFdKi4bR4ruzbVFNGzdGTdno8Qmf/uMj2eGvUU3g+++/74brSEVM4KwpsrLWOe/ckUDgg4L/iHxQaNKklUL8jefaFexOCFv+PNNBytthxiBUTOOKcsU7r7zkCdsyoU7cP8m2HBdccIErpuuc/lFZTpaac8M+1nA/N8PuWwVx9uRJanuv7HeNHj7MtU4vSWs2fECLuHTZl9TxvhV91RYvJERFqmICC/A9S6cZczvfE2vt1ZrwQTlC24z/hNPSqXDLWcbieNB53smS8naYMQgVkwlvyl9ijTOLD0wtsS3So1PsEVnbxAlqJIf9e+65R5zYaPebcIy+Ezk6aYsJXWx/JC3TpZdeqjrWKq0U1zEHLVDXeFYKkuYGJ02apBcnFOkQE4hnpEQU5INCU1dTILZ+x46/boUTX6fsG/J8k6W65t4upj/96U+qQveXVgKjKwArIBFGFmjFihXKemH/rbfeEi3OiAwdbvSZIKLhBbGm6+2331ZbeLfvuOMOd5kK+mqrF9rLgBdU5anrXSz7Y6OHDtaLFIqk/ExBRF8JoujpLFEB4UbARDHOO4Jx458zIxbvyFH+/NLHjEFCYrrkkktcEUxsthe1YQKWwsAnn3xSnDfA9kMByF8/zwlgC4Fi6uaK4bZjc4gcFT51rD3ft2C4HXeEHNU9s6jNLkwEpFVMxPWyDyXF7QpF/phcC4V5Ojg2aWKYOumnT/Xnkz5mDBISU21FuTi23p7awFsmADrOtOgf/MMf/iDOcAQGlBXERm56MwcXAaZMAIz2sKwEwMpNnK/NzRK7ZsWG/q/PjF3jX//6lxsehk4RkyyfxwcF1wHCsW+aWkGY/tYLrJQeh8KJiU8MZwwiiwmrH+E3OrAqX02jENAsUX8JUx0AmrzHptoeauSPc+g3QUjwQZGgwN/85jditjMSBMY5C+hWNtsuCUKT488a1DdLjB8/3g0PQ6eICZzWaJN8UCD6U3Ad0ByePulLhAA1H5Qbjn16AyboLeNgZgwii2nY4EGuAOZPnuiG4xj9HWwXNNsz+oeOHy6e2/5zZaXqc20RBLGm0n5vbuW8mWqLV6qw1OTaEdVqizdeMIK76bvXKk85XvzcOGOUCovHsWPH8gefPsI6cR/UwLKYD4qWouhpSHgQFfpUcDFQnM+TZbpS9mW+O9LuzxBeffVVdTzS6VBv2rRJSyFEeam3PxXEhx56yE2zdu1a/rAylxAStkvH2EIgH5RszlU4FxORhIN9slI0BfNZt0xYkEYVv++Q2JwYXl1C2IzSWDNF+OUvf+mmWdVSInLlKIjm5+BovOfSb7jnB9fVuOlITJkAlCMuIQCM9MgHBSHB6sAHBStDL3byNCDSmFYhJMaMQSQxNdTaHm2QOt7AnDlz3PBvDC7XUgjRNzc2/J83abwYUF/r9pVOHmn3reg8ykBIt5i2bt2qPn6BPPE2MYCXSqNAlcPg5/H4fMj3hIrVLQ62cB2Ql5wqX3cZjNGW+KJZdL5Wx6/B6ea1N4rp3AH25OycZu+bJEhLgsBSWh2lWfbN4hycl/OmT1W+JhxPH2yP4jAlc1pzsVrL9Oabb6qwVMV00EEHeR72jBkzPMejRo1SYopyDRXHUJk6P9zp5A1BcB8UCQuEu0BfS65TD4twTf1+rAxCXDE98MAD6k3e//ztL/yUWpuN0dyx+832hJ9++ulKIHddfokYlme/6VtZWqJGcnADnNE2TOzevVtMLOkr/v73v4vHflQv/vFCmYqXqpjwTQOk1wnwsKKiIpbSD5XWUJkmut/OrCv0i4S2LGznvVo4RnOwWhGuye4lYxBXTGHQP9qlA0K6aK33BYMBTicdvqbXpKAqK70vUyLN/P2nBorp09+/K/614TS1jYctW7bwB25kPKg4hsoMohrd6T4oXTz6Z3zkebwR7C5ZIaJJjHBNdh8Zg6TFdOKJJ4q1KyvFtddeK/7v//7PDX9yS3/xyiMt6l26wf2bxOB+Vao/1V5qOyNpAd1zM5rE0ZNjQ/eXXnpJCQqf4MExx4JKx/FnOKfjH1Prhfj7brWPT+9QGhPjQcUxVGYQ1TKUfZr9PigIiXxQuLbsH9EHMHDc0WZvlxzsz9NEdh8Zg6TF9Oc//1l9Lqe60l7zDbQ0l4m/P1+i9seUFahJ2x+Os0dwuA62GNFh7dNWucX825n9S8WGQeXqy3Rz9hkozl7Wy1jRCCMuWbKEn/Zh27ZtirzPpDMeVBxDZYbxhotl3ism255yLKKDmGhBHVwHuLZjoUwCUctX0NxJAfK8eVyHGYOkxTRv3jxx1GGjxKeffio2rrMndSEqvFuHsA2DStWXU+A2WDJmiJhfmSfF1SxelU3c1cMrxSPXbBQH9CsSc8v7in3L80RuTo7497//LU48wrZAHBAGwolhWLp0qWhqauIP3cd4UHEMlRmPKn8Ihr5bAPbN9jZ7so+0+1ktDebvEE5NpLNGykR2HxmDhMWUm5srPthRIR67c5jYet0Q8b2LW8Sr2we4b5jcelWTOP80e7RGwBflYJVekZaK5vHwKjkBa7ufuKtJPL2lItAyAQgnRoWeRic66vHA0yRMXTz6PrZwVsLBiX2+jtzpO0VkxiBhMeGjqJsuHO4eT2kbqkS0c+dOdQyrdOCBB7rnf/GLX4hLh1aKxTWxzwue2mS7CPTmCj4rIKgDDuAaOEeE9QkCrJMelzMKeJqkGCQojP6wDx8UfY+cvOEUD4QvCtvgf0zIGCQsJh03bawTj9w+yD3GpC1eE+/Xr58Y2Nwovjqo2l05Cd8OiQlf7D3LWVu+dNGBoqysTBx//PHi5ZdfDhUTgHNBXLlyZdw4xCjgaZImxKH7oGifzun78JrT33GgyeMfufczY5C0mJDurcdq1T6WhKyaMkKJ49g6e/E/cXmj7c/JzcpSX4ubVtLH/XTgzDJ7YR0RwjvVeZBhwHkTucMyjBBtPPA0SZP7oGhOTxcRtrx5o+bPtAIhxoxB0mIi/Pa3vxUL60rEKY3F6tvdv3MsERydhEWLFokXZjSLxvJSMaGlUb1lAusFvPPD68W3htrLTn4rTX5tba16SPEATzbi6USzycOC2KViArGgDm+7BPmgsG/6+w1Ox7GpMWOQspgGOK8jYbSF7ZelqICBAweKaxbNFM/OsJfhAo3lZWK/9ini3+/tEk9NaxQfLBorOqa3q7VSL2/epN5MIT9UFMTzI4UxCnialDm3VVhTG7w+KIzy9K+w8DQUTlbLPzGcMUhdTFX2dwb23WeGeGhybNFcpfN2Lnj96hUqrDA3R0x25uX+uOUH7vlFc+3O9+6nt4s5WAZr+Sv7f6+9KP61+jgerID4iTIKeJq0kASDZg/78D/hdSpMGEMwQasM0FHnzaDNjEHKYrpo1Rlqvk3/xwB0sOc2VIpFjd4Pxs+rKRL3HjTVPf7kD78T1w6vEuMHxVwJpg44RDSyyBZZ2AflN2/ezB+0kTfccANPaoQqh8HPkwpVGSAO3QelrzzgX1vRVxmQL8p7PxmDlMUE/Pgb54k/nXSguPjii9X/ngSBXq6Ec5Lj6mXHim9/+9tGMbVXFHoeIEdUEQWlD4KKaxBEqlTlIFGQUGgf83vYh8WipSv0YoLpg2MZhLSIKQpytW9aLjvKfD1YndEDW30VzqdEaDQYxcttYlSouAYxpIOqLEGC0j/aqk0Qq3T+T/ZkDLpMTHhnTncDfPOb3+RRFEyWCUBYuhgVKq5BCOmiKg+EktUzJh7ug3K2iI/vFnRbJon/fvCu+lThQ5MbxO43XuGnXQSJCUhk6B9GvCgaBYjLBZBuKvGErYMCtY/cY2UBu5+MQZeJCThwxECxcHL4a0phYgJoiYqJtOCNh5sYBSqeQQDp5MlHW/Z3C2giGMQxXAj4SCvKu8H7LQN2LxmDLhVTFMQTUzwgbRRGgYpnEEC62dJoC0aVDctUsI9JYCy0w2ek8eKm7DvR53nYvWQMlJgykamA52VimIuBwNNkKDMGrpjE22UZwbUr7aFxKkBzR/cVxCj9plTL0ZnQ7iVjkFYxrT652nPcWO+PE4+pigkWp7i4OJKg4iFKnD0F7T4yBmkVk4Kz/4s7S8WFF17ojxOHqYiJ7iUq4yFKnD0F7T4yBmkTU2NDlbrJ+XMa1fG0qfb3CEpKSnxxw5ismOg+dEZxJYQh3vk9Ce0eMgZpEdM1F5S6N0ni0b87sObk6IJKRkw0AuTk68ZNDEO883sS2j1kDFISkxIOw7RJNeKiNaWifZr3c4H4m9Xlx8QXVaJiChNMkMjce46DKHH2FLT7yBgkLKZbryoVy04yLwXBagGK986TZfy0C4gQ+fC8wUTFROVPhvEQJc6egnYfGYPIYoIAlFgCAMuz+wVbRBeuKhH33VCqttdccw2P6gLfJxg5rJ/nOttut1cIRAWVP4imFZnuPYeAXl7IVGj3kTGIK6blS+yOdZCQ8M0A6idBQNgesbBEjeY2faNUbRsbvOuaOJDH8z+NWSpVnoig8nMmGoeDvlkQFXBH8Pz79OnDo6UN2nUyBqFiWr3c7hNNa6tVFmfZMVWejrUSiRO3sd4rqFuutLcQGgSF/ZEjYm+yAMgT56ZNGaOOSVCqPBFB5dfJwZewEPFNgiCQOMKAte08TxM7A1r+GYNQMSk/kbBFc+HqGhU2f3a5WLNmjWrCcHz/Zrs5w/6Ri0rElevt/UvOKVHHJCg14pP7NdVwI9S4ooOAli1bpq4zYvhgV0y7du3SHl0MHx/c5qkgKj8RHXITeDwwzAuO86bX0ElkeB+Q5xfEHj16uGuw0gUt/4xBoJiUZdGgN0PgtInFroggFt2fNKi1WPWf6Fz7pNg56lPRcXtbjec68Fc11vW0y2TAbYNtsYGoINp37yMEPG5QfHpRgUAfC0s3a2q8954ItHwyBpstp1BcTCOGD/QUHpZk0phiVzS6IEg02KK508VFzZ8rHkdYyG/YoGJpqUo818EvHudRJvrSm472cu8SXp0mS8LB05iAcP37TTxNupmM1dLSZwyutJxCcTFRE0dY5viI1JBfbkcMKZZCscUFqwXCj0T9IxyTs3LZ0ba40AdDGjqPrclXhfBdj9vNCV7z5jB90EvdQwA+PmSyL64pvv76OYGn6UwmAi1dxuDrFt1IHDEBs2fPViJS827SMkEs8Bet/2qpa410lpfb21XoyL9tW6P5s2zxQVQNDfYbwT44Zdj5QGyyNgj6Yrkg/Pf+H/oqji9B0deTA/hAB0/TFVSWOQK0NBmDUy2nUFxMR3xxES+/Apotsj7wdEMs6JSOGmb3ob54ULE4+5RiMWd6sZg8vkSJD3EgPIgIfSm4DiCmwAfHykJlVOVMAv9csq+bHuLTob/ZogP/6aJft6vZ2ur9kgyHFjdjMMNyCsUrcP5s81++X7i6RGy73RbTxedI4XylWLy6rVg8IEd1bzxWKtadViK+fkaJ+O5FpWLDWcXiO3IUN2WC3bSBp3+5WBwuBQdBmaBGdqwsIDkzwbCvn0SF/jYwvjUVBIqzJxgGLV7GoNGigrPKU6MxA2ZMqRQ3bSwVSw+zrQ01aWi+YJlAagZBhON829hiMWaE3dy9vr1UXHeJWUzkgghiUWGPSA87DJ5XpHoGfw+KgD5ar152vK5kELQfwm4rw6AK9v4O76gLhD+IA51oiAjNHdwHn7xZKt7bUSqe3FIqLj23WJx4VIk4ZB4sT7G4Yl2JeOIunI8JjJq8S8/1uh4A8j3FI5UZTGQktG7duljaSQuEdfUzNuUxvPBRETQASDeDoE1uP2plGFTBvv31PF+lgSOGVon7779fvVJ98skni1OWFIu5M+x+ULJEH6uhHm6BUrUP8usGsX1ilv0gIYL1P3YfvMojAHCAUjzrqPNjIiLm2R39KOgqIYEm1whwxhlnUJxVVoZBFWzu9GxfxR26wCwa/MEND0uENJ/HebjsR+1+wbZOm7/lt5SgKu+Zm71iuPgRtwK4K4HCrQFj/SLSKePQh+1NCOqQV1dX+8LSORI0AZ9wdM4PtjIMsYLLyrrgLG8FL1iwQFx00UVq5AWeffbZ6jODOHfAAQcoq4Ut4jz++OM+gSA+/cP3Cy+8oPorsHAAj6vTZK36N9iecZ8QiCu+46uM0Pg6q5oCKw/w5RmHQLr6WZgDDChLxsEtHCrsd0/HfEaYg0PlQwzLly9XwtErXP+LC7I2WPLBhQHgP1d0sQE0KoMQSbAAzh8y3yumK9baX0Gxvn6fXwicI2cIq0++Pzwe6Tkw6M9IJ8QSdJ4D9xYmrnhzfTq08IxDrMBOxaEyYW10QaDisYXjksKwhgnhEBlWE5jSHXXUUcoSYR/LWCichIX4lAZWjPbvvd7bGXfLyQWQThoqLqh50+PxcJ4HIUww6B+tXr3aF07Uvw6shWccdlj0AJyK2zekgw3PuH5MIMFwQmxqvZIUEv6ansJhiXhcT76akP6ykz4YeoJfAPG47sf+sDDK6wweHPtTaRzzT/bwzz6bXqsKAo9HjDcXiGU0hvMZh3aLHoBWgSccaRbUfvvt5wtzBSDM/SCTcEz9K/ST2sb5+0qqfAVl/oqX3HqPv9n788+yReXwASJ/yRniv0/lCOuyR0VdfV+RX2XOw8N1W+1nkQASEVPQaBAWUAc/T2L63//+p4dnJFThvrI011eRnI0NlaKtrc0nBHw4nocRsXSXhwGYguH5c77ysLOCkVe6pI6lK1fFzn1xtWgaUSesLzhiWnOrePH2bPc8rXmCy2DlmWf58sX18DnpKKBnpzNoSI8pEh6XqAMd7qwsxwXikCzXSSedRGEXWBmK2E0ZKpRz4sSJnv4PmjEIBhZI76TTKI9Gc7qYqKPO8+ZU5cJIi1c4E5Pn3BfXiOL8Hh6WFvQQx/UrUed1K0Bpds8aqlhR119Yl2zzVbAJQR3qIASti+IwxTvuOPslDi0sY+EW8q/Pxq9g3QoB3OoEUY9L+xvPD7ZOD93izMehwlf/wHZSyv2HNzlWZsV3VD7Fh55quwUQdsDJShTPT2l1BUK8c3S9itOx6hL1h9BLV60Vo0/5mkdMB9ZW2vnI65J1wL9pmoBzVVZPHxFuAvqVPC5YafXgUV3odcOYsVhmOYVsquvpq1SdWM+ki4n6Q7A0GK1wAZHVwoOEhaIwj5vAcB1QlWnYNNd6HFieL/pWNYjtE5qFdeWOmMic83n9pFVZca24oLVS7jeLzWNbPGIaV13lxiXmFJe754vz8mLnrnxaXf93vcsCxTSkRy91nhPpTMAz4HHBZ7PN85QAj0v1pNVdRsItKK9UnY0NtR6xkJggEPiSuJgANHc0qqMwXWx1tX7r9L+37O+Bu5V7/l2ioLJeVfrrUwf4RAHi3JSyAnFKfak4vLpIVOdme8S0vqXCE7+1pMg917eg2Jcfrr8ruzRjxPRutvNMLOuPWr1lJCKJSbc+b9bY/yTOfUtBBLiY6Jh7vFVZMKPvVCw60ueuXS/uuusu+ylLVDY0+wVwwYPqHHw2HMqPgzjn3O6G9Rk/yw6jZlLnSfbIK1PENLaH2ynvo9VbRuIjyxHTeaf28YmIi2lIaZnYWdMsXpbNCcREQMdc92jTbDwckn+tbTWKCUQzuWCWLaiPX2ZWiXjxI+K6m28R5XUN7vWAMRMm+eJWDR7liQP07JWlzi09/svq2Dr3R+qYRnfYqhl5PS/Lbup0oXAxgK2WWVibeuX7wuLxJSkuHgZS/Wh1lrHItiJYp6lTxqnKf7nG/jt5TLnsV1ohXpGiel/2WXZJNsrzt1XVi7urG8Tb8vi9fi3iwDlz1L+IN5TYS0/41ErH5JhlUmUImQ455ZRTVBogKztbxX/lldhHV+cuiP1FmY6q2tg/KACU38IvLY+FOZ18l+feITvJPTwVyisZ7GwxdfSw71Py41iVZTZcMX26y7y2CJVPbgGaWzvkkEPE97//fXHzzTeLv9a1iq9V9FNW6NFHHxUvvvii+tsw/A8dmjKkg/uApmdcQTn5/+6pYL8ScWJJnvjhyHrx4zENYk5pnrh+WG0k5pdXq/RZhWXquKiwSB13HHmCug9sQX49lIcqVd/X2dli0upmr8FGK8A6/ek3sQlg/PO37mcCFy9eLA4dOVqJ6XuVdWqLv1o9+uijXRGRFeL7en9JXbu81l+hRCw3uRqjsAqRL0dixVk9PZ3sMC6ojXXAC4dOUmEFffrYYdwi6ZT9MJTrq736eFghLdZpcsuJuLJTI4qc84f2zFFhQ6yevrjgST1zfWFEXOfUns6/FuxlYgKMYkKl601TQ0ODmDlzpkdQZ1XUKBH9rLpRbfVzaA51IYGYqwOHD7bFdOAcx5TzygTlkL/40BViy4/vVfvW5U+Kotxcn2DCmDN4gifPuTW2WyD34BX+63HKcn0/q8BjLYI64PVSNDyMwm9meYDogPMwnf0d35Xka3pF7Q1w5+r2mZylKnlAf/tNEn2iljht2jTXPXCdY5Ger2lyxXTrrbe6oz3etBHVVAFZpQAxLT059ip301J7VNZQVi42DakRJ9aViCqZT11VZSjLKu1mDuxYtkZte8lOeUudtITr7xFFI9qEtdgZ8XEe9BVVNr2SuZhelUP3B7OK1D6skn7ujqxCd3+5tET6uXhicp/LXgqPdVq1LFbx5Hg0sVwSIiLy87ofClh2dKx5GznEmZrglehQh1pQj3DZ5CWCshFy1HfIVz2jN7gE8sq9b+JY59/tu75icaX4Vq88t5IHSjE9I4VA3LdHb/cc9tF848eEkSzujc69KOPOlh1qSvdzKUA9H52HOU2kZLFeQXsTBlqOmPLz/M0diYGLhXhoeZXa4iHyc4SRQw1+JTly8lUgp9O36b3PYW5e+G9g4L333hPt7e1i8ZIvqeP9999fvTKOdVf4/96cweN8wqR8aT+/xp5yCSSzTsQaaYkgElgk0ATcP/pAl0lB6qLk1DvgVA965eyNcG/kD8/ERlskKDjg0IcC0Rk3OS7xq8QW0y98ycnbT8RGi1UVzutLvOJ0yn5SRf9Bovf848R+h8SExJFz4DKx9Dh7dMZx3MmnCuuES9TcHICtmo5ZdoU69l3TxMah4njWTFGl034YwkTExVRmua91fSbgCkoXEwlqdnuxWLW8WLRPskdrcFBCZDR6I4Ghz/XJm7G0f/q1YRXlN3/urzidi9eICcV5bmf6g47Bns711YNrRP5A56WByx5T8e8d3eDrhPft3VvFKT71SjfvnZNbxdQKw3RKEA3WicLW9erL9eOBnvY+p3/FSWJynv17serYu+GK6ayTvGudjljkbaZuv7pE1NcVqzXkOP7DM6WipTn21ZQgrlnuDHt5hTGWy5HikPJSJQjMsVVW1Ylj+9eKMZUVoqawUBSNalfxDqwuUXEgkPayAp+YwNLqOmGdsVlYVzwl8nPsEaF16aO+awZSey4mhoHHjcDPFNwbQyeZiyFVqrxlp9hXYYyYmzuiukgsqMiXI6tTxF9+Li3MrCNFTl6BHUd2xrloiPeNbfSFEf+8zxBhnXdnuJ/JRFnuodportFxByyTTWAYkI7S/MBxE/DR3LZs95OGW7V6+EwAowhXUJs2mF/WTIZHLuxt58srKoz6S5RYJnLiZaKoZbhPJMRbRtb5wsCyydobvbI/pioa/iuQX9PE7JxOE5P2vD+T8HjGn9pS6BNGMlT5yQ6xr6Li0fGCg0EorG8R1pcuFDt27OCnxPxFh3jy018N1/OOSyvmFccIDtsJPbK0K/mhp1nUs7faQoAUpj3nzzR+Z2mCeu4ntqMxWXpe845KjLx0K0Lhkw/yVFjziNjbu4WV/u8l9MXSXC1fHeu+eZn/ukHMKxIXOqOzZCzTTcwbrj3fzwWmWZqgkm3y7r42385jza3+CopDwroNF3jCCweNds/VNHsXz5lQMmNhLI60Rpdf9W3ftSJR3gdGX6mKSXuufd2n/TmAR1DjRiTeKXfT84qJQwznPRWjncOIjveLvta/Qljj91P7Vfn5vvNEjOr4tSLTea08GTHd6IhJe56fS7xtaYLKzvb7oYL4/153Fr5NXeSvmIjEykce9qvJ3vXev25rcV8lLxzaprbFrSN8QlJiMlwjIcr7mSz7SmCNFFUY9LgNsQlcsIQe7ucR11maoMD/vGZeA6VTxe3tLPtIlVpnWRfHmuYK0Wf0DH98ydNaa7xCmjhPWMes98VLiGduViKClYF3PAz4JjhZpmmxZbjdkKiwmKBqKnv4BER0X/PmlZEM550gRuTniPGFcgQl2VbUR0wt7iOPc0UfvKLE4zvMz85WcSbKNDOrpJU84hxfnKRo2c1XPDH17t1bZHufWTcYHrOYqM5f4V9Hrs4FvOadKM8/qY/61LKOwvEzPXE6jvyy5zhvygJPfPd1qXRw3VZxdM+cQDHh3xDYM7rEfXrdMII/MDWJCyGFveadFKVlOv94+5M2tU39xRt323NuID43SH+XQS8IwIMOUPiixUeIU9fH3slLC+X9cTEVFvo+gr+THlY34uMEyyAqxcoGfwWkwpApEIL6UDzCTr9eHT9zY7baWuv9nfiUeck29TqS9j0Azm4kgRzL/yBt9s4V1ob7/RWRRq48+3xXTEo4CJeWrHXYSPtDFstjKwbSxmMv8N9rjO+op9KNlAAH3DOW/+HG2DjUfX8t3dx8c+zVcZeJTJeE8ZSr/ffi5+NWNzoF4y3/ww7m3KXmt2y7kqdeI6zZRwurutlfvmD+y+pGl2K25IuWvyJSY2mNsM6/0y8K8LJHhdUyxp8mPfxUstzqRkagVHKb5a+k5KmLip9LnRda3dhrMVfyKMnlkmslvyv5gORLlt2s8Mq22afAH+blG5IPSd5o2V9iw0j0IMkRkvlWNz73uMryiwZ8U4/UjW5EhcladaMbSaNbSN1IK77EA7rhx/8HENvQxrkfzDIAAAAASUVORK5CYII=>